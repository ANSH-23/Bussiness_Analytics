# Project Screenshots & Dashboard Wireframes Catalog

This directory contains visual layout wireframes and step-by-step instructions for capturing and archiving screenshots of the executed Excel financial workbook and Tableau dashboards.

---

### 1. Dashboard Layout Wireframes

#### Dashboard 1: Executive Overview Wireframe (1440 x 900 px)
```
+--------------------------------------------------------------------------------------------------+
|                    EV CHARGING NETWORK — EXECUTIVE PERFORMANCE OVERVIEW                         |
+--------------------------------------------------------------------------------------------------+
| [ TOTAL REVENUE ]  [ OPERATING PROFIT ] [ ENERGY (kWh) ] [ SESSIONS ] [ UTILIZATION ] [ SUCCESS%]|
|   ₹ 4,324,510.80       ₹ 1,289,320.15     224,198.50       10,552         11.8%         89.3%   |
+-----------------------------------------------------------------+--------------------------------+
| Monthly Revenue & Operating Profit Trajectory (Jan - Jun 2024)   | Station Profitability Ranking  |
|                                                                 |                                |
|   Revenue (Steel Blue Line)                                     | Whitefield IT    [██████████]  |
|   Profit (Teal Line)                                            | Koramangala      [████████]    |
|                                                                 | Indiranagar      [██████]      |
|   Jan    Feb    Mar    Apr    May    Jun                        | ...                            |
|                                                                 | MG Road Metro    [██(Loss)]    |
+-----------------------------------------------------------------+--------------------------------+
| Energy Delivered by Station Hub (kWh)                           | Revenue vs Total OPEX Breakdown|
| [ Bar Chart: Whitefield, Koramangala, Indiranagar, etc. ]       | [ Stacked Bar: Elec, Rent, etc]|
+--------------------------------------------------------------------------------------------------+
```

#### Dashboard 2: Charging Demand & Utilization Wireframe
```
+--------------------------------------------------------------------------------------------------+
|                       CHARGING DEMAND & UTILIZATION PATTERNS                                     |
+-----------------------------------------------------------------+--------------------------------+
| 24-Hour Diurnal Demand Profile (Sessions by Hour of Day)        | Weekday vs Weekend Share       |
|                                                                 |                                |
|   /\                  /\                                        | [ Donut Chart:                 |
|  /  \  Morning Peak  /  \  Evening Peak                         |   Weekday 71.4%                |
| /    \ (08:00-11:00)/    \ (17:00-21:00)                        |   Weekend 28.6% ]              |
|                                                                 |                                |
| 00 02 04 06 08 10 12 14 16 18 20 22                             |                                |
+-----------------------------------------------------------------+--------------------------------+
| Connector Active Utilization Rate Ranking (%)                   | Utilization by Port Hardware   |
| [ Horizontal Bar Chart across 50 individual connector ports ]   | CCS2 120kW       [██████████]  |
|                                                                 | CCS2 60kW        [████████]    |
|                                                                 | Type 2 AC 22kW   [█████]       |
+--------------------------------------------------------------------------------------------------+
```

#### Dashboard 3: Equipment Reliability & Downtime Wireframe
```
+--------------------------------------------------------------------------------------------------+
|                       EQUIPMENT RELIABILITY & OUTAGE AUDIT                                       |
+-----------------------------------------------------------------+--------------------------------+
| Cumulative Downtime Hours by Station & Root Cause               | Monthly Outage Duration Trend  |
| [ Stacked Bars: Hardware Fault, Power Outage, Maintenance ]     | [ Line Chart with markers ]    |
+-----------------------------------------------------------------+--------------------------------+
| Session Failure Rate (%) by Connector Type                      | Maintenance Repair Cost by Hub |
| [ Bar Chart: CCS2 vs Type 2 AC vs CHAdeMO ]                     | [ Horizontal Bar in INR ₹ ]    |
+--------------------------------------------------------------------------------------------------+
```

#### Dashboard 4: Financial Performance & Strategic Quadrant Wireframe
```
+--------------------------------------------------------------------------------------------------+
|                  STRATEGIC QUADRANT MATRIX & FINANCIAL BENCHMARKING                              |
+--------------------------------------------------------------------------------------------------+
|   Operating Profit (₹)                                                                           |
|       ^                                                                                          |
|       |         (Cash Cows)          |        (Star Performers)                                  |
|       |      * Hebbal Depot          |    * Whitefield IT Express                                |
|       |                              |    * Koramangala Tech Park                                |
|       |                              |    * Indiranagar Hub                                      |
|   ₹0 -+------------------------------+--------------------------------> Active Utilization Rate %|
|       |         (Problematic)        |        (Underutilized Growth)                             |
|       |      * MG Road Metro (Loss)  |    * Electronic City Phase 1                              |
|       |                              |                                                           |
|       +------------------------------+--------------------------------                           |
|       0%                            12% (Target Threshold)          100%                         |
+--------------------------------------------------------------------------------------------------+
```

---

### 2. Instructions for Capturing & Replacing Screenshots

When running Microsoft Excel and Tableau on your local desktop machine:

#### In Microsoft Excel:
1. Open `output/EV_Charging_Analytics_Financial_Model.xlsx`.
2. Navigate to sheet `Financial Dashboard`.
3. Press `Win + Shift + S` (Windows Snipping Tool) or `Alt + PrtScn`.
4. Capture the full window and save as:
   - `screenshots/01_excel_financial_dashboard.png`
   - `screenshots/02_excel_whatif_analysis.png`
   - `screenshots/03_excel_station_summary.png`

#### In Tableau Desktop / Tableau Public:
1. Build the worksheets according to `docs/TABLEAU_IMPLEMENTATION_GUIDE.md`.
2. Go to **Dashboard -> Export Image...**
3. Save the 4 dashboard views:
   - `screenshots/04_tableau_executive_overview.png`
   - `screenshots/05_tableau_demand_utilization.png`
   - `screenshots/06_tableau_downtime_reliability.png`
   - `screenshots/07_tableau_strategic_matrix.png`
