"""
EV Charging Station Analytics - Synthetic Dataset Generator
Author: Senior Data Analytics Engineer & Academic Project Mentor
Description:
    Generates realistic, internally consistent synthetic datasets for an EV charging network
    operating in Bengaluru, India. Follows all academic and business constraints:
    - 10 Charging Stations
    - 50 Connectors
    - Fixed 6-month period: 2024-01-01 to 2024-06-30 (182 days)
    - At least 5,000 charging sessions (generates ~6,500 records)
    - Zero overlapping sessions per connector
    - Zero overlapping downtime per connector
    - Zero overlap between sessions and downtime
    - Exact reconciliation of electricity costs and monthly rent
    - Fixed random seed for 100% reproducibility
"""

import os
import csv
import random
import calendar
from datetime import datetime, date, timedelta

# Set fixed random seed for strict reproducibility
RANDOM_SEED = 42
random.seed(RANDOM_SEED)

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RAW_DATA_DIR = os.path.join(BASE_DIR, "data", "raw")
PROCESSED_DATA_DIR = os.path.join(BASE_DIR, "data", "processed")

START_DATE = date(2024, 1, 1)
END_DATE = date(2024, 6, 30)
TOTAL_DAYS = (END_DATE - START_DATE).days + 1  # 182 days

os.makedirs(RAW_DATA_DIR, exist_ok=True)
os.makedirs(PROCESSED_DATA_DIR, exist_ok=True)


# ==============================================================================
# 1. GENERATE STATIONS
# ==============================================================================
def generate_stations():
    """
    10 distinct stations in Bengaluru with realistic coordinates,
    station types, monthly rents, maintenance costs, and operating hours.
    Total connectors across stations = 50.
    """
    stations = [
        {
            "station_id": "ST001",
            "station_name": "Indiranagar Hub",
            "city": "Bengaluru",
            "area": "Indiranagar",
            "latitude": 12.9784,
            "longitude": 77.6408,
            "installation_date": "2023-03-15",
            "total_connectors": 6,
            "station_type": "Commercial Hub",
            "monthly_rent_inr": 95000.0,
            "maintenance_cost_monthly_inr": 22000.0,
            "operating_hours_per_day": 24
        },
        {
            "station_id": "ST002",
            "station_name": "Koramangala Tech Park",
            "city": "Bengaluru",
            "area": "Koramangala",
            "latitude": 12.9352,
            "longitude": 77.6245,
            "installation_date": "2023-04-10",
            "total_connectors": 6,
            "station_type": "Tech Park",
            "monthly_rent_inr": 110000.0,
            "maintenance_cost_monthly_inr": 25000.0,
            "operating_hours_per_day": 24
        },
        {
            "station_id": "ST003",
            "station_name": "Whitefield IT Express",
            "city": "Bengaluru",
            "area": "Whitefield",
            "latitude": 12.9698,
            "longitude": 77.7499,
            "installation_date": "2023-01-20",
            "total_connectors": 7,
            "station_type": "Tech Park",
            "monthly_rent_inr": 125000.0,
            "maintenance_cost_monthly_inr": 28000.0,
            "operating_hours_per_day": 24
        },
        {
            "station_id": "ST004",
            "station_name": "Electronic City Phase 1",
            "city": "Bengaluru",
            "area": "Electronic City",
            "latitude": 12.8452,
            "longitude": 77.6602,
            "installation_date": "2023-02-14",
            "total_connectors": 6,
            "station_type": "Tech Park",
            "monthly_rent_inr": 90000.0,
            "maintenance_cost_monthly_inr": 20000.0,
            "operating_hours_per_day": 24
        },
        {
            "station_id": "ST005",
            "station_name": "HSR Layout Sector 1",
            "city": "Bengaluru",
            "area": "HSR Layout",
            "latitude": 12.9121,
            "longitude": 77.6446,
            "installation_date": "2023-05-18",
            "total_connectors": 5,
            "station_type": "Residential/Commercial",
            "monthly_rent_inr": 80000.0,
            "maintenance_cost_monthly_inr": 18000.0,
            "operating_hours_per_day": 24
        },
        {
            "station_id": "ST006",
            "station_name": "Malleshwaram Central",
            "city": "Bengaluru",
            "area": "Malleshwaram",
            "latitude": 13.0031,
            "longitude": 77.5643,
            "installation_date": "2023-06-01",
            "total_connectors": 4,
            "station_type": "Commercial Retail",
            "monthly_rent_inr": 75000.0,
            "maintenance_cost_monthly_inr": 16000.0,
            "operating_hours_per_day": 18
        },
        {
            "station_id": "ST007",
            "station_name": "Jayanagar 4th Block",
            "city": "Bengaluru",
            "area": "Jayanagar",
            "latitude": 12.9250,
            "longitude": 77.5938,
            "installation_date": "2023-07-11",
            "total_connectors": 4,
            "station_type": "Commercial Retail",
            "monthly_rent_inr": 70000.0,
            "maintenance_cost_monthly_inr": 15000.0,
            "operating_hours_per_day": 18
        },
        {
            "station_id": "ST008",
            "station_name": "Marathahalli Junction",
            "city": "Bengaluru",
            "area": "Marathahalli",
            "latitude": 12.9591,
            "longitude": 77.6974,
            "installation_date": "2023-08-05",
            "total_connectors": 4,
            "station_type": "Transit Hub",
            "monthly_rent_inr": 85000.0,
            "maintenance_cost_monthly_inr": 19000.0,
            "operating_hours_per_day": 24
        },
        {
            "station_id": "ST009",
            "station_name": "Hebbal Flyover Depot",
            "city": "Bengaluru",
            "area": "Hebbal",
            "latitude": 13.0358,
            "longitude": 77.5970,
            "installation_date": "2023-09-12",
            "total_connectors": 4,
            "station_type": "Highway Transit",
            "monthly_rent_inr": 65000.0,
            "maintenance_cost_monthly_inr": 15000.0,
            "operating_hours_per_day": 24
        },
        {
            "station_id": "ST010",
            "station_name": "MG Road Metro Station",
            "city": "Bengaluru",
            "area": "MG Road",
            "latitude": 12.9756,
            "longitude": 77.6066,
            "installation_date": "2023-10-01",
            "total_connectors": 4,
            "station_type": "Metro Commuter",
            "monthly_rent_inr": 105000.0,
            "maintenance_cost_monthly_inr": 22000.0,
            "operating_hours_per_day": 18
        }
    ]

    filepath = os.path.join(RAW_DATA_DIR, "stations.csv")
    fields = [
        "station_id", "station_name", "city", "area", "latitude", "longitude",
        "installation_date", "total_connectors", "station_type",
        "monthly_rent_inr", "maintenance_cost_monthly_inr", "operating_hours_per_day"
    ]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(stations)

    print(f"[1/7] Generated stations.csv: {len(stations)} stations (Sum of connectors: {sum(s['total_connectors'] for s in stations)})")
    return stations


# ==============================================================================
# 2. GENERATE CONNECTORS
# ==============================================================================
def generate_connectors(stations):
    """
    Distributes exactly 50 connectors across the 10 stations,
    matching each station's total_connectors count.
    Types: CCS2 (50kW, 60kW, 120kW), Type 2 AC (7.4kW, 22kW), CHAdeMO (50kW), Bharat DC-001 (15kW).
    """
    connector_catalog = [
        ("CCS2", 60.0, 7.80),
        ("CCS2", 120.0, 8.20),
        ("CCS2", 50.0, 7.60),
        ("Type 2 AC", 22.0, 7.20),
        ("Type 2 AC", 7.4, 7.00),
        ("CHAdeMO", 50.0, 7.70),
        ("Bharat DC-001", 15.0, 7.10)
    ]

    connectors = []
    connector_idx = 1

    for st in stations:
        st_id = st["station_id"]
        count = st["total_connectors"]
        for i in range(count):
            c_id = f"CN{connector_idx:03d}"
            # Select connector type based on station profile
            if st["station_type"] == "Highway Transit":
                c_type, power, base_tariff = ("CCS2", 120.0, 8.20) if i % 2 == 0 else ("CCS2", 60.0, 7.80)
            elif st["station_type"] == "Tech Park":
                catalog_choice = [
                    ("CCS2", 60.0, 7.80),
                    ("CCS2", 50.0, 7.60),
                    ("Type 2 AC", 22.0, 7.20),
                    ("Type 2 AC", 7.4, 7.00),
                    ("CHAdeMO", 50.0, 7.70),
                    ("Bharat DC-001", 15.0, 7.10),
                    ("CCS2", 120.0, 8.20)
                ]
                c_type, power, base_tariff = catalog_choice[i % len(catalog_choice)]
            elif st["station_type"] == "Commercial Hub":
                catalog_choice = [
                    ("CCS2", 60.0, 7.80),
                    ("CCS2", 50.0, 7.60),
                    ("Type 2 AC", 22.0, 7.20),
                    ("CHAdeMO", 50.0, 7.70)
                ]
                c_type, power, base_tariff = catalog_choice[i % len(catalog_choice)]
            else:
                catalog_choice = [
                    ("CCS2", 50.0, 7.60),
                    ("Type 2 AC", 22.0, 7.20),
                    ("Bharat DC-001", 15.0, 7.10),
                    ("Type 2 AC", 7.4, 7.00)
                ]
                c_type, power, base_tariff = catalog_choice[i % len(catalog_choice)]

            connectors.append({
                "connector_id": c_id,
                "station_id": st_id,
                "connector_type": c_type,
                "rated_power_kw": power,
                "installation_date": st["installation_date"],
                "connector_status": "Operational",
                "electricity_tariff_per_kwh_inr": base_tariff
            })
            connector_idx += 1

    filepath = os.path.join(RAW_DATA_DIR, "connectors.csv")
    fields = [
        "connector_id", "station_id", "connector_type", "rated_power_kw",
        "installation_date", "connector_status", "electricity_tariff_per_kwh_inr"
    ]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(connectors)

    print(f"[2/7] Generated connectors.csv: {len(connectors)} connectors across 10 stations.")
    return connectors


# ==============================================================================
# 3. GENERATE TARIFF HISTORY
# ==============================================================================
def generate_tariff_history(connectors):
    """
    Creates historical electricity procurement tariffs and customer prices.
    Period 1: 2024-01-01 to 2024-03-31 23:59:59 (Q1)
    Period 2: 2024-04-01 to 2024-06-30 23:59:59 (Q2 - reflects annual tariff revision)
    Ensures 100% coverage with zero overlap.
    Customer prices:
      - Slow AC (7.4 - 22 kW): 14.50 - 16.00 INR/kWh
      - DC Fast (15 - 60 kW): 18.00 - 19.50 INR/kWh
      - Ultra Fast (120 kW): 22.00 - 24.00 INR/kWh
    """
    tariffs = []
    tariff_idx = 1

    for c in connectors:
        c_id = c["connector_id"]
        base_elec = c["electricity_tariff_per_kwh_inr"]
        power = c["rated_power_kw"]

        if power <= 22.0:
            cust_p1 = 15.00
            cust_p2 = 16.00
        elif power <= 60.0:
            cust_p1 = 18.50
            cust_p2 = 19.50
        else:
            cust_p1 = 22.50
            cust_p2 = 23.50

        # Period 1: Q1
        tariffs.append({
            "tariff_id": f"TAR{tariff_idx:04d}",
            "connector_id": c_id,
            "effective_from": "2024-01-01 00:00:00",
            "effective_to": "2024-03-31 23:59:59",
            "electricity_tariff_per_kwh_inr": round(base_elec, 2),
            "customer_price_per_kwh_inr": round(cust_p1, 2)
        })
        tariff_idx += 1

        # Period 2: Q2 (electricity tariff up by ~0.35 INR/kWh, customer price up by 1.00 INR/kWh)
        tariffs.append({
            "tariff_id": f"TAR{tariff_idx:04d}",
            "connector_id": c_id,
            "effective_from": "2024-04-01 00:00:00",
            "effective_to": "2024-06-30 23:59:59",
            "electricity_tariff_per_kwh_inr": round(base_elec + 0.35, 2),
            "customer_price_per_kwh_inr": round(cust_p2, 2)
        })
        tariff_idx += 1

    filepath = os.path.join(RAW_DATA_DIR, "tariff_history.csv")
    fields = [
        "tariff_id", "connector_id", "effective_from", "effective_to",
        "electricity_tariff_per_kwh_inr", "customer_price_per_kwh_inr"
    ]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(tariffs)

    print(f"[3/7] Generated tariff_history.csv: {len(tariffs)} tariff records.")
    return tariffs


# ==============================================================================
# 4. GENERATE STATION DOWNTIME
# ==============================================================================
def generate_downtime(connectors, stations):
    """
    Creates connector-level downtime records across the 6-month window.
    Downtime intervals are tracked to prevent overlapping downtime on any connector.
    Reasons: Hardware fault, Preventive maintenance, Power outage, Connector repair, Communication failure.
    """
    downtime_reasons = [
        ("Preventive maintenance", "Preventive", 800.0, 120, 240),
        ("Hardware fault", "Corrective", 3500.0, 180, 480),
        ("Power outage", "Emergency", 0.0, 45, 180),
        ("Connector repair", "Corrective", 2200.0, 120, 360),
        ("Communication failure", "Corrective", 500.0, 30, 120)
    ]

    downtime_records = []
    downtime_idx = 1

    # Map connector to station
    connector_station = {c["connector_id"]: c["station_id"] for c in connectors}
    # Keep track of booked downtime windows per connector: list of (start_dt, end_dt)
    booked_downtime = {c["connector_id"]: [] for c in connectors}

    # Generate roughly 2 to 4 downtime events per connector across the 182 days (~130-160 total events)
    for c in connectors:
        c_id = c["connector_id"]
        st_id = connector_station[c_id]
        num_events = random.randint(2, 4)

        for _ in range(num_events):
            reason_info = random.choice(downtime_reasons)
            reason, maint_type, base_cost, min_dur, max_dur = reason_info
            duration = random.randint(min_dur, max_dur)
            cost = round(base_cost + random.uniform(-100, 300), 2) if base_cost > 0 else 0.0

            # Pick a random day and start time
            for attempt in range(20):
                random_day = START_DATE + timedelta(days=random.randint(0, TOTAL_DAYS - 1))
                # Preventive maintenance happens early morning (01:00 - 05:00)
                if maint_type == "Preventive":
                    start_hour = random.randint(1, 4)
                else:
                    start_hour = random.randint(6, 20)
                start_minute = random.choice([0, 15, 30, 45])
                dt_start = datetime(random_day.year, random_day.month, random_day.day, start_hour, start_minute)
                dt_end = dt_start + timedelta(minutes=duration)

                if dt_end > datetime(2024, 6, 30, 23, 59, 59):
                    continue

                # Check overlap with existing booked downtime for this connector
                overlap = False
                for b_start, b_end in booked_downtime[c_id]:
                    if not (dt_end <= b_start or dt_start >= b_end):
                        overlap = True
                        break

                if not overlap:
                    booked_downtime[c_id].append((dt_start, dt_end))
                    downtime_records.append({
                        "downtime_id": f"DT{downtime_idx:05d}",
                        "connector_id": c_id,
                        "station_id": st_id,
                        "downtime_start": dt_start.strftime("%Y-%m-%d %H:%M:%S"),
                        "downtime_end": dt_end.strftime("%Y-%m-%d %H:%M:%S"),
                        "downtime_duration_minutes": duration,
                        "downtime_reason": reason,
                        "maintenance_type": maint_type,
                        "maintenance_cost_inr": cost,
                        "_start_dt": dt_start,
                        "_end_dt": dt_end
                    })
                    downtime_idx += 1
                    break

    # Sort downtime records chronologically
    downtime_records.sort(key=lambda x: x["_start_dt"])

    filepath = os.path.join(RAW_DATA_DIR, "station_downtime.csv")
    fields = [
        "downtime_id", "connector_id", "station_id", "downtime_start",
        "downtime_end", "downtime_duration_minutes", "downtime_reason",
        "maintenance_type", "maintenance_cost_inr"
    ]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for r in downtime_records:
            row = {k: r[k] for k in fields}
            writer.writerow(row)

    print(f"[4/7] Generated station_downtime.csv: {len(downtime_records)} downtime records.")
    return downtime_records, booked_downtime


# ==============================================================================
# 5. GENERATE CHARGING SESSIONS
# ==============================================================================
def get_applicable_tariff(tariffs, connector_id, session_start_dt):
    """
    Finds the active electricity tariff and customer price for a connector at session_start.
    """
    for t in tariffs:
        if t["connector_id"] == connector_id:
            eff_from = datetime.strptime(t["effective_from"], "%Y-%m-%d %H:%M:%S")
            eff_to = datetime.strptime(t["effective_to"], "%Y-%m-%d %H:%M:%S")
            if eff_from <= session_start_dt <= eff_to:
                return t["electricity_tariff_per_kwh_inr"], t["customer_price_per_kwh_inr"]
    # Fallback default
    return 7.50, 18.00


def generate_charging_sessions(connectors, stations, tariffs, booked_downtime):
    """
    Generates >= 5,000 charging sessions with realistic demand, vehicle profiles,
    and charging behavior. Guarantees:
    - NO session overlap on the same connector.
    - NO session overlap with connector downtime.
    - Mathematically exact revenue: round(energy_delivered_kwh * customer_price_per_kwh_inr, 2).
    - Session end = session_start + (charging_duration + idle_duration).
    """
    station_map = {s["station_id"]: s for s in stations}
    connector_map = {c["connector_id"]: c for c in connectors}

    # Demand probability by hour of day (Commuter peaks at 8-11am and 5-9pm)
    hourly_weights = {
        0: 0.015, 1: 0.010, 2: 0.008, 3: 0.008, 4: 0.012, 5: 0.025,
        6: 0.045, 7: 0.070, 8: 0.090, 9: 0.095, 10: 0.075, 11: 0.055,
        12: 0.045, 13: 0.040, 14: 0.040, 15: 0.045, 16: 0.060, 17: 0.085,
        18: 0.095, 19: 0.085, 20: 0.065, 21: 0.045, 22: 0.030, 23: 0.020
    }
    hours_list = list(hourly_weights.keys())
    weights_list = [hourly_weights[h] for h in hours_list]

    weather_choices = ["Clear", "Rain", "Overcast", "Thunderstorm"]
    weather_weights = [0.70, 0.15, 0.12, 0.03]

    sessions = []
    session_idx = 1

    # Track booked sessions per connector: list of (start_dt, end_dt)
    booked_sessions = {c["connector_id"]: [] for c in connectors}

    # Generate synthetic vehicles pool (~1,200 unique vehicle IDs)
    vehicle_pool = [f"KA-0{random.randint(1, 9)}-EV-{random.randint(1000, 9999)}" for _ in range(1200)]

    # We iterate day by day across 182 days.
    # Target total sessions: ~6,800 records (~37-38 sessions per day across 50 connectors)
    for current_day_idx in range(TOTAL_DAYS):
        sim_date = START_DATE + timedelta(days=current_day_idx)
        is_weekend = sim_date.weekday() >= 5
        day_type = "Weekend" if is_weekend else "Weekday"

        # Determine daily weather for Bengaluru
        # Pre-monsoon in May/June has higher rain/thunderstorm
        if sim_date.month in [5, 6]:
            w_weights = [0.55, 0.25, 0.15, 0.05]
        else:
            w_weights = [0.75, 0.10, 0.13, 0.02]
        day_weather = random.choices(weather_choices, weights=w_weights, k=1)[0]

        # Shuffle connectors each day for fairness
        shuffled_connectors = list(connectors)
        random.shuffle(shuffled_connectors)

        for c in shuffled_connectors:
            c_id = c["connector_id"]
            st_id = c["station_id"]
            st = station_map[st_id]
            c_type = c["connector_type"]
            rated_power = c["rated_power_kw"]
            op_hours = st["operating_hours_per_day"]

            # Daily sessions per connector:
            # High-traffic Tech Parks / Commercial Hubs: 1 to 3 sessions/day
            # Others: 0 to 2 sessions/day
            if st["station_type"] in ["Tech Park", "Commercial Hub", "Transit Hub"]:
                num_sessions = random.choices([0, 1, 2, 3], weights=[0.10, 0.40, 0.35, 0.15])[0]
            else:
                num_sessions = random.choices([0, 1, 2], weights=[0.25, 0.50, 0.25])[0]

            for _ in range(num_sessions):
                # Pick hour based on operating hours and commute weights
                for attempt in range(25):
                    hour = random.choices(hours_list, weights=weights_list)[0]
                    if op_hours == 18 and (hour < 6 or hour >= 24):
                        continue

                    minute = random.randint(0, 59)
                    start_dt = datetime(sim_date.year, sim_date.month, sim_date.day, hour, minute)

                    # Determine session status
                    # Rain/Thunderstorm slightly increases failure rate
                    fail_chance = 0.09 if day_weather in ["Rain", "Thunderstorm"] else 0.06
                    status_roll = random.random()
                    if status_roll < fail_chance:
                        status = "Failed"
                    elif status_roll < fail_chance + 0.04:
                        status = "Cancelled"
                    else:
                        status = "Completed"

                    # Calculate durations and energy
                    if status == "Completed":
                        # Battery energy delivered depends on connector power rating and vehicle size
                        if rated_power >= 120.0:
                            energy = round(random.uniform(25.0, 65.0), 2)
                            charging_duration = int(round((energy / (rated_power * 0.82)) * 60))
                            charging_duration = max(18, min(charging_duration, 65))
                        elif rated_power >= 50.0:
                            energy = round(random.uniform(15.0, 42.0), 2)
                            charging_duration = int(round((energy / (rated_power * 0.85)) * 60))
                            charging_duration = max(20, min(charging_duration, 75))
                        elif rated_power >= 22.0:
                            energy = round(random.uniform(10.0, 24.0), 2)
                            charging_duration = int(round((energy / (rated_power * 0.90)) * 60))
                            charging_duration = max(30, min(charging_duration, 150))
                        else:  # 7.4 kW / 15 kW
                            energy = round(random.uniform(6.0, 18.0), 2)
                            charging_duration = int(round((energy / (rated_power * 0.92)) * 60))
                            charging_duration = max(45, min(charging_duration, 220))

                        # Idle duration: 70% zero, 30% parked 5 to 45 mins after charging
                        if random.random() < 0.30:
                            idle_duration = random.randint(5, 40)
                        else:
                            idle_duration = 0

                    elif status == "Failed":
                        energy = 0.0
                        charging_duration = random.randint(1, 5)
                        idle_duration = 0
                    else:  # Cancelled
                        energy = 0.0
                        charging_duration = random.randint(1, 3)
                        idle_duration = 0

                    total_duration = charging_duration + idle_duration
                    end_dt = start_dt + timedelta(minutes=total_duration)

                    # Ensure end_dt does not exceed simulation period end
                    if end_dt > datetime(2024, 6, 30, 23, 59, 59):
                        continue

                    # Overlap Check 1: Check against booked downtime for this connector
                    conflict = False
                    for dt_start, dt_end in booked_downtime[c_id]:
                        if not (end_dt <= dt_start or start_dt >= dt_end):
                            conflict = True
                            break

                    if conflict:
                        continue

                    # Overlap Check 2: Check against already booked sessions on this connector (with a 5 min buffer)
                    for s_start, s_end in booked_sessions[c_id]:
                        if not (end_dt + timedelta(minutes=3) <= s_start or start_dt >= s_end + timedelta(minutes=3)):
                            conflict = True
                            break

                    if conflict:
                        continue

                    # Valid slot found! Get tariffs
                    elec_tariff, cust_price = get_applicable_tariff(tariffs, c_id, start_dt)

                    if status == "Completed":
                        revenue = round(energy * cust_price, 2)
                        payment_status = "Paid" if random.random() < 0.992 else "Pending"
                    elif status == "Failed":
                        revenue = 0.0
                        payment_status = "Failed"
                    else:
                        revenue = 0.0
                        payment_status = "Refunded"

                    booked_sessions[c_id].append((start_dt, end_dt))
                    vehicle = random.choice(vehicle_pool)

                    sessions.append({
                        "session_id": f"SES{session_idx:06d}",
                        "connector_id": c_id,
                        "station_id": st_id,
                        "vehicle_id": vehicle,
                        "session_start": start_dt.strftime("%Y-%m-%d %H:%M:%S"),
                        "session_end": end_dt.strftime("%Y-%m-%d %H:%M:%S"),
                        "energy_delivered_kwh": energy,
                        "charging_duration_minutes": charging_duration,
                        "idle_duration_minutes": idle_duration,
                        "electricity_tariff_per_kwh_inr": elec_tariff,
                        "customer_price_per_kwh_inr": cust_price,
                        "charging_revenue_inr": revenue,
                        "session_status": status,
                        "payment_status": payment_status,
                        "day_type": day_type,
                        "weather_condition": day_weather,
                        "_start_dt": start_dt,
                        "_end_dt": end_dt
                    })
                    session_idx += 1
                    break

    # Sort sessions chronologically
    sessions.sort(key=lambda x: x["_start_dt"])

    # Re-assign clean sequential session_ids
    for i, s in enumerate(sessions, 1):
        s["session_id"] = f"SES{i:06d}"

    filepath = os.path.join(RAW_DATA_DIR, "charging_sessions.csv")
    fields = [
        "session_id", "connector_id", "station_id", "vehicle_id",
        "session_start", "session_end", "energy_delivered_kwh",
        "charging_duration_minutes", "idle_duration_minutes",
        "electricity_tariff_per_kwh_inr", "customer_price_per_kwh_inr",
        "charging_revenue_inr", "session_status", "payment_status",
        "day_type", "weather_condition"
    ]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for s in sessions:
            row = {k: s[k] for k in fields}
            writer.writerow(row)

    print(f"[5/7] Generated charging_sessions.csv: {len(sessions)} sessions (Completed: {sum(1 for s in sessions if s['session_status'] == 'Completed')}, Failed: {sum(1 for s in sessions if s['session_status'] == 'Failed')}, Cancelled: {sum(1 for s in sessions if s['session_status'] == 'Cancelled')}).")
    return sessions


# ==============================================================================
# 6. GENERATE DAILY STATION OPERATING COSTS
# ==============================================================================
def generate_daily_costs(stations, sessions, downtime_records):
    """
    Creates daily operational costs (10 stations * 182 days = 1,820 records).
    Key financial integrity rules:
    - electricity_cost_inr: Reconciles 100% to session-level electricity consumed on that date.
    - rent_cost_inr: Daily allocated rent sums exactly to stated monthly rent for each calendar month.
    - maintenance_cost_inr: Routine daily allocation + recorded downtime maintenance costs for that date.
    - staff_cost_inr & other_operating_cost_inr: Realistic daily station operational expenses.
    """
    # Pre-aggregate electricity cost by (station_id, operating_date_str)
    session_elec_by_day = {}
    for s in sessions:
        st_id = s["station_id"]
        # Match by session_start date
        op_date_str = s["session_start"].split(" ")[0]
        key = (st_id, op_date_str)
        cost = round(s["energy_delivered_kwh"] * s["electricity_tariff_per_kwh_inr"], 4)
        session_elec_by_day[key] = session_elec_by_day.get(key, 0.0) + cost

    # Pre-aggregate downtime maintenance cost by (station_id, operating_date_str)
    downtime_maint_by_day = {}
    for d in downtime_records:
        st_id = d["station_id"]
        op_date_str = d["downtime_start"].split(" ")[0]
        key = (st_id, op_date_str)
        downtime_maint_by_day[key] = downtime_maint_by_day.get(key, 0.0) + d["maintenance_cost_inr"]

    daily_costs = []
    record_idx = 1

    # Loop through each month and station to ensure exact monthly rent reconciliation
    for year in [2024]:
        for month in range(1, 7):
            num_days = calendar.monthrange(year, month)[1]

            for st in stations:
                st_id = st["station_id"]
                monthly_rent = st["monthly_rent_inr"]
                base_daily_rent = round(monthly_rent / num_days, 2)
                # Remainder adjustment on the last day of the month
                accumulated_rent = 0.0

                monthly_maint_budget = st["maintenance_cost_monthly_inr"]
                daily_routine_maint = round((monthly_maint_budget * 0.60) / num_days, 2)

                # Staff cost: 750 INR/day for 18h stations, 950 INR/day for 24h stations
                daily_staff = 950.0 if st["operating_hours_per_day"] == 24 else 750.0
                # Other cost: 350 INR/day (network CMS, cloud monitoring, insurance)
                daily_other = 350.0

                for day in range(1, num_days + 1):
                    current_dt = date(year, month, day)
                    date_str = current_dt.strftime("%Y-%m-%d")

                    # Handle rent reconciliation
                    if day == num_days:
                        day_rent = round(monthly_rent - accumulated_rent, 2)
                    else:
                        day_rent = base_daily_rent
                        accumulated_rent += day_rent

                    # Session electricity cost
                    day_elec = round(session_elec_by_day.get((st_id, date_str), 0.0), 2)

                    # Maintenance cost: routine + actual downtime repairs on that day
                    extra_maint = downtime_maint_by_day.get((st_id, date_str), 0.0)
                    day_maint = round(daily_routine_maint + extra_maint, 2)

                    daily_costs.append({
                        "record_id": f"CST{record_idx:06d}",
                        "station_id": st_id,
                        "operating_date": date_str,
                        "electricity_cost_inr": day_elec,
                        "staff_cost_inr": round(daily_staff, 2),
                        "rent_cost_inr": day_rent,
                        "maintenance_cost_inr": day_maint,
                        "other_operating_cost_inr": round(daily_other, 2)
                    })
                    record_idx += 1

    filepath = os.path.join(RAW_DATA_DIR, "daily_station_operating_costs.csv")
    fields = [
        "record_id", "station_id", "operating_date", "electricity_cost_inr",
        "staff_cost_inr", "rent_cost_inr", "maintenance_cost_inr", "other_operating_cost_inr"
    ]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(daily_costs)

    print(f"[6/7] Generated daily_station_operating_costs.csv: {len(daily_costs)} records (10 stations * 182 days).")
    return daily_costs


# ==============================================================================
# 7. GENERATE DERIVED STATION DAILY KPIS
# ==============================================================================
def generate_station_daily_kpis(stations, sessions, downtime_records, daily_costs):
    """
    Computes station_daily_kpis.csv derived directly from raw sessions, downtime, and daily costs.
    Formula:
    - total_sessions = count of sessions on that day
    - completed_sessions = count where status == 'Completed'
    - failed_sessions = count where status == 'Failed'
    - energy_delivered_kwh = sum of energy_delivered_kwh
    - charging_revenue_inr = sum of charging_revenue_inr
    - electricity_cost_inr = sum of session electricity costs
    - available_connector_minutes = total_connectors * operating_hours_per_day * 60
    - downtime_minutes = sum of downtime minutes occurring on that date
    - utilization_rate = min(1.0, active_charging_minutes / available_connector_minutes)
    - operating_profit_inr = charging_revenue_inr - electricity_cost_inr - staff_cost_inr - rent_cost_inr - maintenance_cost_inr - other_operating_cost_inr
    """
    station_map = {s["station_id"]: s for s in stations}

    # Group sessions by (station_id, date)
    sessions_by_st_date = {}
    for s in sessions:
        st_id = s["station_id"]
        d_str = s["session_start"].split(" ")[0]
        key = (st_id, d_str)
        if key not in sessions_by_st_date:
            sessions_by_st_date[key] = []
        sessions_by_st_date[key].append(s)

    # Group downtime by (station_id, date)
    downtime_by_st_date = {}
    for d in downtime_records:
        st_id = d["station_id"]
        d_str = d["downtime_start"].split(" ")[0]
        key = (st_id, d_str)
        downtime_by_st_date[key] = downtime_by_st_date.get(key, 0) + d["downtime_duration_minutes"]

    # Map daily costs by (station_id, date)
    cost_map = {(c["station_id"], c["operating_date"]): c for c in daily_costs}

    kpi_records = []
    # Build for all 10 stations and 182 days
    for current_day_idx in range(TOTAL_DAYS):
        sim_date = START_DATE + timedelta(days=current_day_idx)
        date_str = sim_date.strftime("%Y-%m-%d")

        for st in stations:
            st_id = st["station_id"]
            key = (st_id, date_str)
            st_sessions = sessions_by_st_date.get(key, [])
            dt_mins = downtime_by_st_date.get(key, 0)
            cost_info = cost_map.get(key, {})

            tot_sessions = len(st_sessions)
            comp_sessions = sum(1 for s in st_sessions if s["session_status"] == "Completed")
            fail_sessions = sum(1 for s in st_sessions if s["session_status"] == "Failed")
            energy_kwh = round(sum(s["energy_delivered_kwh"] for s in st_sessions), 2)
            revenue_inr = round(sum(s["charging_revenue_inr"] for s in st_sessions), 2)
            elec_cost_inr = round(sum(s["energy_delivered_kwh"] * s["electricity_tariff_per_kwh_inr"] for s in st_sessions), 2)

            avail_mins = st["total_connectors"] * st["operating_hours_per_day"] * 60
            active_charging_mins = sum(s["charging_duration_minutes"] for s in st_sessions if s["session_status"] == "Completed")

            # Utilization rate based on active charging minutes over available minutes
            utilization_rate = round(min(1.0, active_charging_mins / avail_mins), 4)

            # Operating expenses
            staff_cost = cost_info.get("staff_cost_inr", 0.0)
            rent_cost = cost_info.get("rent_cost_inr", 0.0)
            maint_cost = cost_info.get("maintenance_cost_inr", 0.0)
            other_cost = cost_info.get("other_operating_cost_inr", 0.0)

            op_profit = round(revenue_inr - elec_cost_inr - staff_cost - rent_cost - maint_cost - other_cost, 2)

            kpi_records.append({
                "operating_date": date_str,
                "station_id": st_id,
                "total_sessions": tot_sessions,
                "completed_sessions": comp_sessions,
                "failed_sessions": fail_sessions,
                "energy_delivered_kwh": energy_kwh,
                "charging_revenue_inr": revenue_inr,
                "electricity_cost_inr": elec_cost_inr,
                "available_connector_minutes": avail_mins,
                "downtime_minutes": dt_mins,
                "utilization_rate": utilization_rate,
                "operating_profit_inr": op_profit
            })

    filepath = os.path.join(RAW_DATA_DIR, "station_daily_kpis.csv")
    fields = [
        "operating_date", "station_id", "total_sessions", "completed_sessions",
        "failed_sessions", "energy_delivered_kwh", "charging_revenue_inr",
        "electricity_cost_inr", "available_connector_minutes", "downtime_minutes",
        "utilization_rate", "operating_profit_inr"
    ]
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(kpi_records)

    # Also copy to processed directory
    processed_filepath = os.path.join(PROCESSED_DATA_DIR, "station_daily_kpis.csv")
    with open(processed_filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(kpi_records)

    print(f"[7/7] Generated station_daily_kpis.csv: {len(kpi_records)} records.")
    return kpi_records


def main():
    print("================================================================================")
    print("EV Charging Analytics - Master Synthetic Dataset Generation")
    print(f"Period: {START_DATE} to {END_DATE} ({TOTAL_DAYS} days) | Random Seed: {RANDOM_SEED}")
    print("================================================================================")
    stations = generate_stations()
    connectors = generate_connectors(stations)
    tariffs = generate_tariff_history(connectors)
    downtime_records, booked_downtime = generate_downtime(connectors, stations)
    sessions = generate_charging_sessions(connectors, stations, tariffs, booked_downtime)
    daily_costs = generate_daily_costs(stations, sessions, downtime_records)
    kpis = generate_station_daily_kpis(stations, sessions, downtime_records, daily_costs)
    print("================================================================================")
    print("All synthetic datasets generated successfully in data/raw/ and data/processed/!")
    print("================================================================================")


if __name__ == "__main__":
    main()
