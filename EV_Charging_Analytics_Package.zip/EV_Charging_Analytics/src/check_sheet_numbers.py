import pandas as pd

sd = pd.read_csv('EV_Charging_Analytics/data/tableau/tableau_station_daily.csv')
sf = pd.read_csv('EV_Charging_Analytics/data/tableau/tableau_sessions_flat.csv')

print('--- SHEET 3: STATIONS ---')
st_agg = sd.groupby('station_name').agg({'billed_revenue_inr': 'sum', 'net_profit_inr': 'sum'}).reset_index()
st_agg['margin_pct'] = st_agg['net_profit_inr'] / st_agg['billed_revenue_inr']
st_agg = st_agg.sort_values(by='billed_revenue_inr', ascending=False)
for _, r in st_agg.iterrows():
    m = r['margin_pct']
    print(f"{r['station_name']:<35} Rev: Rs {r['billed_revenue_inr']/1e5:5.1f}L  Profit: Rs {r['net_profit_inr']/1e5:5.2f}L  Margin: {m:+6.1%}")

print('\n--- SHEET 4: CHARGER CLASS ---')
cc = sf.groupby('charger_class').agg({'billed_revenue_inr': 'sum', 'completed_flag': 'sum', 'session_id': 'count'}).reset_index()
cc['success_rate_pct'] = cc['completed_flag'] / cc['session_id']
cc = cc.sort_values(by='billed_revenue_inr', ascending=False)
for _, r in cc.iterrows():
    sr = r['success_rate_pct']
    print(f"{r['charger_class']:<25} Rev: Rs {r['billed_revenue_inr']/1e5:5.1f}L  Sessions: {r['session_id']:5d}  Success Rate: {sr:5.1%}")

print('\n--- SHEET 6: WEATHER ---')
w = sf.groupby('weather_condition').agg({'billed_revenue_inr': 'sum', 'failed_flag': 'sum', 'session_id': 'count'}).reset_index()
w['fail_rate_pct'] = w['failed_flag'] / w['session_id']
w = w.sort_values(by='billed_revenue_inr', ascending=False)
for _, r in w.iterrows():
    fr = r['fail_rate_pct']
    print(f"{r['weather_condition']:<15} Rev: Rs {r['billed_revenue_inr']/1e5:5.1f}L  Sessions: {r['session_id']:5d}  Failure Rate: {fr:5.1%}")

print('\n--- SHEET 2: MONTHLY TREND ---')
m = sd.groupby('month').agg({'billed_revenue_inr': 'sum', 'net_profit_inr': 'sum', 'energy_delivered_kwh': 'sum', 'sessions': 'sum'}).reset_index()
m['margin_pct'] = m['net_profit_inr'] / m['billed_revenue_inr']
for _, r in m.iterrows():
    mp = r['margin_pct']
    print(f"{r['month']} Rev: Rs {r['billed_revenue_inr']/1e5:5.1f}L  Profit: Rs {r['net_profit_inr']/1e5:5.2f}L  Margin: {mp:+5.1%}  Energy: {r['energy_delivered_kwh']:8.1f} kWh  Sessions: {r['sessions']:5d}")

