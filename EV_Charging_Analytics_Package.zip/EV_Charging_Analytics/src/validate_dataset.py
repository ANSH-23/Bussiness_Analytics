"""
EV Charging Station Analytics - Automated Data Quality Validation Script
Author: Senior QA Engineer & Database Architect
Description:
    Performs comprehensive data quality, relational integrity, timestamp consistency,
    financial reconciliation, and operational overlap validation checks on all generated datasets.
    Generates:
    - output/data_quality_report.txt
    - output/data_quality_summary.csv
    Exits with code 0 if all critical checks pass, or 1 if any critical test fails.
"""

import os
import sys
import csv
from datetime import datetime, date
import calendar

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RAW_DATA_DIR = os.path.join(BASE_DIR, "data", "raw")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")

os.makedirs(OUTPUT_DIR, exist_ok=True)


def load_csv(filename):
    path = os.path.join(RAW_DATA_DIR, filename)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Missing required file: {filename}")
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader), reader.fieldnames


def main():
    report_lines = []
    summary_rows = []

    def log(msg=""):
        print(msg)
        report_lines.append(msg)

    def record_check(test_id, category, description, status, details=""):
        summary_rows.append({
            "test_id": test_id,
            "category": category,
            "description": description,
            "status": status,
            "details": details
        })
        log(f"[{status}] {test_id} - {category}: {description} {details}")

    log("=" * 80)
    log("EV CHARGING STATION ANALYTICS - AUTOMATED DATA QUALITY AUDIT REPORT")
    log(f"Execution Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log("=" * 80)

    critical_failures = 0

    # --------------------------------------------------------------------------
    # 1. FILE EXISTENCE & SCHEMA CHECKS
    # --------------------------------------------------------------------------
    expected_files = {
        "stations.csv": [
            "station_id", "station_name", "city", "area", "latitude", "longitude",
            "installation_date", "total_connectors", "station_type",
            "monthly_rent_inr", "maintenance_cost_monthly_inr", "operating_hours_per_day"
        ],
        "connectors.csv": [
            "connector_id", "station_id", "connector_type", "rated_power_kw",
            "installation_date", "connector_status", "electricity_tariff_per_kwh_inr"
        ],
        "tariff_history.csv": [
            "tariff_id", "connector_id", "effective_from", "effective_to",
            "electricity_tariff_per_kwh_inr", "customer_price_per_kwh_inr"
        ],
        "station_downtime.csv": [
            "downtime_id", "connector_id", "station_id", "downtime_start",
            "downtime_end", "downtime_duration_minutes", "downtime_reason",
            "maintenance_type", "maintenance_cost_inr"
        ],
        "charging_sessions.csv": [
            "session_id", "connector_id", "station_id", "vehicle_id",
            "session_start", "session_end", "energy_delivered_kwh",
            "charging_duration_minutes", "idle_duration_minutes",
            "electricity_tariff_per_kwh_inr",
            "charging_revenue_inr", "session_status", "payment_status",
            "day_type", "weather_condition"
        ],
        "daily_station_operating_costs.csv": [
            "record_id", "station_id", "operating_date", "electricity_cost_inr",
            "staff_cost_inr", "rent_cost_inr", "maintenance_cost_inr", "other_operating_cost_inr"
        ],
        "station_daily_kpis.csv": [
            "operating_date", "station_id", "total_sessions", "completed_sessions",
            "failed_sessions", "energy_delivered_kwh", "charging_revenue_inr",
            "electricity_cost_inr", "available_connector_minutes", "downtime_minutes",
            "utilization_rate", "operating_profit_inr"
        ]
    }

    datasets = {}
    test_num = 1

    for fname, cols in expected_files.items():
        t_id = f"CHK_{test_num:03d}"
        test_num += 1
        try:
            data, actual_cols = load_csv(fname)
            datasets[fname] = data
            missing_cols = set(cols) - set(actual_cols)
            if missing_cols:
                record_check(t_id, "Schema", f"{fname} column verification", "FAIL", f"Missing cols: {missing_cols}")
                critical_failures += 1
            else:
                record_check(t_id, "Schema", f"{fname} column verification", "PASS", f"All {len(cols)} columns present")
        except Exception as e:
            record_check(t_id, "Schema", f"{fname} file availability", "FAIL", str(e))
            critical_failures += 1

    stations = datasets.get("stations.csv", [])
    connectors = datasets.get("connectors.csv", [])
    tariffs = datasets.get("tariff_history.csv", [])
    downtime = datasets.get("station_downtime.csv", [])
    sessions = datasets.get("charging_sessions.csv", [])
    daily_costs = datasets.get("daily_station_operating_costs.csv", [])
    daily_kpis = datasets.get("station_daily_kpis.csv", [])

    # --------------------------------------------------------------------------
    # 2. ROW COUNT & SCOPE CHECKS
    # --------------------------------------------------------------------------
    log("\n--- Row Counts and Master Scope Verification ---")
    record_check("CHK_008", "Scope", "Station count check", "PASS" if len(stations) == 10 else "FAIL", f"Count: {len(stations)} (Expected: 10)")
    if len(stations) != 10: critical_failures += 1

    record_check("CHK_009", "Scope", "Connector count check", "PASS" if len(connectors) == 50 else "FAIL", f"Count: {len(connectors)} (Expected: 50)")
    if len(connectors) != 50: critical_failures += 1

    record_check("CHK_010", "Scope", "Charging sessions volume check", "PASS" if len(sessions) >= 5000 else "FAIL", f"Count: {len(sessions)} (Requirement: >= 5,000)")
    if len(sessions) < 5000: critical_failures += 1

    record_check("CHK_011", "Scope", "Daily cost records check", "PASS" if len(daily_costs) in (1820, 1830) else "FAIL", f"Count: {len(daily_costs)} (10 stations * {len(daily_costs)//10} days)")
    if len(daily_costs) not in (1820, 1830): critical_failures += 1

    # Total connectors in stations master vs connectors table
    st_sum_connectors = sum(int(s["total_connectors"]) for s in stations)
    record_check("CHK_012", "Integrity", "Station connector count reconciliation", "PASS" if st_sum_connectors == len(connectors) else "FAIL", f"Stations table: {st_sum_connectors}, Connectors table: {len(connectors)}")
    if st_sum_connectors != len(connectors): critical_failures += 1

    # --------------------------------------------------------------------------
    # 3. PRIMARY KEY UNIQUENESS & NULL CHECKS
    # --------------------------------------------------------------------------
    log("\n--- Primary Key Uniqueness & Null Checks ---")
    pk_map = [
        ("stations.csv", stations, "station_id"),
        ("connectors.csv", connectors, "connector_id"),
        ("tariff_history.csv", tariffs, "tariff_id"),
        ("station_downtime.csv", downtime, "downtime_id"),
        ("charging_sessions.csv", sessions, "session_id"),
        ("daily_station_operating_costs.csv", daily_costs, "record_id"),
    ]

    for fname, data, pk_col in pk_map:
        t_id = f"CHK_{test_num:03d}"
        test_num += 1
        ids = [row[pk_col] for row in data]
        unique_ids = set(ids)
        has_nulls = any(val is None or str(val).strip() == "" for val in ids)

        if len(ids) == len(unique_ids) and not has_nulls:
            record_check(t_id, "Integrity", f"PK {pk_col} uniqueness in {fname}", "PASS", f"Total unique: {len(ids)}")
        else:
            record_check(t_id, "Integrity", f"PK {pk_col} uniqueness in {fname}", "FAIL", f"Duplicates: {len(ids) - len(unique_ids)}, Has Nulls: {has_nulls}")
            critical_failures += 1

    # --------------------------------------------------------------------------
    # 4. FOREIGN KEY INTEGRITY
    # --------------------------------------------------------------------------
    log("\n--- Foreign Key Relational Integrity ---")
    station_ids = {s["station_id"] for s in stations}
    connector_ids = {c["connector_id"] for c in connectors}

    # Connectors -> Stations
    conn_st_orphans = [c["connector_id"] for c in connectors if c["station_id"] not in station_ids]
    record_check("CHK_019", "FK Integrity", "connectors.station_id -> stations.station_id", "PASS" if not conn_st_orphans else "FAIL", f"Orphans: {len(conn_st_orphans)}")
    if conn_st_orphans: critical_failures += 1

    # Tariffs -> Connectors
    tar_conn_orphans = [t["tariff_id"] for t in tariffs if t["connector_id"] not in connector_ids]
    record_check("CHK_020", "FK Integrity", "tariff_history.connector_id -> connectors.connector_id", "PASS" if not tar_conn_orphans else "FAIL", f"Orphans: {len(tar_conn_orphans)}")
    if tar_conn_orphans: critical_failures += 1

    # Downtime -> Connectors & Stations
    dt_conn_orphans = [d["downtime_id"] for d in downtime if d["connector_id"] not in connector_ids]
    dt_st_orphans = [d["downtime_id"] for d in downtime if d["station_id"] not in station_ids]
    record_check("CHK_021", "FK Integrity", "station_downtime foreign keys", "PASS" if not dt_conn_orphans and not dt_st_orphans else "FAIL", f"Conn orphans: {len(dt_conn_orphans)}, Station orphans: {len(dt_st_orphans)}")
    if dt_conn_orphans or dt_st_orphans: critical_failures += 1

    # Sessions -> Connectors & Stations
    ses_conn_orphans = [s["session_id"] for s in sessions if s["connector_id"] not in connector_ids]
    ses_st_orphans = [s["session_id"] for s in sessions if s["station_id"] not in station_ids]
    record_check("CHK_022", "FK Integrity", "charging_sessions foreign keys", "PASS" if not ses_conn_orphans and not ses_st_orphans else "FAIL", f"Conn orphans: {len(ses_conn_orphans)}, Station orphans: {len(ses_st_orphans)}")
    if ses_conn_orphans or ses_st_orphans: critical_failures += 1

    # Daily costs -> Stations
    cost_st_orphans = [c["record_id"] for c in daily_costs if c["station_id"] not in station_ids]
    record_check("CHK_023", "FK Integrity", "daily_station_operating_costs.station_id -> stations", "PASS" if not cost_st_orphans else "FAIL", f"Station orphans: {len(cost_st_orphans)}")
    if cost_st_orphans: critical_failures += 1

    # --------------------------------------------------------------------------
    # 5. TIMESTAMP CONSISTENCY & DURATION CHECKS
    # --------------------------------------------------------------------------
    log("\n--- Timestamp Consistency & Duration Validity ---")
    # Sessions: end > start and (end - start) == charging_duration + idle_duration
    ses_ts_errors = 0
    ses_dur_errors = 0
    for s in sessions:
        st_dt = datetime.strptime(s["session_start"], "%Y-%m-%d %H:%M:%S")
        end_dt = datetime.strptime(s["session_end"], "%Y-%m-%d %H:%M:%S")
        if end_dt <= st_dt:
            ses_ts_errors += 1
        expected_mins = int(s["charging_duration_minutes"]) + int(s["idle_duration_minutes"])
        actual_mins = int((end_dt - st_dt).total_seconds() / 60)
        if expected_mins != actual_mins:
            ses_dur_errors += 1

    record_check("CHK_024", "Timestamps", "Charging session start < end check", "PASS" if ses_ts_errors == 0 else "FAIL", f"Invalid: {ses_ts_errors}")
    if ses_ts_errors > 0: critical_failures += 1

    record_check("CHK_025", "Timestamps", "Charging session duration agreement", "PASS" if ses_dur_errors == 0 else "FAIL", f"Mismatches: {ses_dur_errors}")
    if ses_dur_errors > 0: critical_failures += 1

    # Downtime: end > start and duration matches
    dt_ts_errors = 0
    dt_dur_errors = 0
    for d in downtime:
        st_dt = datetime.strptime(d["downtime_start"], "%Y-%m-%d %H:%M:%S")
        end_dt = datetime.strptime(d["downtime_end"], "%Y-%m-%d %H:%M:%S")
        if end_dt <= st_dt:
            dt_ts_errors += 1
        actual_mins = int((end_dt - st_dt).total_seconds() / 60)
        if actual_mins != int(d["downtime_duration_minutes"]):
            dt_dur_errors += 1

    record_check("CHK_026", "Timestamps", "Downtime start < end check", "PASS" if dt_ts_errors == 0 else "FAIL", f"Invalid: {dt_ts_errors}")
    if dt_ts_errors > 0: critical_failures += 1

    record_check("CHK_027", "Timestamps", "Downtime duration calculation agreement", "PASS" if dt_dur_errors == 0 else "FAIL", f"Mismatches: {dt_dur_errors}")
    if dt_dur_errors > 0: critical_failures += 1

    # --------------------------------------------------------------------------
    # 6. OVERLAP VERIFICATION (CRUCIAL ACADEMIC REQUIREMENT)
    # --------------------------------------------------------------------------
    log("\n--- Connector Schedule Overlap Verification ---")
    # Group sessions by connector
    sessions_by_conn = {}
    for s in sessions:
        c_id = s["connector_id"]
        if c_id not in sessions_by_conn:
            sessions_by_conn[c_id] = []
        st_dt = datetime.strptime(s["session_start"], "%Y-%m-%d %H:%M:%S")
        end_dt = datetime.strptime(s["session_end"], "%Y-%m-%d %H:%M:%S")
        sessions_by_conn[c_id].append((st_dt, end_dt, s["session_id"]))

    session_overlaps = 0
    for c_id, s_list in sessions_by_conn.items():
        s_list.sort(key=lambda x: x[0])
        for i in range(len(s_list) - 1):
            if s_list[i][1] > s_list[i+1][0]:
                session_overlaps += 1

    record_check("CHK_028", "Schedule Integrity", "Session overlap check per connector", "PASS" if session_overlaps == 0 else "FAIL", f"Overlapping session pairs: {session_overlaps}")
    if session_overlaps > 0: critical_failures += 1

    # Group downtime by connector
    downtime_by_conn = {}
    for d in downtime:
        c_id = d["connector_id"]
        if c_id not in downtime_by_conn:
            downtime_by_conn[c_id] = []
        st_dt = datetime.strptime(d["downtime_start"], "%Y-%m-%d %H:%M:%S")
        end_dt = datetime.strptime(d["downtime_end"], "%Y-%m-%d %H:%M:%S")
        downtime_by_conn[c_id].append((st_dt, end_dt, d["downtime_id"]))

    downtime_overlaps = 0
    for c_id, d_list in downtime_by_conn.items():
        d_list.sort(key=lambda x: x[0])
        for i in range(len(d_list) - 1):
            if d_list[i][1] > d_list[i+1][0]:
                downtime_overlaps += 1

    record_check("CHK_029", "Schedule Integrity", "Downtime overlap check per connector", "PASS" if downtime_overlaps == 0 else "FAIL", f"Overlapping downtime pairs: {downtime_overlaps}")
    if downtime_overlaps > 0: critical_failures += 1

    # Cross-check: Session vs Downtime overlap
    ses_dt_overlaps = 0
    for c_id, s_list in sessions_by_conn.items():
        d_list = downtime_by_conn.get(c_id, [])
        for s_start, s_end, s_id in s_list:
            for d_start, d_end, d_id in d_list:
                if not (s_end <= d_start or s_start >= d_end):
                    ses_dt_overlaps += 1

    record_check("CHK_030", "Schedule Integrity", "Session vs Downtime collision check", "PASS" if ses_dt_overlaps == 0 else "FAIL", f"Collisions: {ses_dt_overlaps}")
    if ses_dt_overlaps > 0: critical_failures += 1

    # --------------------------------------------------------------------------
    # 7. FINANCIAL RECONCILIATION CHECKS
    # --------------------------------------------------------------------------
    log("\n--- Financial Reconciliation Verification ---")
    # Revenue reconciliation: completed sessions have positive revenue, non-completed have 0
    rev_mismatches = 0
    for s in sessions:
        rev = float(s["charging_revenue_inr"])
        energy = float(s["energy_delivered_kwh"])
        if s["session_status"] == "Completed":
            if rev <= 0.0 or energy <= 0.0:
                rev_mismatches += 1
        else:
            if rev != 0.0:
                rev_mismatches += 1

    record_check("CHK_031", "Financial", "Session revenue formula reconciliation", "PASS" if rev_mismatches == 0 else "FAIL", f"Mismatches: {rev_mismatches}")
    if rev_mismatches > 0: critical_failures += 1

    # Total sessions electricity cost vs Daily operating costs electricity cost
    total_session_elec_cost = sum(round(float(s["energy_delivered_kwh"]) * float(s["electricity_tariff_per_kwh_inr"]), 2) for s in sessions)
    total_daily_elec_cost = sum(float(c["electricity_cost_inr"]) for c in daily_costs)
    elec_diff = abs(total_session_elec_cost - total_daily_elec_cost)

    record_check("CHK_032", "Financial", "Electricity cost cross-table reconciliation", "PASS" if elec_diff < 10.0 else "FAIL", f"Sessions: INR {total_session_elec_cost:,.2f}, Daily table: INR {total_daily_elec_cost:,.2f} (Diff: INR {elec_diff:.2f})")
    if elec_diff >= 10.0: critical_failures += 1

    # Monthly rent allocation reconciliation
    station_rent_map = {s["station_id"]: float(s["monthly_rent_inr"]) for s in stations}
    months = sorted(list(set(c["operating_date"][:7] for c in daily_costs)))
    monthly_rent_mismatches = 0
    for m_str in months:
        for st_id, expected_rent in station_rent_map.items():
            month_cost_sum = sum(float(c["rent_cost_inr"]) for c in daily_costs if c["station_id"] == st_id and c["operating_date"].startswith(m_str))
            if abs(month_cost_sum - expected_rent) > 0.05:
                monthly_rent_mismatches += 1

    record_check("CHK_033", "Financial", "Monthly rent allocation reconciliation", "PASS" if monthly_rent_mismatches == 0 else "FAIL", f"Mismatches: {monthly_rent_mismatches}")
    if monthly_rent_mismatches > 0: critical_failures += 1

    # Utilization rate bounds (0.0 to 1.0)
    invalid_util = [k for k in daily_kpis if float(k["utilization_rate"]) < 0.0 or float(k["utilization_rate"]) > 1.0]
    record_check("CHK_034", "Operational", "Utilization rate boundary check [0, 1]", "PASS" if not invalid_util else "FAIL", f"Invalid records: {len(invalid_util)}")
    if invalid_util: critical_failures += 1

    # --------------------------------------------------------------------------
    # WRITE REPORTS
    # --------------------------------------------------------------------------
    report_file = os.path.join(OUTPUT_DIR, "data_quality_report.txt")
    with open(report_file, "w", encoding="utf-8") as f:
        f.write("\n".join(report_lines))
        f.write("\n" + "=" * 80 + "\n")
        f.write(f"SUMMARY: Total Tests: {len(summary_rows)} | Critical Failures: {critical_failures}\n")
        f.write("AUDIT STATUS: " + ("PASSED" if critical_failures == 0 else "FAILED") + "\n")
        f.write("=" * 80 + "\n")

    summary_file = os.path.join(OUTPUT_DIR, "data_quality_summary.csv")
    with open(summary_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["test_id", "category", "description", "status", "details"])
        writer.writeheader()
        writer.writerows(summary_rows)

    log("\n" + "=" * 80)
    log(f"DATA QUALITY AUDIT COMPLETE: {len(summary_rows)} Checks Run. Critical Failures: {critical_failures}")
    log(f"Reports saved to: {report_file} and {summary_file}")
    log("=" * 80)

    if critical_failures > 0:
        sys.exit(1)
    else:
        sys.exit(0)


if __name__ == "__main__":
    main()
