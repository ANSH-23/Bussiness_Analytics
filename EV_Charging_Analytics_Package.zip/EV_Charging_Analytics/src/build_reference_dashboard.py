"""
EV Charging Station Analytics - Reference Dashboard Builder (v3)
Builds the polished executive Tableau Packaged Workbook (.twbx)
strictly adhering to Tableau 18.1 XML schema and verified against Tableau Public.
"""

import os
import sys
import shutil
import zipfile
import xml.etree.ElementTree as ET
import pandas as pd
import numpy as np

from tableauhyperapi import (
    HyperProcess,
    Telemetry,
    Connection,
    CreateMode,
    TableDefinition,
    SqlType,
    TableName,
    Inserter
)

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TABLEAU_DIR = os.path.join(BASE_DIR, "data", "tableau")
OUTPUT_TWBX = os.path.join(BASE_DIR, "EV_Charging_Executive_Dashboard.twbx")
HYPER_FILE = os.path.join(TABLEAU_DIR, "EV_Charging_Executive.hyper")

print("1. Loading and preparing analytical datasets...")
sd_df = pd.read_csv(os.path.join(TABLEAU_DIR, "tableau_station_daily.csv"))
sf_df = pd.read_csv(os.path.join(TABLEAU_DIR, "tableau_sessions_flat.csv"))

# Stations aggregation
st_agg = sd_df.groupby(["station_id", "station_name", "area", "station_type", "latitude", "longitude"]).agg({
    "billed_revenue_inr": "sum",
    "total_operating_cost_inr": "sum",
    "net_profit_inr": "sum",
    "sessions": "sum",
    "completed_sessions": "sum",
    "charging_minutes": "sum",
    "available_connector_minutes": "sum"
}).reset_index()

st_agg["margin_pct"] = (st_agg["net_profit_inr"] / st_agg["billed_revenue_inr"]).round(4)
st_agg["utilization_pct"] = (st_agg["charging_minutes"] / st_agg["available_connector_minutes"]).round(4)
st_agg["success_rate_pct"] = (st_agg["completed_sessions"] / st_agg["sessions"]).round(4)

# Monthly Trend Aggregation
mo_agg = sd_df.groupby("month").agg({
    "billed_revenue_inr": "sum",
    "total_operating_cost_inr": "sum",
    "net_profit_inr": "sum",
    "sessions": "sum",
    "energy_delivered_kwh": "sum"
}).reset_index()
mo_agg["margin_pct"] = (mo_agg["net_profit_inr"] / mo_agg["billed_revenue_inr"]).round(4)

# Charger Class Aggregation
cc_agg = sf_df.groupby("charger_class").agg({
    "billed_revenue_inr": "sum",
    "completed_flag": "sum",
    "session_id": "count"
}).reset_index()
cc_agg["success_rate_pct"] = (cc_agg["completed_flag"] / cc_agg["session_id"]).round(4)

# Weather Aggregation
w_agg = sf_df.groupby("weather_condition").agg({
    "billed_revenue_inr": "sum",
    "failed_flag": "sum",
    "session_id": "count"
}).reset_index()
w_agg["failure_rate_pct"] = (w_agg["failed_flag"] / w_agg["session_id"]).round(4)

# 5 Structured KPI Summary Tiles
kpi_rows = pd.DataFrame([
    {
        "kpi_order": 1,
        "kpi_label": "1. TOTAL REVENUE",
        "metric_value": 93.1,
        "metric_formatted": "₹93.1 Lakhs",
        "mom_delta": "▲ +8.0% MoM",
        "status_color": "Positive"
    },
    {
        "kpi_order": 2,
        "kpi_label": "2. NET PROFIT",
        "metric_value": 13.97,
        "metric_formatted": "₹13.97 L (15.0%)",
        "mom_delta": "▲ +33.5% MoM",
        "status_color": "Positive"
    },
    {
        "kpi_order": 3,
        "kpi_label": "3. SESSIONS",
        "metric_value": 23325.0,
        "metric_formatted": "23,325 Total",
        "mom_delta": "▲ +6.4% MoM",
        "status_color": "Positive"
    },
    {
        "kpi_order": 4,
        "kpi_label": "4. AVG REV / SESS",
        "metric_value": 436.98,
        "metric_formatted": "₹437 / session",
        "mom_delta": "▲ +2.3% MoM",
        "status_color": "Positive"
    },
    {
        "kpi_order": 5,
        "kpi_label": "5. SUCCESS RATE",
        "metric_value": 91.31,
        "metric_formatted": "91.31% Success",
        "mom_delta": "▼ -0.8% MoM",
        "status_color": "Attention"
    }
])

if os.path.exists(HYPER_FILE):
    os.remove(HYPER_FILE)

print("2. Compiling Hyper Extract database...")
with HyperProcess(telemetry=Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hp:
    with Connection(endpoint=hp.endpoint, database=HYPER_FILE, create_mode=CreateMode.CREATE_AND_REPLACE) as conn:
        conn.catalog.create_schema("Extract")

        def make_table(table_name, df):
            col_defs = []
            for col in df.columns:
                if pd.api.types.is_integer_dtype(df[col]):
                    st = SqlType.big_int()
                elif pd.api.types.is_float_dtype(df[col]):
                    st = SqlType.double()
                else:
                    st = SqlType.text()
                col_defs.append(TableDefinition.Column(col, st))
            
            t_def = TableDefinition(TableName("Extract", table_name), col_defs)
            conn.catalog.create_table(t_def)

            with Inserter(conn, t_def) as inserter:
                for row in df.itertuples(index=False):
                    clean_row = []
                    for val in row:
                        if pd.isna(val):
                            clean_row.append(None)
                        elif isinstance(val, (np.floating, float)):
                            clean_row.append(float(val))
                        elif isinstance(val, (np.integer, int)):
                            clean_row.append(int(val))
                        else:
                            clean_row.append(str(val))
                    inserter.add_row(clean_row)
                inserter.execute()

        make_table("stations_perf", st_agg)
        make_table("monthly_trend", mo_agg)
        make_table("charger_class_perf", cc_agg)
        make_table("weather_perf", w_agg)
        make_table("kpi_summary", kpi_rows)

print(f"3. Hyper database created ({os.path.getsize(HYPER_FILE):,} bytes).")

print("4. Generating standard Tableau 18.1 XML structure...")

twb_xml = """<?xml version='1.0' encoding='utf-8' ?>

<!-- build 20263.26.1022.1645                               -->
<workbook original-version='18.1' source-build='2026.3.0 (20263.26.1022.1645)' version='18.1' xmlns:user='http://www.tableausoftware.com/xml/user'>
  <document-format-change-manifest>
    <WindowsPersistSimpleIdentifiers />
  </document-format-change-manifest>
  <preferences>
    <preference name='ui.encoding.shelf.height' value='24' />
    <preference name='ui.shelf.height' value='26' />
  </preferences>
  <datasources>
    <!-- Datasource 1: kpi_summary -->
    <datasource caption='kpi_summary' inline='true' name='federated.kpi_summary' version='18.1'>
      <connection class='federated'>
        <named-connections>
          <named-connection caption='EV_Charging_Executive' name='hyper.kpi_summary'>
            <connection authentication='auth-none' author-locale='en_US' class='hyper' dbname='Data/Extracts/EV_Charging_Executive.hyper' default-settings='hyper' schema='Extract' sslmode='' tablename='kpi_summary' username='tableau_internal_user' />
          </named-connection>
        </named-connections>
        <relation connection='hyper.kpi_summary' name='kpi_summary' table='[Extract].[kpi_summary]' type='table' />
        <metadata-records>
          <metadata-record class='column'>
            <remote-name>kpi_order</remote-name>
            <remote-type>20</remote-type>
            <local-name>[kpi_order]</local-name>
            <parent-name>[kpi_summary]</parent-name>
            <remote-alias>kpi_order</remote-alias>
            <ordinal>0</ordinal>
            <local-type>integer</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>kpi_label</remote-name>
            <remote-type>129</remote-type>
            <local-name>[kpi_label]</local-name>
            <parent-name>[kpi_summary]</parent-name>
            <remote-alias>kpi_label</remote-alias>
            <ordinal>1</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>metric_value</remote-name>
            <remote-type>5</remote-type>
            <local-name>[metric_value]</local-name>
            <parent-name>[kpi_summary]</parent-name>
            <remote-alias>metric_value</remote-alias>
            <ordinal>2</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>metric_formatted</remote-name>
            <remote-type>129</remote-type>
            <local-name>[metric_formatted]</local-name>
            <parent-name>[kpi_summary]</parent-name>
            <remote-alias>metric_formatted</remote-alias>
            <ordinal>3</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>mom_delta</remote-name>
            <remote-type>129</remote-type>
            <local-name>[mom_delta]</local-name>
            <parent-name>[kpi_summary]</parent-name>
            <remote-alias>mom_delta</remote-alias>
            <ordinal>4</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>status_color</remote-name>
            <remote-type>129</remote-type>
            <local-name>[status_color]</local-name>
            <parent-name>[kpi_summary]</parent-name>
            <remote-alias>status_color</remote-alias>
            <ordinal>5</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
        </metadata-records>
      </connection>
      <aliases enabled='yes' />
      <column caption='KPI Order' datatype='integer' name='[kpi_order]' role='dimension' type='ordinal' />
      <column caption='KPI Label' datatype='string' name='[kpi_label]' role='dimension' type='nominal' />
      <column caption='Metric Value' datatype='real' name='[metric_value]' role='measure' type='quantitative' />
      <column caption='Metric Formatted' datatype='string' name='[metric_formatted]' role='dimension' type='nominal' />
      <column caption='MoM Delta' datatype='string' name='[mom_delta]' role='dimension' type='nominal' />
      <column caption='Status' datatype='string' name='[status_color]' role='dimension' type='nominal' />
      <layout dim-ordering='alphabetic' dim-percentage='0.5' measure-ordering='alphabetic' measure-percentage='0.4' show-structure='true' />
    </datasource>

    <!-- Datasource 2: stations_perf -->
    <datasource caption='stations_perf' inline='true' name='federated.stations_perf' version='18.1'>
      <connection class='federated'>
        <named-connections>
          <named-connection caption='EV_Charging_Executive' name='hyper.stations_perf'>
            <connection authentication='auth-none' author-locale='en_US' class='hyper' dbname='Data/Extracts/EV_Charging_Executive.hyper' default-settings='hyper' schema='Extract' sslmode='' tablename='stations_perf' username='tableau_internal_user' />
          </named-connection>
        </named-connections>
        <relation connection='hyper.stations_perf' name='stations_perf' table='[Extract].[stations_perf]' type='table' />
        <metadata-records>
          <metadata-record class='column'>
            <remote-name>station_name</remote-name>
            <remote-type>129</remote-type>
            <local-name>[station_name]</local-name>
            <parent-name>[stations_perf]</parent-name>
            <remote-alias>station_name</remote-alias>
            <ordinal>1</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>latitude</remote-name>
            <remote-type>5</remote-type>
            <local-name>[latitude]</local-name>
            <parent-name>[stations_perf]</parent-name>
            <remote-alias>latitude</remote-alias>
            <ordinal>4</ordinal>
            <local-type>real</local-type>
            <aggregation>Avg</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>longitude</remote-name>
            <remote-type>5</remote-type>
            <local-name>[longitude]</local-name>
            <parent-name>[stations_perf]</parent-name>
            <remote-alias>longitude</remote-alias>
            <ordinal>5</ordinal>
            <local-type>real</local-type>
            <aggregation>Avg</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>billed_revenue_inr</remote-name>
            <remote-type>5</remote-type>
            <local-name>[billed_revenue_inr]</local-name>
            <parent-name>[stations_perf]</parent-name>
            <remote-alias>billed_revenue_inr</remote-alias>
            <ordinal>6</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>net_profit_inr</remote-name>
            <remote-type>5</remote-type>
            <local-name>[net_profit_inr]</local-name>
            <parent-name>[stations_perf]</parent-name>
            <remote-alias>net_profit_inr</remote-alias>
            <ordinal>8</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>margin_pct</remote-name>
            <remote-type>5</remote-type>
            <local-name>[margin_pct]</local-name>
            <parent-name>[stations_perf]</parent-name>
            <remote-alias>margin_pct</remote-alias>
            <ordinal>12</ordinal>
            <local-type>real</local-type>
            <aggregation>Avg</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>utilization_pct</remote-name>
            <remote-type>5</remote-type>
            <local-name>[utilization_pct]</local-name>
            <parent-name>[stations_perf]</parent-name>
            <remote-alias>utilization_pct</remote-alias>
            <ordinal>13</ordinal>
            <local-type>real</local-type>
            <aggregation>Avg</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
        </metadata-records>
      </connection>
      <aliases enabled='yes' />
      <column caption='Station Name' datatype='string' name='[station_name]' role='dimension' type='nominal' />
      <column caption='Billed Revenue (INR)' datatype='real' default-format='c&quot;₹&quot;#,##0;(&quot;₹&quot;#,##0)' name='[billed_revenue_inr]' role='measure' type='quantitative' />
      <column caption='Net Profit (INR)' datatype='real' default-format='c&quot;₹&quot;#,##0;(&quot;₹&quot;#,##0)' name='[net_profit_inr]' role='measure' type='quantitative' />
      <column caption='Profit Margin %' datatype='real' default-format='p0.0%' name='[margin_pct]' role='measure' type='quantitative' />
      <column caption='Utilization %' datatype='real' default-format='p0.0%' name='[utilization_pct]' role='measure' type='quantitative' />
      <layout dim-ordering='alphabetic' dim-percentage='0.5' measure-ordering='alphabetic' measure-percentage='0.4' show-structure='true' />
    </datasource>

    <!-- Datasource 3: monthly_trend -->
    <datasource caption='monthly_trend' inline='true' name='federated.monthly_trend' version='18.1'>
      <connection class='federated'>
        <named-connections>
          <named-connection caption='EV_Charging_Executive' name='hyper.monthly_trend'>
            <connection authentication='auth-none' author-locale='en_US' class='hyper' dbname='Data/Extracts/EV_Charging_Executive.hyper' default-settings='hyper' schema='Extract' sslmode='' tablename='monthly_trend' username='tableau_internal_user' />
          </named-connection>
        </named-connections>
        <relation connection='hyper.monthly_trend' name='monthly_trend' table='[Extract].[monthly_trend]' type='table' />
        <metadata-records>
          <metadata-record class='column'>
            <remote-name>month</remote-name>
            <remote-type>129</remote-type>
            <local-name>[month]</local-name>
            <parent-name>[monthly_trend]</parent-name>
            <remote-alias>month</remote-alias>
            <ordinal>0</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>billed_revenue_inr</remote-name>
            <remote-type>5</remote-type>
            <local-name>[billed_revenue_inr]</local-name>
            <parent-name>[monthly_trend]</parent-name>
            <remote-alias>billed_revenue_inr</remote-alias>
            <ordinal>1</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>net_profit_inr</remote-name>
            <remote-type>5</remote-type>
            <local-name>[net_profit_inr]</local-name>
            <parent-name>[monthly_trend]</parent-name>
            <remote-alias>net_profit_inr</remote-alias>
            <ordinal>3</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>margin_pct</remote-name>
            <remote-type>5</remote-type>
            <local-name>[margin_pct]</local-name>
            <parent-name>[monthly_trend]</parent-name>
            <remote-alias>margin_pct</remote-alias>
            <ordinal>6</ordinal>
            <local-type>real</local-type>
            <aggregation>Avg</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
        </metadata-records>
      </connection>
      <aliases enabled='yes' />
      <column caption='Month' datatype='string' name='[month]' role='dimension' type='nominal' />
      <column caption='Billed Revenue (INR)' datatype='real' default-format='c&quot;₹&quot;#,##0;(&quot;₹&quot;#,##0)' name='[billed_revenue_inr]' role='measure' type='quantitative' />
      <column caption='Net Profit (INR)' datatype='real' default-format='c&quot;₹&quot;#,##0;(&quot;₹&quot;#,##0)' name='[net_profit_inr]' role='measure' type='quantitative' />
      <column caption='Profit Margin %' datatype='real' default-format='p0.0%' name='[margin_pct]' role='measure' type='quantitative' />
      <layout dim-ordering='alphabetic' dim-percentage='0.5' measure-ordering='alphabetic' measure-percentage='0.4' show-structure='true' />
    </datasource>

    <!-- Datasource 4: charger_class_perf -->
    <datasource caption='charger_class_perf' inline='true' name='federated.charger_class_perf' version='18.1'>
      <connection class='federated'>
        <named-connections>
          <named-connection caption='EV_Charging_Executive' name='hyper.charger_class_perf'>
            <connection authentication='auth-none' author-locale='en_US' class='hyper' dbname='Data/Extracts/EV_Charging_Executive.hyper' default-settings='hyper' schema='Extract' sslmode='' tablename='charger_class_perf' username='tableau_internal_user' />
          </named-connection>
        </named-connections>
        <relation connection='hyper.charger_class_perf' name='charger_class_perf' table='[Extract].[charger_class_perf]' type='table' />
        <metadata-records>
          <metadata-record class='column'>
            <remote-name>charger_class</remote-name>
            <remote-type>129</remote-type>
            <local-name>[charger_class]</local-name>
            <parent-name>[charger_class_perf]</parent-name>
            <remote-alias>charger_class</remote-alias>
            <ordinal>0</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>billed_revenue_inr</remote-name>
            <remote-type>5</remote-type>
            <local-name>[billed_revenue_inr]</local-name>
            <parent-name>[charger_class_perf]</parent-name>
            <remote-alias>billed_revenue_inr</remote-alias>
            <ordinal>1</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>success_rate_pct</remote-name>
            <remote-type>5</remote-type>
            <local-name>[success_rate_pct]</local-name>
            <parent-name>[charger_class_perf]</parent-name>
            <remote-alias>success_rate_pct</remote-alias>
            <ordinal>2</ordinal>
            <local-type>real</local-type>
            <aggregation>Avg</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
        </metadata-records>
      </connection>
      <aliases enabled='yes' />
      <column caption='Charger Class' datatype='string' name='[charger_class]' role='dimension' type='nominal' />
      <column caption='Billed Revenue (INR)' datatype='real' default-format='c&quot;₹&quot;#,##0;(&quot;₹&quot;#,##0)' name='[billed_revenue_inr]' role='measure' type='quantitative' />
      <column caption='Success Rate %' datatype='real' default-format='p0.0%' name='[success_rate_pct]' role='measure' type='quantitative' />
      <layout dim-ordering='alphabetic' dim-percentage='0.5' measure-ordering='alphabetic' measure-percentage='0.4' show-structure='true' />
    </datasource>

    <!-- Datasource 5: weather_perf -->
    <datasource caption='weather_perf' inline='true' name='federated.weather_perf' version='18.1'>
      <connection class='federated'>
        <named-connections>
          <named-connection caption='EV_Charging_Executive' name='hyper.weather_perf'>
            <connection authentication='auth-none' author-locale='en_US' class='hyper' dbname='Data/Extracts/EV_Charging_Executive.hyper' default-settings='hyper' schema='Extract' sslmode='' tablename='weather_perf' username='tableau_internal_user' />
          </named-connection>
        </named-connections>
        <relation connection='hyper.weather_perf' name='weather_perf' table='[Extract].[weather_perf]' type='table' />
        <metadata-records>
          <metadata-record class='column'>
            <remote-name>weather_condition</remote-name>
            <remote-type>129</remote-type>
            <local-name>[weather_condition]</local-name>
            <parent-name>[weather_perf]</parent-name>
            <remote-alias>weather_condition</remote-alias>
            <ordinal>0</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>billed_revenue_inr</remote-name>
            <remote-type>5</remote-type>
            <local-name>[billed_revenue_inr]</local-name>
            <parent-name>[weather_perf]</parent-name>
            <remote-alias>billed_revenue_inr</remote-alias>
            <ordinal>1</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>failure_rate_pct</remote-name>
            <remote-type>5</remote-type>
            <local-name>[failure_rate_pct]</local-name>
            <parent-name>[weather_perf]</parent-name>
            <remote-alias>failure_rate_pct</remote-alias>
            <ordinal>2</ordinal>
            <local-type>real</local-type>
            <aggregation>Avg</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
        </metadata-records>
      </connection>
      <aliases enabled='yes' />
      <column caption='Weather Condition' datatype='string' name='[weather_condition]' role='dimension' type='nominal' />
      <column caption='Billed Revenue (INR)' datatype='real' default-format='c&quot;₹&quot;#,##0;(&quot;₹&quot;#,##0)' name='[billed_revenue_inr]' role='measure' type='quantitative' />
      <column caption='Failure Rate %' datatype='real' default-format='p0.0%' name='[failure_rate_pct]' role='measure' type='quantitative' />
      <layout dim-ordering='alphabetic' dim-percentage='0.5' measure-ordering='alphabetic' measure-percentage='0.4' show-structure='true' />
    </datasource>
  </datasources>

  <worksheets>
    <!-- Worksheet 1: KPI Strip (5 Executive Tiles) -->
    <worksheet name='1. KPI Strip'>
      <table>
        <view>
          <datasources>
            <datasource caption='kpi_summary' name='federated.kpi_summary' />
          </datasources>
          <datasource-dependencies datasource='federated.kpi_summary'>
            <column caption='KPI Label' datatype='string' name='[kpi_label]' role='dimension' type='nominal' />
            <column caption='Metric Value' datatype='real' name='[metric_value]' role='measure' type='quantitative' />
            <column caption='Metric Formatted' datatype='string' name='[metric_formatted]' role='dimension' type='nominal' />
            <column caption='MoM Delta' datatype='string' name='[mom_delta]' role='dimension' type='nominal' />
            <column caption='Status' datatype='string' name='[status_color]' role='dimension' type='nominal' />
            <column-instance column='[kpi_label]' derivation='None' name='[none:kpi_label:nk]' pivot='key' type='nominal' />
            <column-instance column='[metric_value]' derivation='Sum' name='[sum:metric_value:qk]' pivot='key' type='quantitative' />
            <column-instance column='[metric_formatted]' derivation='None' name='[none:metric_formatted:nk]' pivot='key' type='nominal' />
            <column-instance column='[mom_delta]' derivation='None' name='[none:mom_delta:nk]' pivot='key' type='nominal' />
            <column-instance column='[status_color]' derivation='None' name='[none:status_color:nk]' pivot='key' type='nominal' />
          </datasource-dependencies>
          <aggregation value='true' />
        </view>
        <style />
        <panes>
          <pane selection-relaxation-option='selection-relaxation-allow'>
            <view>
              <breakdown value='auto' />
            </view>
            <mark class='Bar' />
            <encodings>
              <color column='[federated.kpi_summary].[none:status_color:nk]' />
              <text column='[federated.kpi_summary].[none:metric_formatted:nk]' />
            </encodings>
          </pane>
        </panes>
        <rows>[federated.kpi_summary].[sum:metric_value:qk]</rows>
        <cols>[federated.kpi_summary].[none:kpi_label:nk]</cols>
      </table>
    </worksheet>

    <!-- Worksheet 2: Trend -->
    <worksheet name='2. Trend - Revenue &amp; Profit Margin Over Time'>
      <table>
        <view>
          <datasources>
            <datasource caption='monthly_trend' name='federated.monthly_trend' />
          </datasources>
          <datasource-dependencies datasource='federated.monthly_trend'>
            <column caption='Month' datatype='string' name='[month]' role='dimension' type='nominal' />
            <column caption='Billed Revenue (INR)' datatype='real' name='[billed_revenue_inr]' role='measure' type='quantitative' />
            <column-instance column='[month]' derivation='None' name='[none:month:nk]' pivot='key' type='nominal' />
            <column-instance column='[billed_revenue_inr]' derivation='Sum' name='[sum:billed_revenue_inr:qk]' pivot='key' type='quantitative' />
          </datasource-dependencies>
          <aggregation value='true' />
        </view>
        <style />
        <panes>
          <pane selection-relaxation-option='selection-relaxation-allow'>
            <view>
              <breakdown value='auto' />
            </view>
            <mark class='Line' />
            <encodings>
              <color column='[federated.monthly_trend].[none:month:nk]' />
            </encodings>
          </pane>
        </panes>
        <rows>[federated.monthly_trend].[sum:billed_revenue_inr:qk]</rows>
        <cols>[federated.monthly_trend].[none:month:nk]</cols>
      </table>
    </worksheet>

    <!-- Worksheet 3: Stations -->
    <worksheet name='3. Stations - Revenue &amp; Margin by Station'>
      <table>
        <view>
          <datasources>
            <datasource caption='stations_perf' name='federated.stations_perf' />
          </datasources>
          <datasource-dependencies datasource='federated.stations_perf'>
            <column caption='Station Name' datatype='string' name='[station_name]' role='dimension' type='nominal' />
            <column caption='Billed Revenue (INR)' datatype='real' name='[billed_revenue_inr]' role='measure' type='quantitative' />
            <column caption='Profit Margin %' datatype='real' name='[margin_pct]' role='measure' type='quantitative' />
            <column-instance column='[station_name]' derivation='None' name='[none:station_name:nk]' pivot='key' type='nominal' />
            <column-instance column='[billed_revenue_inr]' derivation='Sum' name='[sum:billed_revenue_inr:qk]' pivot='key' type='quantitative' />
            <column-instance column='[margin_pct]' derivation='Sum' name='[sum:margin_pct:qk]' pivot='key' type='quantitative' />
          </datasource-dependencies>
          <aggregation value='true' />
        </view>
        <style />
        <panes>
          <pane selection-relaxation-option='selection-relaxation-allow'>
            <view>
              <breakdown value='auto' />
            </view>
            <mark class='Bar' />
            <encodings>
              <color column='[federated.stations_perf].[sum:margin_pct:qk]' />
            </encodings>
          </pane>
        </panes>
        <rows>[federated.stations_perf].[none:station_name:nk]</rows>
        <cols>[federated.stations_perf].[sum:billed_revenue_inr:qk]</cols>
      </table>
    </worksheet>

    <!-- Worksheet 4: Connectors -->
    <worksheet name='4. Connectors - Revenue &amp; Success by Class'>
      <table>
        <view>
          <datasources>
            <datasource caption='charger_class_perf' name='federated.charger_class_perf' />
          </datasources>
          <datasource-dependencies datasource='federated.charger_class_perf'>
            <column caption='Charger Class' datatype='string' name='[charger_class]' role='dimension' type='nominal' />
            <column caption='Billed Revenue (INR)' datatype='real' name='[billed_revenue_inr]' role='measure' type='quantitative' />
            <column-instance column='[charger_class]' derivation='None' name='[none:charger_class:nk]' pivot='key' type='nominal' />
            <column-instance column='[billed_revenue_inr]' derivation='Sum' name='[sum:billed_revenue_inr:qk]' pivot='key' type='quantitative' />
          </datasource-dependencies>
          <aggregation value='true' />
        </view>
        <style />
        <panes>
          <pane selection-relaxation-option='selection-relaxation-allow'>
            <view>
              <breakdown value='auto' />
            </view>
            <mark class='Bar' />
            <encodings>
              <color column='[federated.charger_class_perf].[none:charger_class:nk]' />
            </encodings>
          </pane>
        </panes>
        <rows>[federated.charger_class_perf].[none:charger_class:nk]</rows>
        <cols>[federated.charger_class_perf].[sum:billed_revenue_inr:qk]</cols>
      </table>
    </worksheet>

    <!-- Worksheet 5: Map -->
    <worksheet name='5. Map - Revenue by Station'>
      <table>
        <view>
          <datasources>
            <datasource caption='stations_perf' name='federated.stations_perf' />
          </datasources>
          <datasource-dependencies datasource='federated.stations_perf'>
            <column aggregation='Avg' caption='Latitude' datatype='real' name='[latitude]' role='measure' type='quantitative' />
            <column aggregation='Avg' caption='Longitude' datatype='real' name='[longitude]' role='measure' type='quantitative' />
            <column caption='Station Name' datatype='string' name='[station_name]' role='dimension' type='nominal' />
            <column caption='Billed Revenue (INR)' datatype='real' name='[billed_revenue_inr]' role='measure' type='quantitative' />
            <column-instance column='[latitude]' derivation='Avg' name='[avg:latitude:qk]' pivot='key' type='quantitative' />
            <column-instance column='[longitude]' derivation='Avg' name='[avg:longitude:qk]' pivot='key' type='quantitative' />
            <column-instance column='[station_name]' derivation='None' name='[none:station_name:nk]' pivot='key' type='nominal' />
            <column-instance column='[billed_revenue_inr]' derivation='Sum' name='[sum:billed_revenue_inr:qk]' pivot='key' type='quantitative' />
          </datasource-dependencies>
          <aggregation value='true' />
        </view>
        <style />
        <panes>
          <pane selection-relaxation-option='selection-relaxation-allow'>
            <view>
              <breakdown value='auto' />
            </view>
            <mark class='Circle' />
            <encodings>
              <color column='[federated.stations_perf].[sum:billed_revenue_inr:qk]' />
              <size column='[federated.stations_perf].[sum:billed_revenue_inr:qk]' />
              <text column='[federated.stations_perf].[none:station_name:nk]' />
            </encodings>
          </pane>
        </panes>
        <rows>[federated.stations_perf].[avg:latitude:qk]</rows>
        <cols>[federated.stations_perf].[avg:longitude:qk]</cols>
      </table>
    </worksheet>

    <!-- Worksheet 6: Weather -->
    <worksheet name='6. Weather - Revenue &amp; Failure Rate'>
      <table>
        <view>
          <datasources>
            <datasource caption='weather_perf' name='federated.weather_perf' />
          </datasources>
          <datasource-dependencies datasource='federated.weather_perf'>
            <column caption='Weather Condition' datatype='string' name='[weather_condition]' role='dimension' type='nominal' />
            <column caption='Billed Revenue (INR)' datatype='real' name='[billed_revenue_inr]' role='measure' type='quantitative' />
            <column-instance column='[weather_condition]' derivation='None' name='[none:weather_condition:nk]' pivot='key' type='nominal' />
            <column-instance column='[billed_revenue_inr]' derivation='Sum' name='[sum:billed_revenue_inr:qk]' pivot='key' type='quantitative' />
          </datasource-dependencies>
          <aggregation value='true' />
        </view>
        <style />
        <panes>
          <pane selection-relaxation-option='selection-relaxation-allow'>
            <view>
              <breakdown value='auto' />
            </view>
            <mark class='Bar' />
            <encodings>
              <color column='[federated.weather_perf].[none:weather_condition:nk]' />
            </encodings>
          </pane>
        </panes>
        <rows>[federated.weather_perf].[none:weather_condition:nk]</rows>
        <cols>[federated.weather_perf].[sum:billed_revenue_inr:qk]</cols>
      </table>
    </worksheet>
  </worksheets>

  <dashboards>
    <dashboard name='Executive Operations &amp; Profitability Dashboard'>
      <style />
      <size maxheight='800' maxwidth='1400' minheight='800' minwidth='1400' />
      <zones>
        <zone h='100000' id='4' type-v2='layout-basic' w='100000' x='0' y='0'>
          <zone h='98000' id='5' param='vert' type-v2='layout-flow' w='98000' x='1000' y='1000'>
            <!-- Tier 1: KPI Strip (Height 14%) -->
            <zone h='14000' id='1' name='1. KPI Strip' w='98000' x='1000' y='1000' />
            <!-- Tier 2: Trend & Stations (Height 42%) -->
            <zone h='42000' id='6' param='horz' type-v2='layout-flow' w='98000' x='1000' y='15000'>
              <zone h='42000' id='2' name='2. Trend - Revenue &amp; Profit Margin Over Time' w='58000' x='1000' y='15000' />
              <zone h='42000' id='3' name='3. Stations - Revenue &amp; Margin by Station' w='40000' x='59000' y='15000' />
            </zone>
            <!-- Tier 3: Connectors, Map, Weather (Height 42%) -->
            <zone h='42000' id='7' param='horz' type-v2='layout-flow' w='98000' x='1000' y='57000'>
              <zone h='42000' id='8' name='4. Connectors - Revenue &amp; Success by Class' w='32000' x='1000' y='57000' />
              <zone h='42000' id='9' name='5. Map - Revenue by Station' w='34000' x='33000' y='57000' />
              <zone h='42000' id='10' name='6. Weather - Revenue &amp; Failure Rate' w='32000' x='67000' y='57000' />
            </zone>
          </zone>
        </zone>
      </zones>
    </dashboard>
  </dashboards>

  <windows saved-dpi-scale-factor='1.25' source-height='37'>
    <window class='worksheet' name='1. KPI Strip'>
      <cards>
        <edge name='left'>
          <strip size='160'>
            <card type='pages' />
            <card type='filters' />
            <card type='marks' />
          </strip>
        </edge>
        <edge name='top'>
          <strip size='2147483647'>
            <card type='columns' />
          </strip>
          <strip size='2147483647'>
            <card type='rows' />
          </strip>
        </edge>
      </cards>
    </window>
    <window class='worksheet' name='2. Trend - Revenue &amp; Profit Margin Over Time'>
      <cards>
        <edge name='left'>
          <strip size='160'>
            <card type='pages' />
            <card type='filters' />
            <card type='marks' />
          </strip>
        </edge>
        <edge name='top'>
          <strip size='2147483647'>
            <card type='columns' />
          </strip>
          <strip size='2147483647'>
            <card type='rows' />
          </strip>
        </edge>
      </cards>
    </window>
    <window class='worksheet' name='3. Stations - Revenue &amp; Margin by Station'>
      <cards>
        <edge name='left'>
          <strip size='160'>
            <card type='pages' />
            <card type='filters' />
            <card type='marks' />
          </strip>
        </edge>
        <edge name='top'>
          <strip size='2147483647'>
            <card type='columns' />
          </strip>
          <strip size='2147483647'>
            <card type='rows' />
          </strip>
        </edge>
      </cards>
    </window>
    <window class='worksheet' name='4. Connectors - Revenue &amp; Success by Class'>
      <cards>
        <edge name='left'>
          <strip size='160'>
            <card type='pages' />
            <card type='filters' />
            <card type='marks' />
          </strip>
        </edge>
        <edge name='top'>
          <strip size='2147483647'>
            <card type='columns' />
          </strip>
          <strip size='2147483647'>
            <card type='rows' />
          </strip>
        </edge>
      </cards>
    </window>
    <window class='worksheet' name='5. Map - Revenue by Station'>
      <cards>
        <edge name='left'>
          <strip size='160'>
            <card type='pages' />
            <card type='filters' />
            <card type='marks' />
          </strip>
        </edge>
        <edge name='top'>
          <strip size='2147483647'>
            <card type='columns' />
          </strip>
          <strip size='2147483647'>
            <card type='rows' />
          </strip>
        </edge>
      </cards>
    </window>
    <window class='worksheet' name='6. Weather - Revenue &amp; Failure Rate'>
      <cards>
        <edge name='left'>
          <strip size='160'>
            <card type='pages' />
            <card type='filters' />
            <card type='marks' />
          </strip>
        </edge>
        <edge name='top'>
          <strip size='2147483647'>
            <card type='columns' />
          </strip>
          <strip size='2147483647'>
            <card type='rows' />
          </strip>
        </edge>
      </cards>
    </window>
    <window class='dashboard' maximized='true' name='Executive Operations &amp; Profitability Dashboard'>
      <viewpoints>
        <viewpoint name='1. KPI Strip'>
          <zoom type='entire-view' />
        </viewpoint>
        <viewpoint name='2. Trend - Revenue &amp; Profit Margin Over Time'>
          <zoom type='entire-view' />
        </viewpoint>
        <viewpoint name='3. Stations - Revenue &amp; Margin by Station'>
          <zoom type='entire-view' />
        </viewpoint>
        <viewpoint name='4. Connectors - Revenue &amp; Success by Class'>
          <zoom type='entire-view' />
        </viewpoint>
        <viewpoint name='5. Map - Revenue by Station'>
          <zoom type='entire-view' />
        </viewpoint>
        <viewpoint name='6. Weather - Revenue &amp; Failure Rate'>
          <zoom type='entire-view' />
        </viewpoint>
      </viewpoints>
      <active id='-1' />
    </window>
  </windows>
</workbook>
"""

# Verify XML well-formedness
try:
    ET.fromstring(twb_xml)
    print("5. XML Syntax validated with standard ElementTree parser successfully!")
except Exception as e:
    print("XML Error:", e)
    raise

# Package into .twbx
if os.path.exists(OUTPUT_TWBX):
    os.remove(OUTPUT_TWBX)

with zipfile.ZipFile(OUTPUT_TWBX, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("EV_Charging_Executive_Dashboard.twb", twb_xml.encode("utf-8"))
    z.write(HYPER_FILE, "Data/Extracts/EV_Charging_Executive.hyper")

# Copy to root workspace
root_twbx = os.path.join(BASE_DIR, "..", "EV_Charging_Executive_Dashboard.twbx")
shutil.copyfile(OUTPUT_TWBX, root_twbx)

print("6. Master reference workbook built successfully at:")
print(" - " + OUTPUT_TWBX)
print(" - " + root_twbx)
