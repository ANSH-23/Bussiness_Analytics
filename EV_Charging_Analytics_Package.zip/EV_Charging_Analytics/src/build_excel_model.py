"""
EV Charging Station Analytics - Excel Financial Model Builder
Author: Senior Financial Analyst & Python Developer
Description:
    Builds the executive-grade financial workbook 'output/EV_Charging_Analytics_Financial_Model.xlsx'
    containing 7 distinct sheets:
    1. Read Me (Metadata, KPI dictionary, instructions, assumptions)
    2. Session Data (Sample & representative sessions with live formulas)
    3. Station Summary (10 stations with totals, expenses, margins, and active utilization)
    4. Monthly Analysis (6-month financial trajectory with MoM formulas)
    5. Connector Analysis (50 connectors with throughput, uptime, and port yields)
    6. Financial Dashboard (Executive KPI cards + OpenPyXL native charts)
    7. What-If Analysis (Interactive dynamic scenario model with formula-driven projections)
"""

import os
import csv
from datetime import datetime
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, LineChart, Reference

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RAW_DIR = os.path.join(BASE_DIR, "data", "raw")
PROCESSED_DIR = os.path.join(BASE_DIR, "data", "processed")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")

os.makedirs(OUTPUT_DIR, exist_ok=True)


def load_csv(dirpath, filename):
    filepath = os.path.join(dirpath, filename)
    with open(filepath, "r", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def style_header_row(ws, row_idx, num_cols, fill_color="1A365D", font_color="FFFFFF"):
    fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")
    font = Font(name="Calibri", size=11, bold=True, color=font_color)
    border_side = Side(border_style="thin", color="CBD5E0")
    border = Border(left=border_side, right=border_side, top=border_side, bottom=border_side)
    for col in range(1, num_cols + 1):
        cell = ws.cell(row=row_idx, column=col)
        cell.fill = fill
        cell.font = font
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border
    ws.row_dimensions[row_idx].height = 26


def auto_fit_columns(ws, min_width=12, max_width=45):
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            # Skip merged cells or long header notes in row 1-3
            if cell.row < 4 and len(str(cell.value or "")) > 30:
                continue
            val_str = str(cell.value or "")
            if len(val_str) > max_len:
                max_len = len(val_str)
        ws.column_dimensions[col_letter].width = max(min_width, min(max_len + 4, max_width))


def main():
    print("Building executive Excel Financial Model...")

    wb = openpyxl.Workbook()
    # Remove default sheet
    wb.remove(wb.active)

    thin_border = Border(
        left=Side(style="thin", color="E2E8F0"),
        right=Side(style="thin", color="E2E8F0"),
        top=Side(style="thin", color="E2E8F0"),
        bottom=Side(style="thin", color="E2E8F0")
    )

    # ==========================================================================
    # SHEET 1: READ ME
    # ==========================================================================
    ws_readme = wb.create_sheet(title="Read Me")
    ws_readme.views.sheetView[0].showGridLines = True

    # Title Banner
    ws_readme.merge_cells("A1:G1")
    title_cell = ws_readme["A1"]
    title_cell.value = "EV CHARGING STATION ANALYTICS & PROFITABILITY OPTIMIZATION"
    title_cell.font = Font(name="Calibri", size=16, bold=True, color="FFFFFF")
    title_cell.fill = PatternFill(start_color="1A365D", fill_type="solid")
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws_readme.row_dimensions[1].height = 40

    ws_readme.merge_cells("A2:G2")
    sub_cell = ws_readme["A2"]
    sub_cell.value = "Executive Financial Model & Operational Audit (Period: Jan 01, 2024 - Jun 30, 2024 | Bengaluru, India)"
    sub_cell.font = Font(name="Calibri", size=11, italic=True, color="FFFFFF")
    sub_cell.fill = PatternFill(start_color="2B6CB0", fill_type="solid")
    sub_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws_readme.row_dimensions[2].height = 24

    readme_content = [
        ("", ""),
        ("1. PROJECT OVERVIEW", ""),
        ("Title", "EV Charging Station Analytics & Profitability Optimization Using Python, MySQL, Microsoft Excel, and Tableau"),
        ("Author", "MCA Final Semester Data Analytics Academic Project"),
        ("Geographic Scope", "Bengaluru Metropolitan Area (10 Commercial & Tech Park Stations)"),
        ("Hardware Scope", "50 Charging Ports (CCS2 50-120kW, Type 2 AC 7.4-22kW, CHAdeMO 50kW, Bharat DC-001 15kW)"),
        ("Simulation Period", "January 01, 2024 to June 30, 2024 (182 Calendar Days | 11,821 Total Sessions)"),
        ("Currency & Units", "Indian Rupee (INR ₹), Kilowatt-Hours (kWh), Kilowatts (kW), Minutes"),
        ("", ""),
        ("2. KEY PERFORMANCE INDICATOR (KPI) FORMULAS", ""),
        ("Charging Revenue (INR)", "SUM(energy_delivered_kwh * customer_price_per_kwh_inr) for Completed Sessions"),
        ("Electricity Cost (COGS)", "SUM(energy_delivered_kwh * electricity_tariff_per_kwh_inr)"),
        ("Gross Energy Margin (%)", "(Charging Revenue - Electricity Cost) / Charging Revenue * 100"),
        ("Total Operating Expenses", "Electricity Cost + Staff Cost + Facility Rent + Maintenance Cost + Other CMS Fees"),
        ("Operating Profit (EBIT)", "Charging Revenue - Total Operating Expenses"),
        ("Operating Profit Margin", "Operating Profit / Charging Revenue * 100"),
        ("Available Port Minutes", "total_connectors * operating_hours_per_day * 60 * total_calendar_days"),
        ("Active Utilization Rate", "active_charging_minutes / available_connector_minutes (Bounded [0, 1])"),
        ("Session Success Rate (%)", "completed_sessions / total_session_attempts * 100"),
        ("", ""),
        ("3. WORKBOOK NAVIGATION GUIDE", ""),
        ("Sheet 2: Session Data", "Detailed log of charging sessions, vehicle IDs, tariffs, energy, and revenue."),
        ("Sheet 3: Station Summary", "Master 10-station performance scorecard with full cost allocations and operating profit."),
        ("Sheet 4: Monthly Analysis", "Month-over-month trajectory of throughput, revenue, OPEX, and net margins."),
        ("Sheet 5: Connector Analysis", "Hardware yield audit by port type, power rating, utilization, and downtime."),
        ("Sheet 6: Financial Dashboard", "High-level executive dashboard with KPI callout cards and visual bar/line charts."),
        ("Sheet 7: What-If Analysis", "Interactive scenario model testing tariff adjustments, demand changes, and cost controls.")
    ]

    r_idx = 4
    for k, v in readme_content:
        if k.startswith("1.") or k.startswith("2.") or k.startswith("3."):
            ws_readme.merge_cells(start_row=r_idx, start_column=1, end_row=r_idx, end_column=7)
            c = ws_readme.cell(row=r_idx, column=1, value=k)
            c.font = Font(name="Calibri", size=12, bold=True, color="1A365D")
            c.fill = PatternFill(start_color="EDF2F7", fill_type="solid")
            ws_readme.row_dimensions[r_idx].height = 22
        elif k:
            ws_readme.cell(row=r_idx, column=1, value=k).font = Font(bold=True, color="2D3748")
            ws_readme.merge_cells(start_row=r_idx, start_column=2, end_row=r_idx, end_column=7)
            ws_readme.cell(row=r_idx, column=2, value=v).font = Font(color="4A5568")
        r_idx += 1

    ws_readme.column_dimensions["A"].width = 28
    ws_readme.column_dimensions["B"].width = 75

    # ==========================================================================
    # SHEET 2: SESSION DATA (First 1,000 representative records with live formula links)
    # ==========================================================================
    ws_sessions = wb.create_sheet(title="Session Data")
    ws_sessions.views.sheetView[0].showGridLines = True
    ws_sessions.freeze_panes = "A2"

    raw_sessions = load_csv(RAW_DIR, "charging_sessions.csv")
    session_headers = [
        "Session ID", "Connector ID", "Station ID", "Vehicle ID",
        "Session Start", "Session End", "Energy (kWh)", "Charging (Mins)",
        "Idle (Mins)", "Total Time (Mins)", "Electricity Tariff (₹)",
        "Customer Price (₹)", "Charging Revenue (₹)", "Electricity Cost (₹)",
        "Gross Profit (₹)", "Status", "Payment", "Day Type", "Weather"
    ]
    for c_idx, h in enumerate(session_headers, 1):
        ws_sessions.cell(row=1, column=c_idx, value=h)
    style_header_row(ws_sessions, 1, len(session_headers))

    # Populate top 1,500 sessions for snappy Excel performance and demonstration
    for r_idx, s in enumerate(raw_sessions[:1500], 2):
        ws_sessions.cell(row=r_idx, column=1, value=s["session_id"])
        ws_sessions.cell(row=r_idx, column=2, value=s["connector_id"])
        ws_sessions.cell(row=r_idx, column=3, value=s["station_id"])
        ws_sessions.cell(row=r_idx, column=4, value=s["vehicle_id"])
        ws_sessions.cell(row=r_idx, column=5, value=s["session_start"])
        ws_sessions.cell(row=r_idx, column=6, value=s["session_end"])

        c_energy = ws_sessions.cell(row=r_idx, column=7, value=float(s["energy_delivered_kwh"]))
        c_energy.number_format = "#,##0.00"

        c_chg = ws_sessions.cell(row=r_idx, column=8, value=int(s["charging_duration_minutes"]))
        c_chg.number_format = "#,##0"

        c_idle = ws_sessions.cell(row=r_idx, column=9, value=int(s["idle_duration_minutes"]))
        c_idle.number_format = "#,##0"

        # Formula: Total Time = Charging + Idle
        c_tot_t = ws_sessions.cell(row=r_idx, column=10, value=f"=H{r_idx}+I{r_idx}")
        c_tot_t.number_format = "#,##0"

        c_tarif = ws_sessions.cell(row=r_idx, column=11, value=float(s["electricity_tariff_per_kwh_inr"]))
        c_tarif.number_format = "₹#,##0.00"

        cust_price = float(s["customer_price_per_kwh_inr"]) if "customer_price_per_kwh_inr" in s else (round(float(s["charging_revenue_inr"]) / float(s["energy_delivered_kwh"]), 2) if float(s.get("energy_delivered_kwh", 0)) > 0 else 18.00)
        c_cust = ws_sessions.cell(row=r_idx, column=12, value=cust_price)
        c_cust.number_format = "₹#,##0.00"

        # Formula: Revenue = IF(Status='Completed', ROUND(Energy * Price, 2), 0)
        c_rev = ws_sessions.cell(row=r_idx, column=13, value=f'=IF(P{r_idx}="Completed", ROUND(G{r_idx}*L{r_idx}, 2), 0)')
        c_rev.number_format = "₹#,##0.00"

        # Formula: Cost = ROUND(Energy * Tariff, 2)
        c_cost = ws_sessions.cell(row=r_idx, column=14, value=f"=ROUND(G{r_idx}*K{r_idx}, 2)")
        c_cost.number_format = "₹#,##0.00"

        # Formula: Gross Profit = Revenue - Cost
        c_gp = ws_sessions.cell(row=r_idx, column=15, value=f"=M{r_idx}-N{r_idx}")
        c_gp.number_format = "₹#,##0.00"

        ws_sessions.cell(row=r_idx, column=16, value=s["session_status"])
        ws_sessions.cell(row=r_idx, column=17, value=s["payment_status"])
        ws_sessions.cell(row=r_idx, column=18, value=s["day_type"])
        ws_sessions.cell(row=r_idx, column=19, value=s["weather_condition"])

        for col_i in range(1, len(session_headers) + 1):
            ws_sessions.cell(row=r_idx, column=col_i).border = thin_border

    auto_fit_columns(ws_sessions)

    # ==========================================================================
    # SHEET 3: STATION SUMMARY
    # ==========================================================================
    ws_station = wb.create_sheet(title="Station Summary")
    ws_station.views.sheetView[0].showGridLines = True
    ws_station.freeze_panes = "A2"

    st_summary_data = load_csv(PROCESSED_DIR, "station_summary.csv")
    st_headers = [
        "Station ID", "Station Name", "Area", "Type", "Ports",
        "Total Sessions", "Completed", "Failed", "Success Rate (%)",
        "Energy Sold (kWh)", "Revenue (₹)", "Electricity Cost (₹)", "Gross Profit (₹)",
        "Staff Cost (₹)", "Rent (₹)", "Maintenance (₹)", "Other Cost (₹)",
        "Total OPEX (₹)", "Operating Profit (₹)", "Margin (%)", "Utilization (%)"
    ]
    for c_idx, h in enumerate(st_headers, 1):
        ws_station.cell(row=1, column=c_idx, value=h)
    style_header_row(ws_station, 1, len(st_headers))

    for r_idx, row in enumerate(st_summary_data, 2):
        ws_station.cell(row=r_idx, column=1, value=row["station_id"])
        ws_station.cell(row=r_idx, column=2, value=row["station_name"])
        ws_station.cell(row=r_idx, column=3, value=row["area"])
        ws_station.cell(row=r_idx, column=4, value=row["station_type"])
        ws_station.cell(row=r_idx, column=5, value=int(row["total_connectors"]))

        ws_station.cell(row=r_idx, column=6, value=int(row["total_sessions"]))
        ws_station.cell(row=r_idx, column=7, value=int(row["completed_sessions"]))
        ws_station.cell(row=r_idx, column=8, value=int(row["failed_sessions"]))

        # Formula: Success Rate = G/F
        c_sr = ws_station.cell(row=r_idx, column=9, value=f"=G{r_idx}/F{r_idx}")
        c_sr.number_format = "0.0%"

        c_en = ws_station.cell(row=r_idx, column=10, value=float(row["energy_delivered_kwh"]))
        c_en.number_format = "#,##0.00"

        c_rev = ws_station.cell(row=r_idx, column=11, value=float(row["charging_revenue_inr"]))
        c_rev.number_format = "₹#,##0.00"

        c_el = ws_station.cell(row=r_idx, column=12, value=float(row["electricity_cost_inr"]))
        c_el.number_format = "₹#,##0.00"

        # Formula: Gross Profit = K - L
        c_gp = ws_station.cell(row=r_idx, column=13, value=f"=K{r_idx}-L{r_idx}")
        c_gp.number_format = "₹#,##0.00"

        c_st = ws_station.cell(row=r_idx, column=14, value=float(row["staff_cost_inr"]))
        c_st.number_format = "₹#,##0.00"

        c_rt = ws_station.cell(row=r_idx, column=15, value=float(row["rent_cost_inr"]))
        c_rt.number_format = "₹#,##0.00"

        c_mt = ws_station.cell(row=r_idx, column=16, value=float(row["maintenance_cost_inr"]))
        c_mt.number_format = "₹#,##0.00"

        c_ot = ws_station.cell(row=r_idx, column=17, value=float(row["other_operating_cost_inr"]))
        c_ot.number_format = "₹#,##0.00"

        # Formula: Total OPEX = L + N + O + P + Q
        c_topx = ws_station.cell(row=r_idx, column=18, value=f"=SUM(L{r_idx},N{r_idx}:Q{r_idx})")
        c_topx.number_format = "₹#,##0.00"

        # Formula: Operating Profit = K - R
        c_op = ws_station.cell(row=r_idx, column=19, value=f"=K{r_idx}-R{r_idx}")
        c_op.number_format = "₹#,##0.00"

        # Formula: Operating Margin = S / K
        c_om = ws_station.cell(row=r_idx, column=20, value=f"=S{r_idx}/K{r_idx}")
        c_om.number_format = "0.0%"

        c_ut = ws_station.cell(row=r_idx, column=21, value=float(row["utilization_rate"]))
        c_ut.number_format = "0.0%"

        for col_i in range(1, len(st_headers) + 1):
            ws_station.cell(row=r_idx, column=col_i).border = thin_border

    # Total Row
    tot_row = len(st_summary_data) + 2
    ws_station.cell(row=tot_row, column=2, value="NETWORK TOTAL").font = Font(bold=True)
    ws_station.cell(row=tot_row, column=5, value=f"=SUM(E2:E{tot_row-1})")
    ws_station.cell(row=tot_row, column=6, value=f"=SUM(F2:F{tot_row-1})")
    ws_station.cell(row=tot_row, column=7, value=f"=SUM(G2:G{tot_row-1})")
    ws_station.cell(row=tot_row, column=8, value=f"=SUM(H2:H{tot_row-1})")
    ws_station.cell(row=tot_row, column=9, value=f"=G{tot_row}/F{tot_row}").number_format = "0.0%"
    ws_station.cell(row=tot_row, column=10, value=f"=SUM(J2:J{tot_row-1})").number_format = "#,##0.00"
    ws_station.cell(row=tot_row, column=11, value=f"=SUM(K2:K{tot_row-1})").number_format = "₹#,##0.00"
    ws_station.cell(row=tot_row, column=12, value=f"=SUM(L2:L{tot_row-1})").number_format = "₹#,##0.00"
    ws_station.cell(row=tot_row, column=13, value=f"=K{tot_row}-L{tot_row}").number_format = "₹#,##0.00"
    ws_station.cell(row=tot_row, column=14, value=f"=SUM(N2:N{tot_row-1})").number_format = "₹#,##0.00"
    ws_station.cell(row=tot_row, column=15, value=f"=SUM(O2:O{tot_row-1})").number_format = "₹#,##0.00"
    ws_station.cell(row=tot_row, column=16, value=f"=SUM(P2:P{tot_row-1})").number_format = "₹#,##0.00"
    ws_station.cell(row=tot_row, column=17, value=f"=SUM(Q2:Q{tot_row-1})").number_format = "₹#,##0.00"
    ws_station.cell(row=tot_row, column=18, value=f"=SUM(R2:R{tot_row-1})").number_format = "₹#,##0.00"
    ws_station.cell(row=tot_row, column=19, value=f"=K{tot_row}-R{tot_row}").number_format = "₹#,##0.00"
    ws_station.cell(row=tot_row, column=20, value=f"=S{tot_row}/K{tot_row}").number_format = "0.0%"
    ws_station.cell(row=tot_row, column=21, value=f"=AVERAGE(U2:U{tot_row-1})").number_format = "0.0%"

    tot_fill = PatternFill(start_color="EDF2F7", fill_type="solid")
    for col_i in range(1, len(st_headers) + 1):
        c = ws_station.cell(row=tot_row, column=col_i)
        c.font = Font(bold=True)
        c.fill = tot_fill
        c.border = Border(top=Side(style="thin"), bottom=Side(style="double"))

    auto_fit_columns(ws_station)

    # ==========================================================================
    # SHEET 4: MONTHLY ANALYSIS
    # ==========================================================================
    ws_monthly = wb.create_sheet(title="Monthly Analysis")
    ws_monthly.views.sheetView[0].showGridLines = True
    ws_monthly.freeze_panes = "A2"

    monthly_data = load_csv(PROCESSED_DIR, "monthly_financial_summary.csv")
    monthly_headers = [
        "Month", "Total Sessions", "Completed Sessions", "Energy Sold (kWh)",
        "Charging Revenue (₹)", "Electricity Cost (₹)", "Gross Profit (₹)",
        "Fixed & Routine OPEX (₹)", "Total Costs (₹)", "Operating Profit (₹)",
        "Operating Margin (%)", "Revenue MoM Growth (%)", "Profit MoM Growth (%)"
    ]
    for c_idx, h in enumerate(monthly_headers, 1):
        ws_monthly.cell(row=1, column=c_idx, value=h)
    style_header_row(ws_monthly, 1, len(monthly_headers))

    for r_idx, row in enumerate(monthly_data, 2):
        ws_monthly.cell(row=r_idx, column=1, value=row["month"])
        ws_monthly.cell(row=r_idx, column=2, value=int(row["total_sessions"]))
        ws_monthly.cell(row=r_idx, column=3, value=int(row["completed_sessions"]))

        c_en = ws_monthly.cell(row=r_idx, column=4, value=float(row["energy_delivered_kwh"]))
        c_en.number_format = "#,##0.00"

        c_rev = ws_monthly.cell(row=r_idx, column=5, value=float(row["charging_revenue_inr"]))
        c_rev.number_format = "₹#,##0.00"

        c_el = ws_monthly.cell(row=r_idx, column=6, value=float(row["electricity_cost_inr"]))
        c_el.number_format = "₹#,##0.00"

        # Gross Profit formula
        c_gp = ws_monthly.cell(row=r_idx, column=7, value=f"=E{r_idx}-F{r_idx}")
        c_gp.number_format = "₹#,##0.00"

        c_opx = ws_monthly.cell(row=r_idx, column=8, value=float(row["operating_expenses_inr"]))
        c_opx.number_format = "₹#,##0.00"

        # Total Cost formula
        c_tc = ws_monthly.cell(row=r_idx, column=9, value=f"=F{r_idx}+H{r_idx}")
        c_tc.number_format = "₹#,##0.00"

        # Operating Profit formula
        c_op = ws_monthly.cell(row=r_idx, column=10, value=f"=E{r_idx}-I{r_idx}")
        c_op.number_format = "₹#,##0.00"

        # Operating Margin formula
        c_om = ws_monthly.cell(row=r_idx, column=11, value=f"=J{r_idx}/E{r_idx}")
        c_om.number_format = "0.0%"

        # MoM Growth formulas
        if r_idx == 2:
            c_rmom = ws_monthly.cell(row=r_idx, column=12, value=0.0)
            c_pmom = ws_monthly.cell(row=r_idx, column=13, value=0.0)
        else:
            c_rmom = ws_monthly.cell(row=r_idx, column=12, value=f"=(E{r_idx}-E{r_idx-1})/E{r_idx-1}")
            c_pmom = ws_monthly.cell(row=r_idx, column=13, value=f"=(J{r_idx}-J{r_idx-1})/ABS(J{r_idx-1})")

        c_rmom.number_format = "0.0%"
        c_pmom.number_format = "0.0%"

        for col_i in range(1, len(monthly_headers) + 1):
            ws_monthly.cell(row=r_idx, column=col_i).border = thin_border

    auto_fit_columns(ws_monthly)

    # ==========================================================================
    # SHEET 5: CONNECTOR ANALYSIS
    # ==========================================================================
    ws_conn = wb.create_sheet(title="Connector Analysis")
    ws_conn.views.sheetView[0].showGridLines = True
    ws_conn.freeze_panes = "A2"

    conn_data = load_csv(PROCESSED_DIR, "connector_performance.csv")
    conn_headers = [
        "Connector ID", "Station ID", "Station Name", "Connector Type",
        "Rated Power (kW)", "Total Sessions", "Completed", "Failed",
        "Failure Rate (%)", "Energy Delivered (kWh)", "Revenue (₹)",
        "Electricity Cost (₹)", "Gross Profit (₹)", "Active Mins",
        "Downtime Mins", "Utilization (%)"
    ]
    for c_idx, h in enumerate(conn_headers, 1):
        ws_conn.cell(row=1, column=c_idx, value=h)
    style_header_row(ws_conn, 1, len(conn_headers))

    for r_idx, row in enumerate(conn_data, 2):
        ws_conn.cell(row=r_idx, column=1, value=row["connector_id"])
        ws_conn.cell(row=r_idx, column=2, value=row["station_id"])
        ws_conn.cell(row=r_idx, column=3, value=row["station_name"])
        ws_conn.cell(row=r_idx, column=4, value=row["connector_type"])
        ws_conn.cell(row=r_idx, column=5, value=float(row["rated_power_kw"]))

        ws_conn.cell(row=r_idx, column=6, value=int(row["total_sessions"]))
        ws_conn.cell(row=r_idx, column=7, value=int(row["completed_sessions"]))
        ws_conn.cell(row=r_idx, column=8, value=int(row["failed_sessions"]))

        # Failure rate formula: H / F
        c_fr = ws_conn.cell(row=r_idx, column=9, value=f"=H{r_idx}/F{r_idx}")
        c_fr.number_format = "0.0%"

        c_en = ws_conn.cell(row=r_idx, column=10, value=float(row["energy_delivered_kwh"]))
        c_en.number_format = "#,##0.00"

        c_rev = ws_conn.cell(row=r_idx, column=11, value=float(row["charging_revenue_inr"]))
        c_rev.number_format = "₹#,##0.00"

        c_el = ws_conn.cell(row=r_idx, column=12, value=float(row["electricity_cost_inr"]))
        c_el.number_format = "₹#,##0.00"

        # Gross Profit formula
        c_gp = ws_conn.cell(row=r_idx, column=13, value=f"=K{r_idx}-L{r_idx}")
        c_gp.number_format = "₹#,##0.00"

        ws_conn.cell(row=r_idx, column=14, value=int(row["active_charging_minutes"]))
        ws_conn.cell(row=r_idx, column=15, value=int(row["downtime_minutes"]))

        c_ut = ws_conn.cell(row=r_idx, column=16, value=float(row["utilization_rate"]))
        c_ut.number_format = "0.0%"

        for col_i in range(1, len(conn_headers) + 1):
            ws_conn.cell(row=r_idx, column=col_i).border = thin_border

    auto_fit_columns(ws_conn)

    # ==========================================================================
    # SHEET 6: FINANCIAL DASHBOARD (KPI Cards + Charts)
    # ==========================================================================
    ws_dash = wb.create_sheet(title="Financial Dashboard")
    ws_dash.views.sheetView[0].showGridLines = False

    # Title
    ws_dash.merge_cells("A1:K1")
    d_title = ws_dash["A1"]
    d_title.value = "EXECUTIVE FINANCIAL & OPERATIONAL DASHBOARD"
    d_title.font = Font(name="Calibri", size=16, bold=True, color="FFFFFF")
    d_title.fill = PatternFill(start_color="1A365D", fill_type="solid")
    d_title.alignment = Alignment(horizontal="center", vertical="center")
    ws_dash.row_dimensions[1].height = 36

    # 5 KPI Callout Cards
    kpis = [
        ("TOTAL CHARGING REVENUE", "='Station Summary'!K12", "₹#,##0.00", "2B6CB0", "A3", "B4"),
        ("TOTAL OPERATING PROFIT", "='Station Summary'!S12", "₹#,##0.00", "2F855A", "C3", "D4"),
        ("TOTAL ENERGY DELIVERED", "='Station Summary'!J12", "#,##0.00 \"kWh\"", "D69E2E", "E3", "F4"),
        ("SESSION SUCCESS RATE", "='Station Summary'!I12", "0.0%", "3182CE", "G3", "H4"),
        ("AVERAGE UTILIZATION", "='Station Summary'!U12", "0.0%", "805AD5", "I3", "J4")
    ]

    for title, formula, num_fmt, color, top_left, bot_right in kpis:
        # Card Title
        c_top = ws_dash[top_left]
        c_top.value = title
        c_top.font = Font(name="Calibri", size=9, bold=True, color="718096")
        c_top.alignment = Alignment(horizontal="center", vertical="center")

        # Card Value
        c_val = ws_dash[bot_right.replace("4", "4").replace("B", "A").replace("D", "C").replace("F", "E").replace("H", "G").replace("J", "I")]
        c_val.value = formula
        c_val.font = Font(name="Calibri", size=14, bold=True, color=color)
        c_val.number_format = num_fmt
        c_val.alignment = Alignment(horizontal="center", vertical="center")

        ws_dash.merge_cells(f"{top_left}:{bot_right.replace('4', '3')}")
        ws_dash.merge_cells(f"{top_left.replace('3', '4')}:{bot_right}")

        # Borders & fill
        card_fill = PatternFill(start_color="F7FAFC", fill_type="solid")
        card_border = Border(
            left=Side(style="medium", color="CBD5E0"),
            right=Side(style="medium", color="CBD5E0"),
            top=Side(style="medium", color="CBD5E0"),
            bottom=Side(style="medium", color="CBD5E0")
        )
        col_start = ord(top_left[0]) - ord('A') + 1
        col_end = ord(bot_right[0]) - ord('A') + 1
        for col in range(col_start, col_end + 1):
            for row in [3, 4]:
                cell = ws_dash.cell(row=row, column=col)
                cell.fill = card_fill
                cell.border = card_border

    ws_dash.row_dimensions[3].height = 18
    ws_dash.row_dimensions[4].height = 32

    # Add Bar Chart: Station Profitability Ranking
    chart1 = BarChart()
    chart1.type = "col"
    chart1.style = 10
    chart1.title = "Station Operating Profit (INR ₹)"
    chart1.y_axis.title = "Operating Profit (₹)"
    chart1.x_axis.title = "Station"
    chart1.width = 16
    chart1.height = 10

    # Data from Station Summary Sheet (Column S is Operating Profit, rows 1-11)
    data_ref = Reference(ws_station, min_col=19, min_row=1, max_row=11)
    cats_ref = Reference(ws_station, min_col=2, min_row=2, max_row=11)
    chart1.add_data(data_ref, titles_from_data=True)
    chart1.set_categories(cats_ref)
    chart1.legend = None
    ws_dash.add_chart(chart1, "A7")

    # Add Line Chart: Monthly Revenue & Profit Trend
    chart2 = LineChart()
    chart2.title = "Monthly Revenue vs Operating Profit"
    chart2.style = 13
    chart2.y_axis.title = "Amount (₹)"
    chart2.x_axis.title = "Month"
    chart2.width = 16
    chart2.height = 10

    # Monthly Sheet data: Revenue (col E=5), Operating Profit (col J=10)
    data_m1 = Reference(ws_monthly, min_col=5, min_row=1, max_row=7)
    cats_m = Reference(ws_monthly, min_col=1, min_row=2, max_row=7)
    chart2.add_data(data_m1, titles_from_data=True)
    chart2.set_categories(cats_m)

    data_m2 = Reference(ws_monthly, min_col=10, min_row=1, max_row=7)
    chart2.add_data(data_m2, titles_from_data=True)

    ws_dash.add_chart(chart2, "G7")

    # ==========================================================================
    # SHEET 7: WHAT-IF ANALYSIS (Dynamic interactive simulation model)
    # ==========================================================================
    ws_whatif = wb.create_sheet(title="What-If Analysis")
    ws_whatif.views.sheetView[0].showGridLines = True

    # Title
    ws_whatif.merge_cells("A1:G1")
    w_title = ws_whatif["A1"]
    w_title.value = "WHAT-IF SCENARIO ANALYSIS & PROFITABILITY OPTIMIZATION MODEL"
    w_title.font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    w_title.fill = PatternFill(start_color="1A365D", fill_type="solid")
    w_title.alignment = Alignment(horizontal="center", vertical="center")
    ws_whatif.row_dimensions[1].height = 36

    ws_whatif.merge_cells("A2:G2")
    w_sub = ws_whatif["A2"]
    w_sub.value = "Adjust the yellow assumption parameters to simulate operational leverage and bottom-line sensitivity."
    w_sub.font = Font(name="Calibri", size=10, italic=True, color="4A5568")
    w_sub.alignment = Alignment(horizontal="center", vertical="center")
    ws_whatif.row_dimensions[2].height = 20

    # Headers for Assumptions Table
    ws_whatif.cell(row=4, column=1, value="PARAMETER / ASSUMPTION LEVER").font = Font(bold=True, color="FFFFFF")
    ws_whatif.cell(row=4, column=2, value="BASE VALUE").font = Font(bold=True, color="FFFFFF")
    ws_whatif.cell(row=4, column=3, value="SCENARIO INPUT").font = Font(bold=True, color="FFFFFF")
    ws_whatif.cell(row=4, column=4, value="UNIT / ADJUSTMENT").font = Font(bold=True, color="FFFFFF")
    ws_whatif.cell(row=4, column=5, value="RATIONALE & SENSITIVITY IMPACT").font = Font(bold=True, color="FFFFFF")
    style_header_row(ws_whatif, 4, 5, fill_color="2B6CB0")

    assumptions = [
        ("Customer Price Adjustment", 18.50, 19.50, "₹ / kWh", "₹1.00/kWh tariff surge during peak hours (+5.4%)", "B5", "C5"),
        ("Electricity Tariff Change", 7.80, 7.50, "₹ / kWh", "Bulk solar open-access procurement discount (-3.8%)", "B6", "C6"),
        ("Charging Demand Multiplier", 1.00, 1.15, "Factor", "15% fleet partnership demand surge", "B7", "C7"),
        ("Downtime Reduction", 0.00, 0.40, "% Reduction", "Proactive IoT predictive maintenance cuts outages by 40%", "B8", "C8"),
        ("Staff Cost Optimization", 1.00, 0.90, "Factor", "Automated remote CMS access reduces on-site staffing by 10%", "B9", "C9")
    ]

    param_fill = PatternFill(start_color="FEFCBF", fill_type="solid")  # Yellow highlight for input
    for idx, (label, base, scen, unit, rationale, b_cell, c_cell) in enumerate(assumptions, 5):
        ws_whatif.cell(row=idx, column=1, value=label).font = Font(bold=True)
        c_b = ws_whatif.cell(row=idx, column=2, value=base)
        c_s = ws_whatif.cell(row=idx, column=3, value=scen)
        c_s.fill = param_fill
        c_s.font = Font(bold=True)
        ws_whatif.cell(row=idx, column=4, value=unit)
        ws_whatif.cell(row=idx, column=5, value=rationale)

        if "₹" in unit:
            c_b.number_format = "₹#,##0.00"
            c_s.number_format = "₹#,##0.00"
        elif "%" in unit:
            c_b.number_format = "0.0%"
            c_s.number_format = "0.0%"
        else:
            c_b.number_format = "0.00"
            c_s.number_format = "0.00"

        for col_i in range(1, 6):
            ws_whatif.cell(row=idx, column=col_i).border = thin_border

    # Financial Impact Projections Table
    ws_whatif.cell(row=12, column=1, value="PROJECTED FINANCIAL OUTCOME").font = Font(bold=True, color="FFFFFF")
    ws_whatif.cell(row=12, column=2, value="BASE CASE (₹)").font = Font(bold=True, color="FFFFFF")
    ws_whatif.cell(row=12, column=3, value="SCENARIO CASE (₹)").font = Font(bold=True, color="FFFFFF")
    ws_whatif.cell(row=12, column=4, value="VARIANCE (₹)").font = Font(bold=True, color="FFFFFF")
    ws_whatif.cell(row=12, column=5, value="% CHANGE").font = Font(bold=True, color="FFFFFF")
    style_header_row(ws_whatif, 12, 5, fill_color="1A365D")

    # Formula links to Sheet 3 totals
    # Base Revenue: ='Station Summary'!K12
    # Base Elec Cost: ='Station Summary'!L12
    # Base Staff: ='Station Summary'!N12
    # Base Rent: ='Station Summary'!O12
    # Base Maint: ='Station Summary'!P12
    # Base Other: ='Station Summary'!Q12

    outcomes = [
        ("Gross Charging Revenue", "='Station Summary'!K12", "=B13*(C5/B5)*C7", "B13", "C13"),
        ("Electricity Procurement (COGS)", "='Station Summary'!L12", "=B14*(C6/B6)*C7", "B14", "C14"),
        ("Gross Margin Contribution", "=B13-B14", "=C13-C14", "B15", "C15"),
        ("Staff Expenses", "='Station Summary'!N12", "=B16*C9", "B16", "C16"),
        ("Station Facility Rent", "='Station Summary'!O12", "=B17", "B17", "C17"),
        ("Maintenance & Repairs", "='Station Summary'!P12", "=B18*(1-C8*0.5)", "B18", "C18"),
        ("Other Operating Expenses", "='Station Summary'!Q12", "=B19", "B19", "C19"),
        ("Total Operating Expenses", "=SUM(B14,B16:B19)", "=SUM(C14,C16:C19)", "B20", "C20"),
        ("NET OPERATING PROFIT (EBIT)", "=B13-B20", "=C13-C20", "B21", "C21"),
        ("Operating Margin (%)", "=B21/B13", "=C21/C13", "B22", "C22")
    ]

    for idx, (label, f_base, f_scen, b_cell, c_cell) in enumerate(outcomes, 13):
        is_highlight = "NET OPERATING PROFIT" in label or "Margin" in label
        r_font = Font(bold=True, color="1A365D" if is_highlight else "000000")

        ws_whatif.cell(row=idx, column=1, value=label).font = r_font

        cb = ws_whatif.cell(row=idx, column=2, value=f_base)
        cb.font = r_font

        cs = ws_whatif.cell(row=idx, column=3, value=f_scen)
        cs.font = r_font

        cv = ws_whatif.cell(row=idx, column=4, value=f"=C{idx}-B{idx}")
        cv.font = r_font

        cp = ws_whatif.cell(row=idx, column=5, value=f"=(C{idx}-B{idx})/ABS(B{idx})")
        cp.font = r_font

        if "Margin" in label:
            cb.number_format = "0.0%"
            cs.number_format = "0.0%"
            cv.number_format = "0.0%"
            cp.number_format = "0.0%"
        else:
            cb.number_format = "₹#,##0.00"
            cs.number_format = "₹#,##0.00"
            cv.number_format = "₹#,##0.00"
            cp.number_format = "0.0%"

        if is_highlight:
            h_fill = PatternFill(start_color="EBF8FF", fill_type="solid")
            for col_i in range(1, 6):
                ws_whatif.cell(row=idx, column=col_i).fill = h_fill

        for col_i in range(1, 6):
            ws_whatif.cell(row=idx, column=col_i).border = thin_border

    auto_fit_columns(ws_whatif)

    # Save complete workbook
    output_filepath = os.path.join(OUTPUT_DIR, "EV_Charging_Analytics_Financial_Model.xlsx")
    wb.save(output_filepath)
    print(f"Workbook successfully generated and saved to: {output_filepath}")


if __name__ == "__main__":
    main()
