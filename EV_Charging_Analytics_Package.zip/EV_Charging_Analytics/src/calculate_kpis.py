"""
EV Charging Station Analytics - KPI Calculation & Aggregation Engine
Author: Senior Data Analytics Engineer
Description:
    Computes aggregated operational and financial performance metrics across multiple dimensions:
    - Station Summary (Total sessions, energy, revenue, costs, operating profit, active utilization)
    - Monthly Financial Summary (MoM growth, revenue, costs, operating margins)
    - Connector Performance (by type, power rating, utilization, failure rate)
    - Hourly Demand Profile (hourly sessions, energy, peak classification)
    - Weather Impact Summary (demand, duration, and failure rates under diverse weather conditions)
    Outputs all aggregated summaries to data/processed/.
"""

import os
import csv
from datetime import datetime
from collections import defaultdict

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RAW_DIR = os.path.join(BASE_DIR, "data", "raw")
PROCESSED_DIR = os.path.join(BASE_DIR, "data", "processed")

os.makedirs(PROCESSED_DIR, exist_ok=True)


def load_csv(filename):
    filepath = os.path.join(RAW_DIR, filename)
    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader)


def export_csv(filename, rows, fieldnames):
    filepath = os.path.join(PROCESSED_DIR, filename)
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Exported {filename}: {len(rows)} records.")


def main():
    stations = load_csv("stations.csv")
    connectors = load_csv("connectors.csv")
    sessions = load_csv("charging_sessions.csv")
    downtime = load_csv("station_downtime.csv")
    daily_costs = load_csv("daily_station_operating_costs.csv")

    station_dict = {s["station_id"]: s for s in stations}
    connector_dict = {c["connector_id"]: c for c in connectors}

    # --------------------------------------------------------------------------
    # 1. STATION SUMMARY
    # --------------------------------------------------------------------------
    st_stats = defaultdict(lambda: {
        "total_sessions": 0, "completed_sessions": 0, "failed_sessions": 0,
        "energy_delivered_kwh": 0.0, "charging_revenue_inr": 0.0,
        "charging_duration_minutes": 0, "idle_duration_minutes": 0
    })

    for s in sessions:
        st_id = s["station_id"]
        st = st_stats[st_id]
        st["total_sessions"] += 1
        if s["session_status"] == "Completed":
            st["completed_sessions"] += 1
            st["energy_delivered_kwh"] += float(s["energy_delivered_kwh"])
            st["charging_revenue_inr"] += float(s["charging_revenue_inr"])
            st["charging_duration_minutes"] += int(s["charging_duration_minutes"])
            st["idle_duration_minutes"] += int(s["idle_duration_minutes"])
        elif s["session_status"] == "Failed":
            st["failed_sessions"] += 1

    # Downtime minutes by station
    st_dt_mins = defaultdict(int)
    for d in downtime:
        st_dt_mins[d["station_id"]] += int(d["downtime_duration_minutes"])

    # Costs by station
    st_costs = defaultdict(lambda: {
        "electricity_cost_inr": 0.0, "staff_cost_inr": 0.0,
        "rent_cost_inr": 0.0, "maintenance_cost_inr": 0.0,
        "other_operating_cost_inr": 0.0
    })
    for c in daily_costs:
        st_id = c["station_id"]
        st_costs[st_id]["electricity_cost_inr"] += float(c["electricity_cost_inr"])
        st_costs[st_id]["staff_cost_inr"] += float(c["staff_cost_inr"])
        st_costs[st_id]["rent_cost_inr"] += float(c["rent_cost_inr"])
        st_costs[st_id]["maintenance_cost_inr"] += float(c["maintenance_cost_inr"])
        st_costs[st_id]["other_operating_cost_inr"] += float(c["other_operating_cost_inr"])

    total_days = len(set(c["operating_date"] for c in daily_costs))
    station_summary_rows = []
    # Total available minutes across actual calendar days in dataset
    for s in stations:
        st_id = s["station_id"]
        st_data = st_stats[st_id]
        c_data = st_costs[st_id]
        dt_m = st_dt_mins[st_id]

        total_conn = int(s["total_connectors"])
        op_hours = int(s["operating_hours_per_day"])
        avail_mins = total_conn * op_hours * 60 * total_days

        tot_sessions = st_data["total_sessions"]
        comp_sessions = st_data["completed_sessions"]
        fail_sessions = st_data["failed_sessions"]
        energy_kwh = round(st_data["energy_delivered_kwh"], 2)
        revenue = round(st_data["charging_revenue_inr"], 2)

        elec_cost = round(c_data["electricity_cost_inr"], 2)
        staff_cost = round(c_data["staff_cost_inr"], 2)
        rent_cost = round(c_data["rent_cost_inr"], 2)
        maint_cost = round(c_data["maintenance_cost_inr"], 2)
        other_cost = round(c_data["other_operating_cost_inr"], 2)
        total_opex = round(elec_cost + staff_cost + rent_cost + maint_cost + other_cost, 2)
        gross_profit = round(revenue - elec_cost, 2)
        operating_profit = round(revenue - total_opex, 2)
        op_margin_pct = round((operating_profit / revenue * 100) if revenue > 0 else 0.0, 2)

        act_charging_m = st_data["charging_duration_minutes"]
        utilization_rate = round(min(1.0, act_charging_m / avail_mins), 4)
        success_rate = round((comp_sessions / tot_sessions * 100) if tot_sessions > 0 else 0.0, 2)

        station_summary_rows.append({
            "station_id": st_id,
            "station_name": s["station_name"],
            "area": s["area"],
            "station_type": s["station_type"],
            "total_connectors": total_conn,
            "total_sessions": tot_sessions,
            "completed_sessions": comp_sessions,
            "failed_sessions": fail_sessions,
            "session_success_rate_pct": success_rate,
            "energy_delivered_kwh": energy_kwh,
            "charging_revenue_inr": revenue,
            "electricity_cost_inr": elec_cost,
            "gross_profit_inr": gross_profit,
            "staff_cost_inr": staff_cost,
            "rent_cost_inr": rent_cost,
            "maintenance_cost_inr": maint_cost,
            "other_operating_cost_inr": other_cost,
            "total_operating_cost_inr": total_opex,
            "operating_profit_inr": operating_profit,
            "operating_margin_pct": op_margin_pct,
            "available_minutes": avail_mins,
            "active_charging_minutes": act_charging_m,
            "downtime_minutes": dt_m,
            "utilization_rate": utilization_rate
        })

    station_summary_rows.sort(key=lambda x: x["operating_profit_inr"], reverse=True)
    export_csv("station_summary.csv", station_summary_rows, list(station_summary_rows[0].keys()))

    # --------------------------------------------------------------------------
    # 2. MONTHLY FINANCIAL SUMMARY
    # --------------------------------------------------------------------------
    months = sorted(list(set(s["session_start"][:7] for s in sessions if s.get("session_start"))))
    monthly_stats = {m: {
        "month": m, "total_sessions": 0, "completed_sessions": 0,
        "energy_delivered_kwh": 0.0, "charging_revenue_inr": 0.0,
        "electricity_cost_inr": 0.0, "opex_excluding_elec": 0.0
    } for m in months}

    for s in sessions:
        m = s["session_start"][:7]
        if m in monthly_stats:
            monthly_stats[m]["total_sessions"] += 1
            if s["session_status"] == "Completed":
                monthly_stats[m]["completed_sessions"] += 1
                monthly_stats[m]["energy_delivered_kwh"] += float(s["energy_delivered_kwh"])
                monthly_stats[m]["charging_revenue_inr"] += float(s["charging_revenue_inr"])

    for c in daily_costs:
        m = c["operating_date"][:7]
        if m in monthly_stats:
            monthly_stats[m]["electricity_cost_inr"] += float(c["electricity_cost_inr"])
            monthly_stats[m]["opex_excluding_elec"] += (
                float(c["staff_cost_inr"]) + float(c["rent_cost_inr"]) +
                float(c["maintenance_cost_inr"]) + float(c["other_operating_cost_inr"])
            )

    monthly_rows = []
    prev_rev = None
    prev_profit = None

    for m in months:
        data = monthly_stats[m]
        rev = round(data["charging_revenue_inr"], 2)
        elec = round(data["electricity_cost_inr"], 2)
        other_exp = round(data["opex_excluding_elec"], 2)
        tot_exp = round(elec + other_exp, 2)
        gross_prof = round(rev - elec, 2)
        op_prof = round(rev - tot_exp, 2)
        margin_pct = round((op_prof / rev * 100) if rev > 0 else 0.0, 2)

        rev_mom = round(((rev - prev_rev) / prev_rev * 100), 2) if prev_rev else 0.0
        profit_mom = round(((op_prof - prev_profit) / abs(prev_profit) * 100), 2) if prev_profit else 0.0

        prev_rev = rev
        prev_profit = op_prof

        monthly_rows.append({
            "month": m,
            "total_sessions": data["total_sessions"],
            "completed_sessions": data["completed_sessions"],
            "energy_delivered_kwh": round(data["energy_delivered_kwh"], 2),
            "charging_revenue_inr": rev,
            "electricity_cost_inr": elec,
            "gross_profit_inr": gross_prof,
            "operating_expenses_inr": other_exp,
            "total_costs_inr": tot_exp,
            "operating_profit_inr": op_prof,
            "operating_margin_pct": margin_pct,
            "revenue_mom_growth_pct": rev_mom,
            "operating_profit_mom_growth_pct": profit_mom
        })

    export_csv("monthly_financial_summary.csv", monthly_rows, list(monthly_rows[0].keys()))

    # --------------------------------------------------------------------------
    # 3. CONNECTOR PERFORMANCE
    # --------------------------------------------------------------------------
    conn_stats = defaultdict(lambda: {
        "sessions": 0, "completed": 0, "failed": 0, "energy_kwh": 0.0,
        "revenue_inr": 0.0, "charging_minutes": 0
    })

    for s in sessions:
        c_id = s["connector_id"]
        cs = conn_stats[c_id]
        cs["sessions"] += 1
        if s["session_status"] == "Completed":
            cs["completed"] += 1
            cs["energy_kwh"] += float(s["energy_delivered_kwh"])
            cs["revenue_inr"] += float(s["charging_revenue_inr"])
            cs["charging_minutes"] += int(s["charging_duration_minutes"])
        elif s["session_status"] == "Failed":
            cs["failed"] += 1

    conn_dt = defaultdict(int)
    for d in downtime:
        conn_dt[d["connector_id"]] += int(d["downtime_duration_minutes"])

    connector_rows = []
    for c in connectors:
        c_id = c["connector_id"]
        st = station_dict[c["station_id"]]
        cs = conn_stats[c_id]
        tot_sess = cs["sessions"]
        comp = cs["completed"]
        failed = cs["failed"]
        energy = round(cs["energy_kwh"], 2)
        rev = round(cs["revenue_inr"], 2)
        elec_tariff = float(c["electricity_tariff_per_kwh_inr"])
        elec_cost = round(energy * elec_tariff, 2)
        gross_margin = round(rev - elec_cost, 2)

        op_hours = int(st["operating_hours_per_day"])
        avail_mins = op_hours * 60 * total_days
        charging_m = cs["charging_minutes"]
        dt_m = conn_dt[c_id]
        util_rate = round(min(1.0, charging_m / avail_mins), 4)
        fail_rate = round((failed / tot_sess * 100) if tot_sess > 0 else 0.0, 2)

        connector_rows.append({
            "connector_id": c_id,
            "station_id": c["station_id"],
            "station_name": st["station_name"],
            "connector_type": c["connector_type"],
            "rated_power_kw": float(c["rated_power_kw"]),
            "total_sessions": tot_sess,
            "completed_sessions": comp,
            "failed_sessions": failed,
            "failure_rate_pct": fail_rate,
            "energy_delivered_kwh": energy,
            "charging_revenue_inr": rev,
            "electricity_cost_inr": elec_cost,
            "gross_profit_inr": gross_margin,
            "active_charging_minutes": charging_m,
            "downtime_minutes": dt_m,
            "utilization_rate": util_rate
        })

    connector_rows.sort(key=lambda x: x["charging_revenue_inr"], reverse=True)
    export_csv("connector_performance.csv", connector_rows, list(connector_rows[0].keys()))

    # --------------------------------------------------------------------------
    # 4. HOURLY DEMAND PROFILE
    # --------------------------------------------------------------------------
    hourly_data = {h: {"hour_of_day": h, "weekday_sessions": 0, "weekend_sessions": 0, "total_sessions": 0, "energy_delivered_kwh": 0.0, "charging_revenue_inr": 0.0} for h in range(24)}
    for s in sessions:
        h = int(s["session_start"][11:13])
        hd = hourly_data[h]
        hd["total_sessions"] += 1
        if s["day_type"] == "Weekday":
            hd["weekday_sessions"] += 1
        else:
            hd["weekend_sessions"] += 1

        if s["session_status"] == "Completed":
            hd["energy_delivered_kwh"] += float(s["energy_delivered_kwh"])
            hd["charging_revenue_inr"] += float(s["charging_revenue_inr"])

    hourly_rows = []
    for h in range(24):
        hd = hourly_data[h]
        # Label peak period
        if (8 <= h <= 11) or (17 <= h <= 21):
            period_label = "Peak Commute"
        elif (12 <= h <= 16):
            period_label = "Midday Regular"
        else:
            period_label = "Off-Peak / Night"

        hourly_rows.append({
            "hour_of_day": h,
            "period_label": period_label,
            "total_sessions": hd["total_sessions"],
            "weekday_sessions": hd["weekday_sessions"],
            "weekend_sessions": hd["weekend_sessions"],
            "energy_delivered_kwh": round(hd["energy_delivered_kwh"], 2),
            "charging_revenue_inr": round(hd["charging_revenue_inr"], 2)
        })

    export_csv("hourly_demand_profile.csv", hourly_rows, list(hourly_rows[0].keys()))

    # --------------------------------------------------------------------------
    # 5. WEATHER IMPACT SUMMARY
    # --------------------------------------------------------------------------
    weather_dict = defaultdict(lambda: {"sessions": 0, "completed": 0, "failed": 0, "energy_kwh": 0.0, "charging_mins": 0})
    for s in sessions:
        w = s["weather_condition"]
        wd = weather_dict[w]
        wd["sessions"] += 1
        if s["session_status"] == "Completed":
            wd["completed"] += 1
            wd["energy_kwh"] += float(s["energy_delivered_kwh"])
            wd["charging_mins"] += int(s["charging_duration_minutes"])
        elif s["session_status"] == "Failed":
            wd["failed"] += 1

    weather_rows = []
    for w, wd in weather_dict.items():
        tot = wd["sessions"]
        comp = wd["completed"]
        failed = wd["failed"]
        avg_energy = round(wd["energy_kwh"] / comp, 2) if comp > 0 else 0.0
        avg_dur = round(wd["charging_mins"] / comp, 1) if comp > 0 else 0.0
        fail_pct = round((failed / tot * 100) if tot > 0 else 0.0, 2)

        weather_rows.append({
            "weather_condition": w,
            "total_sessions": tot,
            "completed_sessions": comp,
            "failed_sessions": failed,
            "failure_rate_pct": fail_pct,
            "avg_energy_per_session_kwh": avg_energy,
            "avg_duration_minutes": avg_dur
        })

    weather_rows.sort(key=lambda x: x["total_sessions"], reverse=True)
    export_csv("weather_impact_summary.csv", weather_rows, list(weather_rows[0].keys()))

    print("KPI calculation completed successfully. All outputs generated in data/processed/.")


if __name__ == "__main__":
    main()
