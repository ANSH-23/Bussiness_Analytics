"""
EV Charging Station Analytics - Master Tableau Dashboard Builder
Builds the complete executive Tableau Packaged Workbook (.twbx)
containing 5 worksheets and one integrated 1400x900 executive dashboard.
"""

import os
import csv
from datetime import datetime
from collections import defaultdict
import zipfile
import xml.etree.ElementTree as ET

from tableauhyperapi import (
    HyperProcess,
    Telemetry,
    Connection,
    CreateMode,
    TableDefinition,
    SqlType,
    TableName,
    Inserter
)

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RAW_DIR = os.path.join(BASE_DIR, "data", "raw")
PROCESSED_DIR = os.path.join(BASE_DIR, "data", "processed")
OUTPUT_TWBX = os.path.join(BASE_DIR, "EV_Charging_Analytics.twbx")
HYPER_FILE = os.path.join(PROCESSED_DIR, "EV_Charging_Master.hyper")

print("Stage 1: Processing underlying analytical datasets...")

# 1. Station Summary
station_summary_rows = []
with open(os.path.join(PROCESSED_DIR, "station_summary.csv"), "r", encoding="utf-8") as f:
    r = csv.DictReader(f)
    for row in r:
        station_summary_rows.append(row)

# 2. Monthly Financials
monthly_rows = []
with open(os.path.join(PROCESSED_DIR, "monthly_financial_summary.csv"), "r", encoding="utf-8") as f:
    r = csv.DictReader(f)
    for row in r:
        monthly_rows.append(row)

# 3. Connector Performance
connector_rows = []
with open(os.path.join(PROCESSED_DIR, "connector_performance.csv"), "r", encoding="utf-8") as f:
    r = csv.DictReader(f)
    for row in r:
        connector_rows.append(row)

# 4. Hourly & Weekly Heatmap (168 cells: 7 days x 24 hours)
heatmap_dict = defaultdict(lambda: {"sessions": 0, "energy_kwh": 0.0, "revenue_inr": 0.0})
with open(os.path.join(RAW_DIR, "charging_sessions.csv"), "r", encoding="utf-8") as f:
    r = csv.DictReader(f)
    for row in r:
        if row["session_status"] == "Completed":
            dt = datetime.strptime(row["session_start"], "%Y-%m-%d %H:%M:%S")
            day_num = dt.weekday()  # 0=Monday, 6=Sunday
            day_name = dt.strftime("%A")
            hour = dt.hour
            key = (day_num, day_name, hour)
            heatmap_dict[key]["sessions"] += 1
            heatmap_dict[key]["energy_kwh"] += float(row["energy_delivered_kwh"])
            heatmap_dict[key]["revenue_inr"] += float(row["charging_revenue_inr"])

heatmap_rows = []
day_order_map = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
for (d_num, d_name, hr), vals in sorted(heatmap_dict.items(), key=lambda x: (x[0][0], x[0][2])):
    is_weekend = "Weekend" if d_name in ["Saturday", "Sunday"] else "Weekday"
    peak_flag = "Morning Peak (08-11)" if 8 <= hr <= 11 else ("Evening Peak (17-21)" if 17 <= hr <= 21 else ("Midday (12-16)" if 12 <= hr <= 16 else "Off-Peak Night"))
    heatmap_rows.append({
        "day_sort": d_num + 1,
        "day_name": d_name,
        "hour_of_day": hr,
        "day_type": is_weekend,
        "peak_category": peak_flag,
        "total_sessions": vals["sessions"],
        "energy_delivered_kwh": round(vals["energy_kwh"], 2),
        "charging_revenue_inr": round(vals["revenue_inr"], 2)
    })

# 5. Downtime Pareto Analysis
dt_counts = defaultdict(int)
dt_mins = defaultdict(int)
dt_costs = defaultdict(float)
with open(os.path.join(RAW_DIR, "station_downtime.csv"), "r", encoding="utf-8") as f:
    r = csv.DictReader(f)
    for row in r:
        reason = row["downtime_reason"]
        dt_counts[reason] += 1
        dt_mins[reason] += int(row["downtime_duration_minutes"])
        dt_costs[reason] += float(row["maintenance_cost_inr"])

total_dt_mins = sum(dt_mins.values())
sorted_reasons = sorted(dt_mins.keys(), key=lambda x: dt_mins[x], reverse=True)
downtime_rows = []
running_pct = 0.0
# Realized network revenue per operating hour
rev_per_operating_hour = 4300909.43 / (50 * 24 * 182) # approx 19.69 INR/port-hr
for r_name in sorted_reasons:
    m = dt_mins[r_name]
    hrs = round(m / 60.0, 1)
    share = round((m / total_dt_mins) * 100, 2)
    running_pct += share
    lost_rev = round(hrs * 50 * rev_per_operating_hour * (share / 100.0), 2)
    downtime_rows.append({
        "downtime_reason": r_name,
        "outage_events": dt_counts[r_name],
        "downtime_minutes": m,
        "downtime_hours": hrs,
        "pct_share": share,
        "cumulative_pct": round(min(running_pct, 100.0), 2),
        "repair_cost_inr": round(dt_costs[r_name], 2),
        "estimated_lost_revenue_inr": lost_rev
    })

print(f"Stage 1 complete: Prepared {len(station_summary_rows)} stations, {len(monthly_rows)} months, {len(connector_rows)} connectors, {len(heatmap_rows)} heatmap cells, and {len(downtime_rows)} downtime root-causes.")

print("Stage 2: Building multi-table Tableau Hyper database...")
if os.path.exists(HYPER_FILE):
    os.remove(HYPER_FILE)

with HyperProcess(telemetry=Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hyper:
    with Connection(endpoint=hyper.endpoint, database=HYPER_FILE, create_mode=CreateMode.CREATE_AND_REPLACE) as connection:
        connection.catalog.create_schema("Extract")

        # Table 1: station_summary
        t1 = TableDefinition(TableName("Extract", "station_summary"))
        for col in ["station_id", "station_name", "area", "station_type"]:
            t1.add_column(col, SqlType.text())
        for col in ["total_connectors", "total_sessions", "completed_sessions", "failed_sessions", "available_minutes", "active_charging_minutes", "downtime_minutes"]:
            t1.add_column(col, SqlType.big_int())
        for col in ["session_success_rate_pct", "energy_delivered_kwh", "charging_revenue_inr", "electricity_cost_inr", "gross_profit_inr", "staff_cost_inr", "rent_cost_inr", "maintenance_cost_inr", "other_operating_cost_inr", "total_operating_cost_inr", "operating_profit_inr", "operating_margin_pct", "utilization_rate"]:
            t1.add_column(col, SqlType.double())
        connection.catalog.create_table(t1)
        with Inserter(connection, t1) as ins:
            for row in station_summary_rows:
                ins.add_row([
                    row["station_id"], row["station_name"], row["area"], row["station_type"],
                    int(row["total_connectors"]), int(row["total_sessions"]), int(row["completed_sessions"]), int(row["failed_sessions"]),
                    int(row["available_minutes"]), int(row["active_charging_minutes"]), int(row["downtime_minutes"]),
                    float(row["session_success_rate_pct"]), float(row["energy_delivered_kwh"]), float(row["charging_revenue_inr"]),
                    float(row["electricity_cost_inr"]), float(row["gross_profit_inr"]), float(row["staff_cost_inr"]),
                    float(row["rent_cost_inr"]), float(row["maintenance_cost_inr"]), float(row["other_operating_cost_inr"]),
                    float(row["total_operating_cost_inr"]), float(row["operating_profit_inr"]), float(row["operating_margin_pct"]),
                    float(row["utilization_rate"])
                ])
            ins.execute()

        # Table 2: monthly_financials
        t2 = TableDefinition(TableName("Extract", "monthly_financials"))
        t2.add_column("month", SqlType.text())
        t2.add_column("total_sessions", SqlType.big_int())
        t2.add_column("completed_sessions", SqlType.big_int())
        for col in ["energy_delivered_kwh", "charging_revenue_inr", "electricity_cost_inr", "gross_profit_inr", "operating_expenses_inr", "total_costs_inr", "operating_profit_inr", "operating_margin_pct", "revenue_mom_growth_pct"]:
            t2.add_column(col, SqlType.double())
        connection.catalog.create_table(t2)
        with Inserter(connection, t2) as ins:
            for row in monthly_rows:
                ins.add_row([
                    row["month"], int(row["total_sessions"]), int(row["completed_sessions"]),
                    float(row["energy_delivered_kwh"]), float(row["charging_revenue_inr"]), float(row["electricity_cost_inr"]),
                    float(row["gross_profit_inr"]), float(row["operating_expenses_inr"]), float(row["total_costs_inr"]),
                    float(row["operating_profit_inr"]), float(row["operating_margin_pct"]), float(row["revenue_mom_growth_pct"])
                ])
            ins.execute()

        # Table 3: heatmap_demand
        t3 = TableDefinition(TableName("Extract", "heatmap_demand"))
        t3.add_column("day_sort", SqlType.big_int())
        t3.add_column("day_name", SqlType.text())
        t3.add_column("hour_of_day", SqlType.big_int())
        t3.add_column("day_type", SqlType.text())
        t3.add_column("peak_category", SqlType.text())
        t3.add_column("total_sessions", SqlType.big_int())
        t3.add_column("energy_delivered_kwh", SqlType.double())
        t3.add_column("charging_revenue_inr", SqlType.double())
        connection.catalog.create_table(t3)
        with Inserter(connection, t3) as ins:
            for row in heatmap_rows:
                ins.add_row([
                    row["day_sort"], row["day_name"], row["hour_of_day"], row["day_type"],
                    row["peak_category"], row["total_sessions"], row["energy_delivered_kwh"], row["charging_revenue_inr"]
                ])
            ins.execute()

        # Table 4: connector_performance
        t4 = TableDefinition(TableName("Extract", "connector_performance"))
        for col in ["connector_id", "station_id", "station_name", "connector_type"]:
            t4.add_column(col, SqlType.text())
        for col in ["total_sessions", "completed_sessions", "failed_sessions", "active_charging_minutes", "downtime_minutes"]:
            t4.add_column(col, SqlType.big_int())
        for col in ["rated_power_kw", "failure_rate_pct", "energy_delivered_kwh", "charging_revenue_inr", "electricity_cost_inr", "gross_profit_inr", "utilization_rate"]:
            t4.add_column(col, SqlType.double())
        connection.catalog.create_table(t4)
        with Inserter(connection, t4) as ins:
            for row in connector_rows:
                ins.add_row([
                    row["connector_id"], row["station_id"], row["station_name"], row["connector_type"],
                    int(row["total_sessions"]), int(row["completed_sessions"]), int(row["failed_sessions"]),
                    int(row["active_charging_minutes"]), int(row["downtime_minutes"]),
                    float(row["rated_power_kw"]), float(row["failure_rate_pct"]), float(row["energy_delivered_kwh"]),
                    float(row["charging_revenue_inr"]), float(row["electricity_cost_inr"]), float(row["gross_profit_inr"]),
                    float(row["utilization_rate"])
                ])
            ins.execute()

        # Table 5: downtime_pareto
        t5 = TableDefinition(TableName("Extract", "downtime_pareto"))
        t5.add_column("downtime_reason", SqlType.text())
        t5.add_column("outage_events", SqlType.big_int())
        t5.add_column("downtime_minutes", SqlType.big_int())
        for col in ["downtime_hours", "pct_share", "cumulative_pct", "repair_cost_inr", "estimated_lost_revenue_inr"]:
            t5.add_column(col, SqlType.double())
        connection.catalog.create_table(t5)
        with Inserter(connection, t5) as ins:
            for row in downtime_rows:
                ins.add_row([
                    row["downtime_reason"], row["outage_events"], row["downtime_minutes"],
                    row["downtime_hours"], row["pct_share"], row["cumulative_pct"],
                    row["repair_cost_inr"], row["estimated_lost_revenue_inr"]
                ])
            ins.execute()

print("Stage 2 complete: Hyper database populated successfully with all 5 analytical tables.")

print("Stage 3: Generating native Tableau Packaged Workbook (.twbx)...")

# We build the master .twb XML connecting to the internal Data/Extracts/EV_Charging_Master.hyper file
twb_xml = """<?xml version='1.0' encoding='utf-8' ?>

<!-- build 20263.26.1022.1645                               -->
<workbook original-version='18.1' source-build='2026.3.0 (20263.26.1022.1645)' version='18.1' xmlns:user='http://www.tableausoftware.com/xml/user'>
  <document-format-change-manifest>
    <WindowsPersistSimpleIdentifiers />
  </document-format-change-manifest>
  <preferences>
    <preference name='ui.encoding.shelf.height' value='24' />
    <preference name='ui.shelf.height' value='26' />
  </preferences>
  <datasources>
    <datasource caption='station_summary' inline='true' name='federated.station_summary' version='18.1'>
      <connection class='federated'>
        <named-connections>
          <named-connection caption='EV_Charging_Master' name='hyper.station_summary'>
            <connection authentication='auth-none' author-locale='en_US' class='hyper' dbname='Data/Extracts/EV_Charging_Master.hyper' default-settings='hyper' schema='Extract' sslmode='' tablename='station_summary' username='tableau_internal_user' />
          </named-connection>
        </named-connections>
        <relation connection='hyper.station_summary' name='station_summary' table='[Extract].[station_summary]' type='table' />
        <metadata-records>
          <metadata-record class='column'>
            <remote-name>station_id</remote-name>
            <remote-type>129</remote-type>
            <local-name>[station_id]</local-name>
            <parent-name>[station_summary]</parent-name>
            <remote-alias>station_id</remote-alias>
            <ordinal>0</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>station_name</remote-name>
            <remote-type>129</remote-type>
            <local-name>[station_name]</local-name>
            <parent-name>[station_summary]</parent-name>
            <remote-alias>station_name</remote-alias>
            <ordinal>1</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>area</remote-name>
            <remote-type>129</remote-type>
            <local-name>[area]</local-name>
            <parent-name>[station_summary]</parent-name>
            <remote-alias>area</remote-alias>
            <ordinal>2</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>station_type</remote-name>
            <remote-type>129</remote-type>
            <local-name>[station_type]</local-name>
            <parent-name>[station_summary]</parent-name>
            <remote-alias>station_type</remote-alias>
            <ordinal>3</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>charging_revenue_inr</remote-name>
            <remote-type>5</remote-type>
            <local-name>[charging_revenue_inr]</local-name>
            <parent-name>[station_summary]</parent-name>
            <remote-alias>charging_revenue_inr</remote-alias>
            <ordinal>12</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>operating_profit_inr</remote-name>
            <remote-type>5</remote-type>
            <local-name>[operating_profit_inr]</local-name>
            <parent-name>[station_summary]</parent-name>
            <remote-alias>operating_profit_inr</remote-alias>
            <ordinal>20</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>operating_margin_pct</remote-name>
            <remote-type>5</remote-type>
            <local-name>[operating_margin_pct]</local-name>
            <parent-name>[station_summary]</parent-name>
            <remote-alias>operating_margin_pct</remote-alias>
            <ordinal>21</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>utilization_rate</remote-name>
            <remote-type>5</remote-type>
            <local-name>[utilization_rate]</local-name>
            <parent-name>[station_summary]</parent-name>
            <remote-alias>utilization_rate</remote-alias>
            <ordinal>22</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
        </metadata-records>
      </connection>
      <aliases enabled='yes' />
      <column caption='Area' datatype='string' name='[area]' role='dimension' type='nominal' />
      <column caption='Charging Revenue (INR)' datatype='real' default-format='c&quot;₹&quot;#,##0;(&quot;₹&quot;#,##0)' name='[charging_revenue_inr]' role='measure' type='quantitative' />
      <column caption='Operating Profit (INR)' datatype='real' default-format='c&quot;₹&quot;#,##0;(&quot;₹&quot;#,##0)' name='[operating_profit_inr]' role='measure' type='quantitative' />
      <column caption='Operating Margin %' datatype='real' default-format='p0.0%' name='[operating_margin_pct]' role='measure' type='quantitative' />
      <column caption='Station ID' datatype='string' name='[station_id]' role='dimension' type='nominal' />
      <column caption='Station Name' datatype='string' name='[station_name]' role='dimension' type='nominal' />
      <column caption='Station Type' datatype='string' name='[station_type]' role='dimension' type='nominal' />
      <column caption='Utilization Rate' datatype='real' default-format='p0.0%' name='[utilization_rate]' role='measure' type='quantitative' />
      <layout dim-ordering='alphabetic' dim-percentage='0.5' measure-ordering='alphabetic' measure-percentage='0.4' show-structure='true' />
    </datasource>

    <datasource caption='monthly_financials' inline='true' name='federated.monthly_financials' version='18.1'>
      <connection class='federated'>
        <named-connections>
          <named-connection caption='EV_Charging_Master' name='hyper.monthly_financials'>
            <connection authentication='auth-none' author-locale='en_US' class='hyper' dbname='Data/Extracts/EV_Charging_Master.hyper' default-settings='hyper' schema='Extract' sslmode='' tablename='monthly_financials' username='tableau_internal_user' />
          </named-connection>
        </named-connections>
        <relation connection='hyper.monthly_financials' name='monthly_financials' table='[Extract].[monthly_financials]' type='table' />
        <metadata-records>
          <metadata-record class='column'>
            <remote-name>month</remote-name>
            <remote-type>129</remote-type>
            <local-name>[month]</local-name>
            <parent-name>[monthly_financials]</parent-name>
            <remote-alias>month</remote-alias>
            <ordinal>0</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>charging_revenue_inr</remote-name>
            <remote-type>5</remote-type>
            <local-name>[charging_revenue_inr]</local-name>
            <parent-name>[monthly_financials]</parent-name>
            <remote-alias>charging_revenue_inr</remote-alias>
            <ordinal>4</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>total_costs_inr</remote-name>
            <remote-type>5</remote-type>
            <local-name>[total_costs_inr]</local-name>
            <parent-name>[monthly_financials]</parent-name>
            <remote-alias>total_costs_inr</remote-alias>
            <ordinal>8</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>operating_profit_inr</remote-name>
            <remote-type>5</remote-type>
            <local-name>[operating_profit_inr]</local-name>
            <parent-name>[monthly_financials]</parent-name>
            <remote-alias>operating_profit_inr</remote-alias>
            <ordinal>9</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
        </metadata-records>
      </connection>
      <aliases enabled='yes' />
      <column caption='Month' datatype='string' name='[month]' role='dimension' type='nominal' />
      <column caption='Charging Revenue (INR)' datatype='real' default-format='c&quot;₹&quot;#,##0;(&quot;₹&quot;#,##0)' name='[charging_revenue_inr]' role='measure' type='quantitative' />
      <column caption='Total Costs (INR)' datatype='real' default-format='c&quot;₹&quot;#,##0;(&quot;₹&quot;#,##0)' name='[total_costs_inr]' role='measure' type='quantitative' />
      <column caption='Operating Profit (INR)' datatype='real' default-format='c&quot;₹&quot;#,##0;(&quot;₹&quot;#,##0)' name='[operating_profit_inr]' role='measure' type='quantitative' />
      <layout dim-ordering='alphabetic' dim-percentage='0.5' measure-ordering='alphabetic' measure-percentage='0.4' show-structure='true' />
    </datasource>

    <datasource caption='heatmap_demand' inline='true' name='federated.heatmap_demand' version='18.1'>
      <connection class='federated'>
        <named-connections>
          <named-connection caption='EV_Charging_Master' name='hyper.heatmap_demand'>
            <connection authentication='auth-none' author-locale='en_US' class='hyper' dbname='Data/Extracts/EV_Charging_Master.hyper' default-settings='hyper' schema='Extract' sslmode='' tablename='heatmap_demand' username='tableau_internal_user' />
          </named-connection>
        </named-connections>
        <relation connection='hyper.heatmap_demand' name='heatmap_demand' table='[Extract].[heatmap_demand]' type='table' />
        <metadata-records>
          <metadata-record class='column'>
            <remote-name>day_name</remote-name>
            <remote-type>129</remote-type>
            <local-name>[day_name]</local-name>
            <parent-name>[heatmap_demand]</parent-name>
            <remote-alias>day_name</remote-alias>
            <ordinal>1</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>hour_of_day</remote-name>
            <remote-type>20</remote-type>
            <local-name>[hour_of_day]</local-name>
            <parent-name>[heatmap_demand]</parent-name>
            <remote-alias>hour_of_day</remote-alias>
            <ordinal>2</ordinal>
            <local-type>integer</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>total_sessions</remote-name>
            <remote-type>20</remote-type>
            <local-name>[total_sessions]</local-name>
            <parent-name>[heatmap_demand]</parent-name>
            <remote-alias>total_sessions</remote-alias>
            <ordinal>5</ordinal>
            <local-type>integer</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
        </metadata-records>
      </connection>
      <aliases enabled='yes' />
      <column caption='Day of Week' datatype='string' name='[day_name]' role='dimension' type='nominal' />
      <column caption='Hour of Day' datatype='integer' name='[hour_of_day]' role='dimension' type='ordinal' />
      <column caption='Completed Sessions' datatype='integer' name='[total_sessions]' role='measure' type='quantitative' />
      <layout dim-ordering='alphabetic' dim-percentage='0.5' measure-ordering='alphabetic' measure-percentage='0.4' show-structure='true' />
    </datasource>

    <datasource caption='connector_performance' inline='true' name='federated.connector_performance' version='18.1'>
      <connection class='federated'>
        <named-connections>
          <named-connection caption='EV_Charging_Master' name='hyper.connector_performance'>
            <connection authentication='auth-none' author-locale='en_US' class='hyper' dbname='Data/Extracts/EV_Charging_Master.hyper' default-settings='hyper' schema='Extract' sslmode='' tablename='connector_performance' username='tableau_internal_user' />
          </named-connection>
        </named-connections>
        <relation connection='hyper.connector_performance' name='connector_performance' table='[Extract].[connector_performance]' type='table' />
        <metadata-records>
          <metadata-record class='column'>
            <remote-name>connector_id</remote-name>
            <remote-type>129</remote-type>
            <local-name>[connector_id]</local-name>
            <parent-name>[connector_performance]</parent-name>
            <remote-alias>connector_id</remote-alias>
            <ordinal>0</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>connector_type</remote-name>
            <remote-type>129</remote-type>
            <local-name>[connector_type]</local-name>
            <parent-name>[connector_performance]</parent-name>
            <remote-alias>connector_type</remote-alias>
            <ordinal>3</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>rated_power_kw</remote-name>
            <remote-type>5</remote-type>
            <local-name>[rated_power_kw]</local-name>
            <parent-name>[connector_performance]</parent-name>
            <remote-alias>rated_power_kw</remote-alias>
            <ordinal>9</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>charging_revenue_inr</remote-name>
            <remote-type>5</remote-type>
            <local-name>[charging_revenue_inr]</local-name>
            <parent-name>[connector_performance]</parent-name>
            <remote-alias>charging_revenue_inr</remote-alias>
            <ordinal>12</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>utilization_rate</remote-name>
            <remote-type>5</remote-type>
            <local-name>[utilization_rate]</local-name>
            <parent-name>[connector_performance]</parent-name>
            <remote-alias>utilization_rate</remote-alias>
            <ordinal>15</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
        </metadata-records>
      </connection>
      <aliases enabled='yes' />
      <column caption='Connector ID' datatype='string' name='[connector_id]' role='dimension' type='nominal' />
      <column caption='Connector Type' datatype='string' name='[connector_type]' role='dimension' type='nominal' />
      <column caption='Rated Power (kW)' datatype='real' name='[rated_power_kw]' role='measure' type='quantitative' />
      <column caption='Revenue per Port (INR)' datatype='real' default-format='c&quot;₹&quot;#,##0;(&quot;₹&quot;#,##0)' name='[charging_revenue_inr]' role='measure' type='quantitative' />
      <column caption='Utilization Rate' datatype='real' default-format='p0.0%' name='[utilization_rate]' role='measure' type='quantitative' />
      <layout dim-ordering='alphabetic' dim-percentage='0.5' measure-ordering='alphabetic' measure-percentage='0.4' show-structure='true' />
    </datasource>

    <datasource caption='downtime_pareto' inline='true' name='federated.downtime_pareto' version='18.1'>
      <connection class='federated'>
        <named-connections>
          <named-connection caption='EV_Charging_Master' name='hyper.downtime_pareto'>
            <connection authentication='auth-none' author-locale='en_US' class='hyper' dbname='Data/Extracts/EV_Charging_Master.hyper' default-settings='hyper' schema='Extract' sslmode='' tablename='downtime_pareto' username='tableau_internal_user' />
          </named-connection>
        </named-connections>
        <relation connection='hyper.downtime_pareto' name='downtime_pareto' table='[Extract].[downtime_pareto]' type='table' />
        <metadata-records>
          <metadata-record class='column'>
            <remote-name>downtime_reason</remote-name>
            <remote-type>129</remote-type>
            <local-name>[downtime_reason]</local-name>
            <parent-name>[downtime_pareto]</parent-name>
            <remote-alias>downtime_reason</remote-alias>
            <ordinal>0</ordinal>
            <local-type>string</local-type>
            <aggregation>Count</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>downtime_hours</remote-name>
            <remote-type>5</remote-type>
            <local-name>[downtime_hours]</local-name>
            <parent-name>[downtime_pareto]</parent-name>
            <remote-alias>downtime_hours</remote-alias>
            <ordinal>3</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
          <metadata-record class='column'>
            <remote-name>cumulative_pct</remote-name>
            <remote-type>5</remote-type>
            <local-name>[cumulative_pct]</local-name>
            <parent-name>[downtime_pareto]</parent-name>
            <remote-alias>cumulative_pct</remote-alias>
            <ordinal>5</ordinal>
            <local-type>real</local-type>
            <aggregation>Sum</aggregation>
            <contains-null>true</contains-null>
          </metadata-record>
        </metadata-records>
      </connection>
      <aliases enabled='yes' />
      <column caption='Downtime Root Cause' datatype='string' name='[downtime_reason]' role='dimension' type='nominal' />
      <column caption='Outage Duration (Hours)' datatype='real' name='[downtime_hours]' role='measure' type='quantitative' />
      <column caption='Cumulative Share %' datatype='real' default-format='p0.0%' name='[cumulative_pct]' role='measure' type='quantitative' />
      <layout dim-ordering='alphabetic' dim-percentage='0.5' measure-ordering='alphabetic' measure-percentage='0.4' show-structure='true' />
    </datasource>
  </datasources>

  <worksheets>
    <!-- Sheet 1: Monthly Financial Trajectory -->
    <worksheet name='1. Monthly Financial Trajectory'>
      <table>
        <view>
          <datasources>
            <datasource caption='monthly_financials' name='federated.monthly_financials' />
          </datasources>
          <datasource-dependencies datasource='federated.monthly_financials'>
            <column caption='Month' datatype='string' name='[month]' role='dimension' type='nominal' />
            <column caption='Charging Revenue (INR)' datatype='real' name='[charging_revenue_inr]' role='measure' type='quantitative' />
            <column caption='Total Costs (INR)' datatype='real' name='[total_costs_inr]' role='measure' type='quantitative' />
            <column-instance column='[month]' derivation='None' name='[none:month:nk]' pivot='key' type='nominal' />
            <column-instance column='[charging_revenue_inr]' derivation='Sum' name='[sum:charging_revenue_inr:qk]' pivot='key' type='quantitative' />
            <column-instance column='[total_costs_inr]' derivation='Sum' name='[sum:total_costs_inr:qk]' pivot='key' type='quantitative' />
          </datasource-dependencies>
          <aggregation value='true' />
        </view>
        <style />
        <panes>
          <pane selection-relaxation-option='selection-relaxation-allow'>
            <view>
              <breakdown value='auto' />
            </view>
            <mark class='Bar' />
            <encodings>
              <color column='[federated.monthly_financials].[sum:charging_revenue_inr:qk]' />
            </encodings>
          </pane>
        </panes>
        <rows>[federated.monthly_financials].[sum:charging_revenue_inr:qk]</rows>
        <cols>[federated.monthly_financials].[none:month:nk]</cols>
      </table>
    </worksheet>

    <!-- Sheet 2: Station Profitability Ranking -->
    <worksheet name='2. Station Profitability Ranking'>
      <table>
        <view>
          <datasources>
            <datasource caption='station_summary' name='federated.station_summary' />
          </datasources>
          <datasource-dependencies datasource='federated.station_summary'>
            <column caption='Station Name' datatype='string' name='[station_name]' role='dimension' type='nominal' />
            <column caption='Operating Profit (INR)' datatype='real' name='[operating_profit_inr]' role='measure' type='quantitative' />
            <column-instance column='[station_name]' derivation='None' name='[none:station_name:nk]' pivot='key' type='nominal' />
            <column-instance column='[operating_profit_inr]' derivation='Sum' name='[sum:operating_profit_inr:qk]' pivot='key' type='quantitative' />
          </datasource-dependencies>
          <aggregation value='true' />
        </view>
        <style />
        <panes>
          <pane selection-relaxation-option='selection-relaxation-allow'>
            <view>
              <breakdown value='auto' />
            </view>
            <mark class='Bar' />
            <encodings>
              <color column='[federated.station_summary].[sum:operating_profit_inr:qk]' />
            </encodings>
          </pane>
        </panes>
        <rows>[federated.station_summary].[none:station_name:nk]</rows>
        <cols>[federated.station_summary].[sum:operating_profit_inr:qk]</cols>
      </table>
    </worksheet>

    <!-- Sheet 3: Hourly & Weekly Demand Heatmap -->
    <worksheet name='3. Hourly &amp; Weekly Demand Heatmap'>
      <table>
        <view>
          <datasources>
            <datasource caption='heatmap_demand' name='federated.heatmap_demand' />
          </datasources>
          <datasource-dependencies datasource='federated.heatmap_demand'>
            <column caption='Day of Week' datatype='string' name='[day_name]' role='dimension' type='nominal' />
            <column caption='Hour of Day' datatype='integer' name='[hour_of_day]' role='dimension' type='ordinal' />
            <column caption='Completed Sessions' datatype='integer' name='[total_sessions]' role='measure' type='quantitative' />
            <column-instance column='[day_name]' derivation='None' name='[none:day_name:nk]' pivot='key' type='nominal' />
            <column-instance column='[hour_of_day]' derivation='None' name='[none:hour_of_day:ok]' pivot='key' type='ordinal' />
            <column-instance column='[total_sessions]' derivation='Sum' name='[sum:total_sessions:qk]' pivot='key' type='quantitative' />
          </datasource-dependencies>
          <aggregation value='true' />
        </view>
        <style />
        <panes>
          <pane selection-relaxation-option='selection-relaxation-allow'>
            <view>
              <breakdown value='auto' />
            </view>
            <mark class='Square' />
            <encodings>
              <color column='[federated.heatmap_demand].[sum:total_sessions:qk]' />
            </encodings>
          </pane>
        </panes>
        <rows>[federated.heatmap_demand].[none:day_name:nk]</rows>
        <cols>[federated.heatmap_demand].[none:hour_of_day:ok]</cols>
      </table>
    </worksheet>

    <!-- Sheet 4: Connector Utilization Quadrant -->
    <worksheet name='4. Connector Utilization Quadrant'>
      <table>
        <view>
          <datasources>
            <datasource caption='connector_performance' name='federated.connector_performance' />
          </datasources>
          <datasource-dependencies datasource='federated.connector_performance'>
            <column caption='Connector ID' datatype='string' name='[connector_id]' role='dimension' type='nominal' />
            <column caption='Connector Type' datatype='string' name='[connector_type]' role='dimension' type='nominal' />
            <column caption='Revenue per Port (INR)' datatype='real' name='[charging_revenue_inr]' role='measure' type='quantitative' />
            <column caption='Utilization Rate' datatype='real' name='[utilization_rate]' role='measure' type='quantitative' />
            <column-instance column='[connector_id]' derivation='None' name='[none:connector_id:nk]' pivot='key' type='nominal' />
            <column-instance column='[connector_type]' derivation='None' name='[none:connector_type:nk]' pivot='key' type='nominal' />
            <column-instance column='[charging_revenue_inr]' derivation='Sum' name='[sum:charging_revenue_inr:qk]' pivot='key' type='quantitative' />
            <column-instance column='[utilization_rate]' derivation='Sum' name='[sum:utilization_rate:qk]' pivot='key' type='quantitative' />
          </datasource-dependencies>
          <aggregation value='true' />
        </view>
        <style />
        <panes>
          <pane selection-relaxation-option='selection-relaxation-allow'>
            <view>
              <breakdown value='auto' />
            </view>
            <mark class='Circle' />
            <encodings>
              <color column='[federated.connector_performance].[none:connector_type:nk]' />
              <text column='[federated.connector_performance].[none:connector_id:nk]' />
            </encodings>
          </pane>
        </panes>
        <rows>[federated.connector_performance].[sum:charging_revenue_inr:qk]</rows>
        <cols>[federated.connector_performance].[sum:utilization_rate:qk]</cols>
      </table>
    </worksheet>

    <!-- Sheet 5: Downtime Pareto Analysis -->
    <worksheet name='5. Downtime Pareto Analysis'>
      <table>
        <view>
          <datasources>
            <datasource caption='downtime_pareto' name='federated.downtime_pareto' />
          </datasources>
          <datasource-dependencies datasource='federated.downtime_pareto'>
            <column caption='Downtime Root Cause' datatype='string' name='[downtime_reason]' role='dimension' type='nominal' />
            <column caption='Outage Duration (Hours)' datatype='real' name='[downtime_hours]' role='measure' type='quantitative' />
            <column-instance column='[downtime_reason]' derivation='None' name='[none:downtime_reason:nk]' pivot='key' type='nominal' />
            <column-instance column='[downtime_hours]' derivation='Sum' name='[sum:downtime_hours:qk]' pivot='key' type='quantitative' />
          </datasource-dependencies>
          <aggregation value='true' />
        </view>
        <style />
        <panes>
          <pane selection-relaxation-option='selection-relaxation-allow'>
            <view>
              <breakdown value='auto' />
            </view>
            <mark class='Bar' />
            <encodings>
              <color column='[federated.downtime_pareto].[none:downtime_reason:nk]' />
            </encodings>
          </pane>
        </panes>
        <rows>[federated.downtime_pareto].[sum:downtime_hours:qk]</rows>
        <cols>[federated.downtime_pareto].[none:downtime_reason:nk]</cols>
      </table>
    </worksheet>
  </worksheets>

  <dashboards>
    <dashboard name='Executive Operations &amp; Profitability Dashboard'>
      <style />
      <size maxheight='900' maxwidth='1400' minheight='900' minwidth='1400' />
      <zones>
        <zone h='100000' id='4' type-v2='layout-basic' w='100000' x='0' y='0'>
          <zone h='98000' id='5' param='vert' type-v2='layout-flow' w='98000' x='1000' y='1000'>
            <!-- Row 1: Monthly Financials & Station Profitability -->
            <zone h='48000' id='6' param='horz' type-v2='layout-flow' w='98000' x='1000' y='1000'>
              <zone h='48000' id='1' name='1. Monthly Financial Trajectory' w='49000' x='1000' y='1000' />
              <zone h='48000' id='2' name='2. Station Profitability Ranking' w='49000' x='50000' y='1000' />
            </zone>
            <!-- Row 2: Heatmap & Connector Performance -->
            <zone h='48000' id='7' param='horz' type-v2='layout-flow' w='98000' x='1000' y='50000'>
              <zone h='48000' id='3' name='3. Hourly &amp; Weekly Demand Heatmap' w='49000' x='1000' y='50000' />
              <zone h='48000' id='8' name='4. Connector Utilization Quadrant' w='49000' x='50000' y='50000' />
            </zone>
          </zone>
        </zone>
      </zones>
    </dashboard>
  </dashboards>

  <windows saved-dpi-scale-factor='1.25' source-height='37'>
    <window class='worksheet' name='1. Monthly Financial Trajectory'>
      <cards>
        <edge name='left'>
          <strip size='160'>
            <card type='pages' />
            <card type='filters' />
            <card type='marks' />
          </strip>
        </edge>
        <edge name='top'>
          <strip size='2147483647'>
            <card type='columns' />
          </strip>
          <strip size='2147483647'>
            <card type='rows' />
          </strip>
        </edge>
      </cards>
    </window>
    <window class='worksheet' name='2. Station Profitability Ranking'>
      <cards>
        <edge name='left'>
          <strip size='160'>
            <card type='pages' />
            <card type='filters' />
            <card type='marks' />
          </strip>
        </edge>
        <edge name='top'>
          <strip size='2147483647'>
            <card type='columns' />
          </strip>
          <strip size='2147483647'>
            <card type='rows' />
          </strip>
        </edge>
      </cards>
    </window>
    <window class='worksheet' name='3. Hourly &amp; Weekly Demand Heatmap'>
      <cards>
        <edge name='left'>
          <strip size='160'>
            <card type='pages' />
            <card type='filters' />
            <card type='marks' />
          </strip>
        </edge>
        <edge name='top'>
          <strip size='2147483647'>
            <card type='columns' />
          </strip>
          <strip size='2147483647'>
            <card type='rows' />
          </strip>
        </edge>
      </cards>
    </window>
    <window class='worksheet' name='4. Connector Utilization Quadrant'>
      <cards>
        <edge name='left'>
          <strip size='160'>
            <card type='pages' />
            <card type='filters' />
            <card type='marks' />
          </strip>
        </edge>
        <edge name='top'>
          <strip size='2147483647'>
            <card type='columns' />
          </strip>
          <strip size='2147483647'>
            <card type='rows' />
          </strip>
        </edge>
      </cards>
    </window>
    <window class='worksheet' name='5. Downtime Pareto Analysis'>
      <cards>
        <edge name='left'>
          <strip size='160'>
            <card type='pages' />
            <card type='filters' />
            <card type='marks' />
          </strip>
        </edge>
        <edge name='top'>
          <strip size='2147483647'>
            <card type='columns' />
          </strip>
          <strip size='2147483647'>
            <card type='rows' />
          </strip>
        </edge>
      </cards>
    </window>
    <window class='dashboard' maximized='true' name='Executive Operations &amp; Profitability Dashboard'>
      <viewpoints>
        <viewpoint name='1. Monthly Financial Trajectory'>
          <zoom type='entire-view' />
        </viewpoint>
        <viewpoint name='2. Station Profitability Ranking'>
          <zoom type='entire-view' />
        </viewpoint>
        <viewpoint name='3. Hourly &amp; Weekly Demand Heatmap'>
          <zoom type='entire-view' />
        </viewpoint>
        <viewpoint name='4. Connector Utilization Quadrant'>
          <zoom type='entire-view' />
        </viewpoint>
      </viewpoints>
      <active id='-1' />
    </window>
  </windows>
</workbook>
"""

# Verify XML well-formedness
try:
    ET.fromstring(twb_xml)
    print("XML Syntax validated successfully!")
except Exception as e:
    print("XML Error:", e)
    raise

# Package into .twbx
if os.path.exists(OUTPUT_TWBX):
    os.remove(OUTPUT_TWBX)

with zipfile.ZipFile(OUTPUT_TWBX, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("EV_Charging_Analytics.twb", twb_xml.encode("utf-8"))
    z.write(HYPER_FILE, "Data/Extracts/EV_Charging_Master.hyper")

# Copy to root directory as well
import shutil
shutil.copyfile(OUTPUT_TWBX, os.path.join(BASE_DIR, "..", "EV_Charging_Analytics.twbx"))

print("Stage 3 complete: Packaged workbook created successfully at:")
print(" - " + OUTPUT_TWBX)
print(" - " + os.path.join(BASE_DIR, "..", "EV_Charging_Analytics.twbx"))

