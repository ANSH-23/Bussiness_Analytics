"""
EV Charging Station Analytics - Tableau Data Export Engine
Author: Senior Tableau Developer & Data Architect
Description:
    Prepares clean, normalized, and optimized CSV datasets in data/tableau/ specifically formatted
    for Tableau Desktop and Tableau Public.
    Includes relational tables that avoid double-counting pitfalls, along with enriched
    date/time dimensions and calculated helper fields for seamless drag-and-drop dashboard creation.
"""

import os
import csv
import shutil

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RAW_DIR = os.path.join(BASE_DIR, "data", "raw")
TABLEAU_DIR = os.path.join(BASE_DIR, "data", "tableau")

os.makedirs(TABLEAU_DIR, exist_ok=True)


def load_csv(filename):
    filepath = os.path.join(RAW_DIR, filename)
    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader), reader.fieldnames


def export_csv(filename, rows, fieldnames):
    filepath = os.path.join(TABLEAU_DIR, filename)
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Tableau Export: {filename} ({len(rows)} records)")


def main():
    print("Preparing Tableau-compatible datasets in data/tableau/...")

    # 1. Stations Master
    stations, st_fields = load_csv("stations.csv")
    export_csv("tableau_stations.csv", stations, st_fields)

    # 2. Connectors Master (enriched with station area)
    connectors, c_fields = load_csv("connectors.csv")
    st_map = {s["station_id"]: s for s in stations}
    enriched_connectors = []
    for c in connectors:
        st = st_map[c["station_id"]]
        row = dict(c)
        row["station_name"] = st["station_name"]
        row["station_area"] = st["area"]
        enriched_connectors.append(row)
    conn_fields = list(c_fields) + ["station_name", "station_area"]
    export_csv("tableau_connectors.csv", enriched_connectors, conn_fields)

    # 3. Charging Sessions (Enriched with Date/Hour dimensions and Gross Margin)
    sessions, ses_fields = load_csv("charging_sessions.csv")
    enriched_sessions = []
    for s in sessions:
        row = dict(s)
        # Parse timestamp for dimension slicing
        st_dt = row["session_start"]
        row["session_date"] = st_dt[:10]
        row["session_hour"] = int(st_dt[11:13])
        row["session_month"] = st_dt[:7]
        # Calculate gross margin
        elec_cost = round(float(row["energy_delivered_kwh"]) * float(row["electricity_tariff_per_kwh_inr"]), 2)
        row["electricity_cost_inr"] = elec_cost
        row["gross_margin_inr"] = round(float(row["charging_revenue_inr"]) - elec_cost, 2)
        enriched_sessions.append(row)

    ses_fields_enriched = list(ses_fields) + [
        "session_date", "session_hour", "session_month",
        "electricity_cost_inr", "gross_margin_inr"
    ]
    export_csv("tableau_charging_sessions.csv", enriched_sessions, ses_fields_enriched)

    # 4. Station Downtime
    downtime, dt_fields = load_csv("station_downtime.csv")
    enriched_downtime = []
    for d in downtime:
        row = dict(d)
        row["downtime_date"] = row["downtime_start"][:10]
        row["downtime_month"] = row["downtime_start"][:7]
        enriched_downtime.append(row)
    dt_fields_enriched = list(dt_fields) + ["downtime_date", "downtime_month"]
    export_csv("tableau_station_downtime.csv", enriched_downtime, dt_fields_enriched)

    # 5. Daily Station Operating Costs
    daily_costs, cost_fields = load_csv("daily_station_operating_costs.csv")
    enriched_costs = []
    for c in daily_costs:
        row = dict(c)
        tot_opex = round(
            float(row["electricity_cost_inr"]) + float(row["staff_cost_inr"]) +
            float(row["rent_cost_inr"]) + float(row["maintenance_cost_inr"]) +
            float(row["other_operating_cost_inr"]), 2
        )
        row["total_daily_operating_cost_inr"] = tot_opex
        row["operating_month"] = row["operating_date"][:7]
        enriched_costs.append(row)
    cost_fields_enriched = list(cost_fields) + ["total_daily_operating_cost_inr", "operating_month"]
    export_csv("tableau_daily_station_operating_costs.csv", enriched_costs, cost_fields_enriched)

    # 6. Station Daily KPIs (Pre-aggregated daily metrics for high-level cards and trends)
    kpis, kpi_fields = load_csv("station_daily_kpis.csv")
    enriched_kpis = []
    for k in kpis:
        row = dict(k)
        row["kpi_month"] = row["operating_date"][:7]
        st = st_map[k["station_id"]]
        row["station_name"] = st["station_name"]
        row["area"] = st["area"]
        enriched_kpis.append(row)
    kpi_fields_enriched = list(kpi_fields) + ["kpi_month", "station_name", "area"]
    export_csv("tableau_station_daily_kpis.csv", enriched_kpis, kpi_fields_enriched)

    print("All Tableau export files successfully generated in data/tableau/!")


if __name__ == "__main__":
    main()
