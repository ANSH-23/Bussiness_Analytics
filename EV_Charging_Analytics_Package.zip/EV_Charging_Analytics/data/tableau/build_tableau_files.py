#!/usr/bin/env python3
"""
build_tableau_files.py
Creates two denormalised, Tableau-ready CSVs from the six source files (synthetic data):

  tableau/tableau_sessions_flat.csv   one row per session  (23,325 rows)
  tableau/tableau_station_daily.csv   one row per station-day (1,830 rows)

Usage: python build_tableau_files.py --data data --out tableau
Standard library only. Reconciles totals against the source files before finishing.
"""
import argparse
import csv
import os
from collections import defaultdict
from datetime import datetime, time, timedelta, date
from decimal import Decimal, ROUND_HALF_UP

CENT = Decimal("0.01")
OPEN_HOUR = 6


def q2(x):
    return x.quantize(CENT, rounding=ROUND_HALF_UP)


def rd(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def charger_class(ctype, kw):
    if ctype == "AC Type 2":
        return "AC (slow/medium)"
    return "DC fast (<=50 kW)" if kw <= 50 else "DC rapid (>=60 kW)"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="tableau")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    st = {r["station_id"]: r for r in rd(f"{a.data}/stations.csv")}
    cn = {r["connector_id"]: r for r in rd(f"{a.data}/connectors.csv")}
    ses = rd(f"{a.data}/charging_sessions.csv")
    dtm = rd(f"{a.data}/station_downtime.csv")
    oc = rd(f"{a.data}/daily_station_operating_costs.csv")
    tar = defaultdict(list)
    for r in rd(f"{a.data}/tariff_history.csv"):
        tar[r["connector_id"]].append((r["effective_from"], r["effective_to"], Decimal(r["customer_price_per_kwh_inr"])))

    def price(cid, d):
        for f, t, p in tar[cid]:
            if f <= d <= t:
                return p
        raise ValueError((cid, d))

    # ---------------------------------------------------------------- sessions flat
    daily = defaultdict(lambda: defaultdict(lambda: Decimal("0")))
    out_rows = []
    for s in ses:
        start = datetime.strptime(s["session_start"], "%Y-%m-%d %H:%M:%S")
        d = start.date()
        c, S = cn[s["connector_id"]], st[s["station_id"]]
        energy, tariff = Decimal(s["energy_delivered_kwh"]), Decimal(s["electricity_tariff_per_kwh_inr"])
        billed = Decimal(s["charging_revenue_inr"])
        collected = billed if s["payment_status"] == "Paid" else Decimal("0.00")
        ecost = q2(energy * tariff)
        status = s["session_status"]
        kw = float(c["rated_power_kw"])
        out_rows.append([
            s["session_id"], s["session_start"], s["session_end"], d.isoformat(), start.hour, d.strftime("%a"),
            d.strftime("%Y-%m"), s["day_type"], s["weather_condition"],
            S["station_id"], S["station_name"], S["area"], S["station_type"], S["latitude"], S["longitude"],
            c["connector_id"], c["connector_type"], c["rated_power_kw"], f"{c['connector_type']} {kw:g} kW",
            charger_class(c["connector_type"], kw), s["vehicle_id"], status, s["payment_status"],
            f"{energy}", s["charging_duration_minutes"], s["idle_duration_minutes"], f"{tariff}",
            f"{price(s['connector_id'], d.isoformat())}", f"{billed}", f"{collected}", f"{ecost}",
            f"{billed - ecost}", int(status == "Completed"), int(status == "Failed"), int(status == "Cancelled")])
        k = (s["station_id"], d)
        g = daily[k]
        g["sessions"] += 1
        g["completed"] += status == "Completed"
        g["failed"] += status == "Failed"
        g["cancelled"] += status == "Cancelled"
        g["energy"] += energy
        g["charge_min"] += int(s["charging_duration_minutes"])
        g["billed"] += billed
        g["collected"] += collected
    hdr = ["session_id", "session_start", "session_end", "session_date", "start_hour", "day_name", "month",
           "day_type", "weather_condition", "station_id", "station_name", "area", "station_type", "latitude",
           "longitude", "connector_id", "connector_type", "rated_power_kw", "connector_label", "charger_class",
           "vehicle_id", "session_status", "payment_status", "energy_delivered_kwh", "charging_duration_minutes",
           "idle_duration_minutes", "electricity_tariff_per_kwh_inr", "customer_price_per_kwh_inr",
           "billed_revenue_inr", "collected_revenue_inr", "electricity_cost_inr", "gross_margin_inr",
           "completed_flag", "failed_flag", "cancelled_flag"]
    with open(f"{a.out}/tableau_sessions_flat.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(hdr)
        w.writerows(out_rows)

    # ---------------------------------------------------------------- station-day
    dts = defaultdict(list)
    for r in dtm:
        dts[r["connector_id"]].append((datetime.strptime(r["downtime_start"], "%Y-%m-%d %H:%M:%S"),
                                       datetime.strptime(r["downtime_end"], "%Y-%m-%d %H:%M:%S")))
    avail = defaultdict(lambda: [0, 0, 0])      # (station, date) -> active connectors, scheduled min, downtime min
    d0, d1 = date(2026, 4, 1), date(2026, 9, 30)
    for cid, c in cn.items():
        S = st[c["station_id"]]
        hours = int(S["operating_hours_per_day"])
        inst = date.fromisoformat(c["installation_date"])
        d = d0
        while d <= d1:
            if d >= inst:
                ws = datetime.combine(d, time(0)) if hours >= 24 else datetime.combine(d, time(OPEN_HOUR))
                we = ws + timedelta(hours=hours)
                down = 0
                for ds, de in dts[cid]:
                    ov = (min(de, we) - max(ds, ws)).total_seconds() / 60
                    down += max(0, int(ov))
                a_ = avail[(S["station_id"], d)]
                a_[0] += 1
                a_[1] += hours * 60
                a_[2] += down
            d += timedelta(days=1)

    sd_rows = []
    for r in oc:
        sid, d = r["station_id"], date.fromisoformat(r["operating_date"])
        S, g, av = st[sid], daily[(sid, d)], avail[(sid, d)]
        costs = [Decimal(r[k]) for k in ("electricity_cost_inr", "staff_cost_inr", "rent_cost_inr",
                                          "maintenance_cost_inr", "other_operating_cost_inr")]
        total = sum(costs)
        sd_rows.append([
            r["record_id"], sid, S["station_name"], S["area"], S["station_type"], S["latitude"], S["longitude"],
            d.isoformat(), d.strftime("%Y-%m"), d.strftime("%a"),
            int(g["sessions"]), int(g["completed"]), int(g["failed"]), int(g["cancelled"]), f"{q2(g['energy'])}",
            int(g["charge_min"]), f"{g['billed']}", f"{g['collected']}",
            *[f"{c}" for c in costs], f"{total}", f"{g['billed'] - total}",
            av[0], av[1], av[2], av[1] - av[2]])
    hdr2 = ["record_id", "station_id", "station_name", "area", "station_type", "latitude", "longitude",
            "operating_date", "month", "day_name", "sessions", "completed_sessions", "failed_sessions",
            "cancelled_sessions", "energy_delivered_kwh", "charging_minutes", "billed_revenue_inr",
            "collected_revenue_inr", "electricity_cost_inr", "staff_cost_inr", "rent_cost_inr",
            "maintenance_cost_inr", "other_operating_cost_inr", "total_operating_cost_inr", "net_profit_inr",
            "active_connectors", "scheduled_connector_minutes", "downtime_connector_minutes",
            "available_connector_minutes"]
    with open(f"{a.out}/tableau_station_daily.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(hdr2)
        w.writerows(sd_rows)

    # ---------------------------------------------------------------- reconciliation
    src_rev = sum(Decimal(s["charging_revenue_inr"]) for s in ses)
    src_cost = sum(Decimal(r[k]) for r in oc for k in ("electricity_cost_inr", "staff_cost_inr", "rent_cost_inr",
                                                       "maintenance_cost_inr", "other_operating_cost_inr"))
    f_rev = sum(Decimal(r[28]) for r in out_rows)
    d_rev = sum(Decimal(r[16]) for r in sd_rows)
    d_cost = sum(Decimal(r[23]) for r in sd_rows)
    d_sess = sum(r[10] for r in sd_rows)
    d_down = sum(r[27] for r in sd_rows)
    src_down = sum(int(r["downtime_duration_minutes"]) for r in dtm)
    assert len(out_rows) == len(ses) and len(sd_rows) == 1830
    assert f_rev == src_rev == d_rev, (f_rev, src_rev, d_rev)
    assert d_cost == src_cost, (d_cost, src_cost)
    assert d_sess == len(ses)
    print(f"sessions_flat rows={len(out_rows):,}  station_daily rows={len(sd_rows):,}")
    print(f"revenue  source={src_rev:,.2f}  flat={f_rev:,.2f}  station_daily={d_rev:,.2f}  -> match")
    print(f"op cost  source={src_cost:,.2f}  station_daily={d_cost:,.2f}  -> match")
    print(f"net profit (station_daily) = {sum(Decimal(r[24]) for r in sd_rows):,.2f}")
    print(f"downtime minutes in station_daily (window-clipped) = {d_down:,}  vs source total {src_down:,} "
          f"(source includes time outside operating windows, so station_daily <= source)")
    sched = sum(r[26] for r in sd_rows)
    availm = sum(r[28] for r in sd_rows)
    chg = sum(r[15] for r in sd_rows)
    print(f"network utilisation = charging min / available min = {chg:,}/{availm:,} = {chg/availm:.1%}")
    assert d_down <= src_down


if __name__ == "__main__":
    main()
