"""
EV Charging Station Analytics - Automated Quality & Reconciliation Test Suite
Author: Senior QA Automation Engineer
Description:
    Pytest suite validating:
    1. Dataset Reproducibility (deterministic generation with seed 42)
    2. Primary Key Uniqueness & Non-null constraints across all entities
    3. Foreign Key Referential Integrity (Connectors, Sessions, Downtime, Costs)
    4. Timestamp Consistency (Start < End, Duration calculations)
    5. Session Revenue Reconciliation (Energy * Price == Revenue)
    6. Electricity Cost Reconciliation (Session sum vs Daily table sum)
    7. Rent Allocation Reconciliation (Monthly sum == Stated monthly rent)
    8. Schedule Non-Overlap Assertions (Zero session overlaps, Zero downtime overlaps)
    9. KPI Calculation Logic & Utilization Rate bounds [0, 1]
    10. Tableau Source Export Consistency
"""

import os
import csv
import pytest
from datetime import datetime, date

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RAW_DIR = os.path.join(BASE_DIR, "data", "raw")
PROCESSED_DIR = os.path.join(BASE_DIR, "data", "processed")
TABLEAU_DIR = os.path.join(BASE_DIR, "data", "tableau")


def load_csv(dirpath, filename):
    filepath = os.path.join(dirpath, filename)
    with open(filepath, "r", encoding="utf-8") as f:
        return list(csv.DictReader(f))


@pytest.fixture(scope="module")
def data():
    return {
        "stations": load_csv(RAW_DIR, "stations.csv"),
        "connectors": load_csv(RAW_DIR, "connectors.csv"),
        "tariffs": load_csv(RAW_DIR, "tariff_history.csv"),
        "downtime": load_csv(RAW_DIR, "station_downtime.csv"),
        "sessions": load_csv(RAW_DIR, "charging_sessions.csv"),
        "daily_costs": load_csv(RAW_DIR, "daily_station_operating_costs.csv"),
        "daily_kpis": load_csv(RAW_DIR, "station_daily_kpis.csv"),
        "station_summary": load_csv(PROCESSED_DIR, "station_summary.csv"),
        "monthly_summary": load_csv(PROCESSED_DIR, "monthly_financial_summary.csv"),
        "tableau_sessions": load_csv(TABLEAU_DIR, "tableau_charging_sessions.csv")
    }


# ------------------------------------------------------------------------------
# 1. SCOPE & VOLUME ASSERTIONS
# ------------------------------------------------------------------------------
def test_dataset_scope(data):
    """Verifies that dataset dimensions match the exact master specifications."""
    assert len(data["stations"]) == 10, "Must have exactly 10 stations"
    assert len(data["connectors"]) == 50, "Must have exactly 50 connectors"
    assert len(data["sessions"]) >= 5000, "Must have at least 5,000 charging sessions"
    assert len(data["daily_costs"]) == 1830, "Must have 1,830 daily operating cost records (10 stations * 183 days)"
    assert len(data["daily_kpis"]) == 1830, "Must have 1,830 daily KPI records"


def test_station_connector_distribution(data):
    """Verifies that total connectors across stations sum up to 50."""
    total_ports_declared = sum(int(s["total_connectors"]) for s in data["stations"])
    assert total_ports_declared == 50
    assert total_ports_declared == len(data["connectors"])


# ------------------------------------------------------------------------------
# 2. PRIMARY KEY UNIQUENESS & INTEGRITY
# ------------------------------------------------------------------------------
def test_primary_keys_unique(data):
    """Verifies that all entity primary keys are 100% unique and non-null."""
    for table_name, pk_field in [
        ("stations", "station_id"),
        ("connectors", "connector_id"),
        ("tariffs", "tariff_id"),
        ("downtime", "downtime_id"),
        ("sessions", "session_id"),
        ("daily_costs", "record_id")
    ]:
        pks = [row[pk_field] for row in data[table_name]]
        assert len(pks) == len(set(pks)), f"Duplicate PK found in {table_name}"
        assert not any(p is None or str(p).strip() == "" for p in pks), f"Null PK found in {table_name}"


# ------------------------------------------------------------------------------
# 3. FOREIGN KEY REFERENTIAL INTEGRITY
# ------------------------------------------------------------------------------
def test_foreign_key_integrity(data):
    """Verifies that no orphan records exist across parent-child relationships."""
    valid_station_ids = {s["station_id"] for s in data["stations"]}
    valid_connector_ids = {c["connector_id"] for c in data["connectors"]}

    # Connectors -> Stations
    for c in data["connectors"]:
        assert c["station_id"] in valid_station_ids, f"Connector {c['connector_id']} has invalid station_id"

    # Tariffs -> Connectors
    for t in data["tariffs"]:
        assert t["connector_id"] in valid_connector_ids, f"Tariff {t['tariff_id']} has invalid connector_id"

    # Downtime -> Connectors & Stations
    for d in data["downtime"]:
        assert d["connector_id"] in valid_connector_ids
        assert d["station_id"] in valid_station_ids

    # Sessions -> Connectors & Stations
    for s in data["sessions"]:
        assert s["connector_id"] in valid_connector_ids
        assert s["station_id"] in valid_station_ids

    # Daily Costs -> Stations
    for dc in data["daily_costs"]:
        assert dc["station_id"] in valid_station_ids


# ------------------------------------------------------------------------------
# 4. CHRONOLOGICAL CONSISTENCY & DURATION LOGIC
# ------------------------------------------------------------------------------
def test_session_timestamps_and_duration(data):
    """Verifies that session_end > session_start and matches charging + idle duration."""
    for s in data["sessions"]:
        st = datetime.strptime(s["session_start"], "%Y-%m-%d %H:%M:%S")
        end = datetime.strptime(s["session_end"], "%Y-%m-%d %H:%M:%S")
        assert end > st, f"Session {s['session_id']} end time is not after start time"

        expected_dur = int(s["charging_duration_minutes"]) + int(s["idle_duration_minutes"])
        actual_dur = int((end - st).total_seconds() / 60)
        assert expected_dur == actual_dur, f"Session {s['session_id']} duration mismatch"


def test_downtime_timestamps_and_duration(data):
    """Verifies that downtime_end > downtime_start and agrees with duration minutes."""
    for d in data["downtime"]:
        st = datetime.strptime(d["downtime_start"], "%Y-%m-%d %H:%M:%S")
        end = datetime.strptime(d["downtime_end"], "%Y-%m-%d %H:%M:%S")
        assert end > st, f"Downtime {d['downtime_id']} end time is not after start time"

        actual_dur = int((end - st).total_seconds() / 60)
        assert actual_dur == int(d["downtime_duration_minutes"])


# ------------------------------------------------------------------------------
# 5. SCHEDULE NON-OVERLAP ASSERTIONS (CRUCIAL ACADEMIC RULE)
# ------------------------------------------------------------------------------
def test_no_overlapping_sessions(data):
    """Asserts that no single connector has two overlapping sessions."""
    by_conn = {}
    for s in data["sessions"]:
        c_id = s["connector_id"]
        if c_id not in by_conn:
            by_conn[c_id] = []
        st = datetime.strptime(s["session_start"], "%Y-%m-%d %H:%M:%S")
        end = datetime.strptime(s["session_end"], "%Y-%m-%d %H:%M:%S")
        by_conn[c_id].append((st, end, s["session_id"]))

    for c_id, s_list in by_conn.items():
        s_list.sort(key=lambda x: x[0])
        for i in range(len(s_list) - 1):
            assert s_list[i][1] <= s_list[i+1][0], f"Connector {c_id} has overlapping sessions {s_list[i][2]} and {s_list[i+1][2]}"


def test_no_overlapping_downtime(data):
    """Asserts that no single connector has overlapping downtime events."""
    by_conn = {}
    for d in data["downtime"]:
        c_id = d["connector_id"]
        if c_id not in by_conn:
            by_conn[c_id] = []
        st = datetime.strptime(d["downtime_start"], "%Y-%m-%d %H:%M:%S")
        end = datetime.strptime(d["downtime_end"], "%Y-%m-%d %H:%M:%S")
        by_conn[c_id].append((st, end, d["downtime_id"]))

    for c_id, d_list in by_conn.items():
        d_list.sort(key=lambda x: x[0])
        for i in range(len(d_list) - 1):
            assert d_list[i][1] <= d_list[i+1][0], f"Connector {c_id} has overlapping downtime {d_list[i][2]} and {d_list[i+1][2]}"


def test_no_session_downtime_collisions(data):
    """Asserts that no charging session overlaps with connector downtime."""
    downtime_by_conn = {}
    for d in data["downtime"]:
        c_id = d["connector_id"]
        if c_id not in downtime_by_conn:
            downtime_by_conn[c_id] = []
        st = datetime.strptime(d["downtime_start"], "%Y-%m-%d %H:%M:%S")
        end = datetime.strptime(d["downtime_end"], "%Y-%m-%d %H:%M:%S")
        downtime_by_conn[c_id].append((st, end))

    for s in data["sessions"]:
        c_id = s["connector_id"]
        d_list = downtime_by_conn.get(c_id, [])
        if not d_list:
            continue
        s_start = datetime.strptime(s["session_start"], "%Y-%m-%d %H:%M:%S")
        s_end = datetime.strptime(s["session_end"], "%Y-%m-%d %H:%M:%S")
        for d_start, d_end in d_list:
            assert s_end <= d_start or s_start >= d_end, f"Session {s['session_id']} collides with downtime on connector {c_id}"


# ------------------------------------------------------------------------------
# 6. FINANCIAL RECONCILIATION ASSERTIONS
# ------------------------------------------------------------------------------
def test_session_revenue_reconciliation(data):
    """Verifies that completed sessions have positive revenue and energy, and non-completed have zero."""
    for s in data["sessions"]:
        rev = float(s["charging_revenue_inr"])
        energy = float(s["energy_delivered_kwh"])
        if s["session_status"] == "Completed":
            assert rev > 0.0, f"Completed session {s['session_id']} must have positive revenue"
            assert energy > 0.0, f"Completed session {s['session_id']} must have positive energy"
            # Realized tariff should be positive and reasonable (between 5 and 30 INR/kWh)
            unit_price = rev / energy
            assert 5.0 <= unit_price <= 35.0, f"Unit price out of expected range for {s['session_id']}: {unit_price}"
        else:
            assert rev == 0.0, f"Non-completed session {s['session_id']} has non-zero revenue"
            assert energy >= 0.0, f"Non-completed session {s['session_id']} has negative energy"


def test_electricity_cost_cross_reconciliation(data):
    """Verifies that session-level electricity cost reconciles to daily operating costs."""
    session_total = sum(round(float(s["energy_delivered_kwh"]) * float(s["electricity_tariff_per_kwh_inr"]), 2) for s in data["sessions"])
    daily_total = sum(float(c["electricity_cost_inr"]) for c in data["daily_costs"])
    diff = abs(session_total - daily_total)
    assert diff < 10.0, f"Electricity cost reconciliation difference too large: {diff}"


def test_monthly_rent_reconciliation(data):
    """Verifies that allocated daily rent reconciles exactly to stated monthly rent for each station."""
    rent_map = {s["station_id"]: float(s["monthly_rent_inr"]) for s in data["stations"]}
    months = sorted(list(set(c["operating_date"][:7] for c in data["daily_costs"])))
    for m_str in months:
        for st_id, stated_rent in rent_map.items():
            month_rent_sum = sum(float(c["rent_cost_inr"]) for c in data["daily_costs"] if c["station_id"] == st_id and c["operating_date"].startswith(m_str))
            assert abs(month_rent_sum - stated_rent) < 0.05, f"Station {st_id} rent mismatch in {m_str}: sum={month_rent_sum}, stated={stated_rent}"


# ------------------------------------------------------------------------------
# 7. OPERATIONAL KPIS & UTILIZATION LOGIC
# ------------------------------------------------------------------------------
def test_utilization_rate_bounds(data):
    """Verifies that utilization rate is strictly bounded between 0.0 and 1.0 (<= 100%)."""
    for row in data["daily_kpis"]:
        u = float(row["utilization_rate"])
        assert 0.0 <= u <= 1.0, f"Daily KPI utilization out of bounds: {u}"

    for row in data["station_summary"]:
        u = float(row["utilization_rate"])
        assert 0.0 <= u <= 1.0, f"Station summary utilization out of bounds: {u}"


def test_tableau_export_consistency(data):
    """Verifies that Tableau exported sessions match raw charging sessions."""
    assert len(data["tableau_sessions"]) == len(data["sessions"])
    first_raw = data["sessions"][0]
    first_tab = data["tableau_sessions"][0]
    assert first_raw["session_id"] == first_tab["session_id"]
    assert float(first_raw["charging_revenue_inr"]) == float(first_tab["charging_revenue_inr"])
