# EV Charging Station Analytics & Profitability Optimization
## Master Viva Voce Preparation Guide (35 Questions & In-Depth Academic Answers)

---

### Category 1: Project Selection & Business Domain

#### Q1: What is the primary objective of this project, and why did you choose this topic?
**Answer:**  
The primary objective is to evaluate the operational performance and financial viability of an electric vehicle (EV) charging network across 10 charging stations in Chandigarh, India. The EV sector in India is experiencing exponential growth under the FAME II policy and national EV incentives; however, charging point operators (CPOs) face significant challenges: high commercial facility rents, demand volatility, equipment downtime, and narrow gross margins. This project applies an end-to-end data analytics workflow (MySQL, Excel, and Tableau) to determine which stations are profitable, identify underutilized charging ports, assess the financial cost of equipment downtime, and model pricing strategies to optimize bottom-line operating profit.

#### Q2: Why did you use synthetic data rather than real-world commercial data?
**Answer:**  
Commercial charging station operators (such as Tata Power, Ather Grid, or Zeon) treat their minute-by-minute session logs, electricity tariffs, facility leases, and failure logs as proprietary business secrets. Furthermore, publicly available IoT data is often incomplete, lacking financial cost allocations such as station lease rents, staff expenses, and maintenance invoices. Synthetic data generation allowed us to engineer a mathematically consistent, realistic, and fully transparent dataset following actual Chandigarh geographic coordinates, real tariff revisions, and true charging curve physics, while enabling strict reproducibility.

#### Q3: How did you ensure the synthetic dataset realistically reflects Indian EV charging patterns?
**Answer:**  
We incorporated realistic real-world parameters:
1. **Diurnal Commuter Distribution:** Morning rush hour (08:00–11:00) and evening commute (17:00–21:00) peaks.
2. **Station Types:** Transit Hubs (ISBT Sector 43) and Highway Corridors (Sector 28) show strong daily and weekend demand; Office Complexes (Sector 34) experience sharp weekday peaks but zero weekend demand.
3. **Hardware & Tariff Realism:** We modeled DC Fast (CCS2 30–120 kW, CHAdeMO 50 kW) and AC Slow (Type 2 7.4–22 kW) with tariffs reflecting actual Indian commercial electricity rates (₹7.00–₹9.00/kWh) and retail customer prices (₹15.00–₹25.00/kWh).
4. **Failure Mechanics:** Summer heatwaves and monsoon rains in North India elevate equipment fault rates and downtime events.

---

### Category 2: Python Data Engineering & Methodology

#### Q4: How does your Python generator guarantee zero overlapping sessions on the same connector?
**Answer:**  
In physical reality, a single charging plug can only plug into one vehicle at a time. In `src/generate_dataset.py`, we track booked intervals `(start_dt, end_dt)` for every individual connector. Before inserting any candidate session or downtime window, the script runs an interval intersection algorithm:
$$\text{Overlap Condition: } \neg (End_A \le Start_B \lor Start_A \ge End_B)$$
If an overlap or collision with maintenance downtime is detected, the candidate session is rejected or re-scheduled into an available free slot.

#### Q5: Why is active charging duration distinguished from idle dwell duration?
**Answer:**  
Active charging duration is the time electric current is flowing to charge the battery. Idle duration is the dwell time when a driver remains parked at the charger after their battery has reached full capacity. Distinguishing these is vital for CPOs: active minutes generate energy revenue, while idle minutes represent unbilled port congestion (often referred to as 'charger squatting'). Modeling this allows CPOs to evaluate whether to introduce idle congestion fees.

#### Q6: How was reproducibility maintained across multiple script executions?
**Answer:**  
We explicitly initialized Python's pseudorandom number generator with a deterministic seed: `random.seed(42)` at the top of `src/generate_dataset.py`. This ensures that every random choice—session timestamps, vehicle registrations, failure occurrences, and weather assignments—produces the exact same sequence of data every time the script is executed.

---

### Category 3: Relational Database Design & MySQL Implementation

#### Q7: What normal form is your MySQL database in, and why is normalization important?
**Answer:**  
The database is in **Third Normal Form (3NF)**:
1. **1NF:** Every column contains atomic values, each table has a defined primary key, and there are no repeating groups.
2. **2NF:** It is in 1NF and all non-key attributes are fully functionally dependent on the entire primary key (no partial dependencies).
3. **3NF:** It is in 2NF and contains no transitive dependencies (non-key columns depend only on candidate keys).  
Normalization prevents update, insertion, and deletion anomalies. For instance, updating a station's monthly rent in the `stations` table automatically reflects across all queries without modifying 11,000+ session rows.

#### Q8: What is the purpose of foreign key constraints and `ON UPDATE CASCADE`?
**Answer:**  
Foreign keys enforce **referential integrity**. They guarantee that child records (such as a session in `charging_sessions`) cannot reference a non-existent `connector_id` or `station_id`. The clause `ON UPDATE CASCADE` ensures that if a parent primary key is updated, all associated child rows update automatically; `ON DELETE RESTRICT` prevents accidental deletion of a station that has historical revenue and session records.

#### Q9: What data types did you choose for financial and geographic coordinates, and why?
**Answer:**  
For financial values (revenues, tariffs, operating expenses), we used `DECIMAL(10, 2)` or `DECIMAL(12, 2)` rather than `FLOAT` or `DOUBLE`. Floating-point numbers use binary approximations that cause floating-point rounding errors (e.g., $0.1 + 0.2 = 0.30000000000000004$). `DECIMAL` provides exact fixed-point arithmetic required for monetary auditing. For coordinates, we used `DECIMAL(9, 6)` providing sub-meter geographic accuracy.

#### Q10: What indexes did you create, and how do they improve query execution speed?
**Answer:**  
We established B-tree indexes on foreign keys (`idx_sessions_station`, `idx_sessions_connector`) and high-frequency analytical filter attributes (`idx_sessions_start`, `idx_sessions_status`, `idx_daily_costs_date`). Without indexes, MySQL must perform an expensive Full Table Scan ($O(N)$ complexity) checking all 11,821 rows. With B-tree indexes, search complexity drops to logarithmic time ($O(\log N)$), accelerating multi-table joins and date-range aggregations.

---

### Category 4: Advanced SQL Queries & Analytical Techniques

#### Q11: What is a Common Table Expression (CTE), and where did you use it?
**Answer:**  
A CTE is a temporary named result set defined within the execution scope of a single SQL statement using the `WITH` clause. We utilized CTEs extensively in Query 3, 6, 8, 13, 18, and 20. For example, in Query 18, we used two separate CTEs (`StationRevenues` and `StationExpenses`) to pre-aggregate revenues and operating expenses independently by station, before joining them to calculate operating profit. This prevents cartesian fan-out where joining sessions directly to daily costs would multiply monetary totals.

#### Q12: How do window functions differ from standard aggregate functions with `GROUP BY`?
**Answer:**  
Standard aggregate functions collapse multiple rows into a single summary row per group. In contrast, **window functions** perform calculations across a set of table rows related to the current row (the "window") while retaining each individual row's identity. We utilized:
- `DENSE_RANK() OVER (ORDER BY profit DESC)` to rank stations by profitability without gaps in rank.
- `ROW_NUMBER() OVER (PARTITION BY station_id ORDER BY COUNT(*) DESC)` in Query 13 to extract each station's single busiest hour.
- `LAG() OVER (ORDER BY billing_month)` in Query 6 to access the previous month's energy and revenue to compute Month-over-Month (MoM) growth percentages.
- Cumulative running sum: `SUM(monthly_revenue_inr) OVER (ORDER BY session_month)` in Query 3.

#### Q13: What is the difference between `RANK()`, `DENSE_RANK()`, and `ROW_NUMBER()`?
**Answer:**  
- `ROW_NUMBER()` assigns a unique, strictly sequential integer (1, 2, 3, 4) regardless of ties.
- `RANK()` assigns identical numbers to ties but skips subsequent rank numbers (e.g., 1, 2, 2, 4).
- `DENSE_RANK()` assigns identical numbers to ties without skipping numbers (e.g., 1, 2, 2, 3). In our business rankings, `DENSE_RANK()` was preferred so consecutive ranks remain unbroken.

#### Q14: What is the purpose of database views, and which views did you create?
**Answer:**  
A database view is a virtual table defined by a stored SQL query. Views provide security (restricting underlying columns), simplify complex multi-table joins for business analysts, and establish a single source of truth for reporting tools like Excel and Tableau. We created 5 views:
1. `vw_session_financials`: Granular session margins.
2. `vw_station_profitability`: Station-level P&L statement.
3. `vw_daily_station_performance`: Daily operational activity.
4. `vw_connector_utilization`: Port capacity, active minutes, and downtime.
5. `vw_monthly_financial_summary`: Executive monthly financial trajectory.

---

### Category 5: Financial Modeling & Business Logic

#### Q15: How do you define Charging Revenue, Electricity Cost, Gross Contribution, and Operating Profit?
**Answer:**  
- **Charging Revenue:** Delivered Energy $(\text{kWh}) \times \text{Customer Price per kWh (₹)}$. (Zero for failed sessions).
- **Electricity Cost (COGS):** Consumed Energy $(\text{kWh}) \times \text{Procurement Electricity Tariff (₹)}$.
- **Gross Contribution (Gross Profit):** $\text{Charging Revenue} - \text{Electricity Cost}$.
- **Operating Profit (EBIT):** $\text{Charging Revenue} - (\text{Electricity Cost} + \text{Staff Expenses} + \text{Facility Rent} + \text{Maintenance Upkeep} + \text{Other CMS/Insurance Costs})$.

#### Q16: Why should Operating Profit not be casually referred to as EBITDA in this project?
**Answer:**  
EBITDA stands for Earnings Before Interest, Taxes, Depreciation, and Amortization. While our operational model accounts for cash operating expenses (rent, staff, utilities, repairs), it does not explicitly model capital expenditure (CapEx) depreciation of the charging hardware, interest on debt financing, or corporate income tax. Calling our metric Operating Profit (or EBIT) is mathematically and accountant-approved accurate.

#### Q17: How did you ensure electricity costs were not double-counted between session logs and daily operating costs?
**Answer:**  
We established a strict reconciliation rule: in `daily_station_operating_costs.csv`, the `electricity_cost_inr` field is not an independent estimated guess; it is computed as the exact sum of electricity costs for all sessions originating at that station on that date:
$$\text{daily\_elec\_cost}_{\text{station, date}} = \sum_{s \in \text{Sessions}} (\text{energy}_s \times \text{tariff}_s)$$
When building financial summaries, revenue is taken from sessions and fixed overheads are taken from the daily cost table, guaranteeing 100% financial reconciliation without double-counting.

#### Q18: How is port utilization defined, and can it ever exceed 100%?
**Answer:**  
Active Connector Utilization is defined as:
$$\text{Utilization Rate} = \frac{\text{Total Active Charging Minutes}}{\text{Total Available Connector Minutes}} = \frac{\sum \text{charging\_duration\_minutes}}{\text{Connectors} \times \text{Operating Hours} \times 60 \times \text{Days}}$$
Because sessions are strictly scheduled without time overlaps and cannot exceed available operating hours, utilization is mathematically bounded between $0.00\%$ and $100.00\%$. In our 6-month simulation, network-wide active utilization averages approximately $11.8\%$, which matches realistic commercial EV networks worldwide.

---

### Category 6: Microsoft Excel Financial Modeling

#### Q19: What sheets did you implement in `EV_Charging_Analytics_Financial_Model.xlsx`?
**Answer:**  
We engineered 7 structured worksheets:
1. **Read Me:** Project metadata, instructions, and KPI mathematical dictionary.
2. **Session Data:** 1,500 representative transaction rows with live Excel formulas for total duration, revenue, and gross profit.
3. **Station Summary:** Master 10-station P&L scorecard with full expense allocations and margins.
4. **Monthly Analysis:** 6-month financial trajectory with live Month-over-Month (`MoM%`) growth formulas.
5. **Connector Analysis:** Port-level throughput, active minutes, and failure rates.
6. **Financial Dashboard:** Executive KPI callout cards and native embedded Bar and Line charts.
7. **What-If Analysis:** Dynamic scenario sensitivity model with adjustable assumption cells.

#### Q20: How does the What-If Analysis worksheet operate dynamically?
**Answer:**  
The What-If model defines 5 input parameters highlighted in yellow:
1. Retail price per kWh adjustment
2. Electricity procurement rate change
3. Demand multiplier factor
4. Downtime reduction percentage
5. Staff cost optimization factor  
All output rows (Gross Revenue, Electricity COGS, OPEX, Net Operating Profit, and Margin %) are connected via dynamic Excel formulas referencing the Base Case totals from the Station Summary sheet multiplied by the scenario input cells. Adjusting any assumption cell immediately recalculates the projected EBIT and variance without hardcoded numbers.

---

### Category 7: Tableau Business Intelligence & Executive Dashboard

#### Q21: What are the 5 core worksheets and the master layout of your Executive Dashboard?
**Answer:**  
1. **Worksheet 1 - Monthly Financial Trajectory:** Combo chart showing monthly charging revenue vs operating expenses as dual bars, with net operating profit as a tracking line.
2. **Worksheet 2 - Station Profitability Ranking:** Sorted horizontal bar chart ranking all 10 stations by Net Operating Profit (EBIT), formatted with a diverging green/red palette and labelled with operating margin %.
3. **Worksheet 3 - Hourly & Weekly Demand Heatmap:** 168-cell matrix (7 Days of Week × 24 Hours of Day) colored by charging sessions / energy throughput to highlight diurnal peak demand.
4. **Worksheet 4 - Connector Utilization Quadrant:** Scatter plot of active utilization % (X-axis) versus revenue per port (Y-axis) with quadrant reference lines dividing Star Performers, Workhorses, and Underperforming ports.
5. **Worksheet 5 - Downtime Pareto Analysis:** Dual-axis chart with outage hours per failure category sorted descending (bars) and cumulative percentage line (Pareto 80/20 curve).
- **Master Dashboard:** Fixed 1400×900 executive canvas featuring high-level KPI tiles across the top and a 2×2 analytical grid below with synchronized cross-filtering.

#### Q22: Why did you use Level of Detail (LOD) expressions or Tableau Relationships rather than a flat physical join?
**Answer:**  
In relational analytics, joining a parent table (`stations`) to two transactional tables of completely different grains (`charging_sessions` with 23,325 rows, and `daily_station_operating_costs` with 1,830 rows) causes a Many-to-Many Cartesian fan-out. In a flat physical join, daily station rent and staff costs would be multiplied by the number of sessions occurring that day, artificially inflating expenses by over 1,200%. Tableau Relationships or LOD expressions (`{FIXED [Station Id], [Operating Date] : AVG([Daily Cost])}`) guarantee that costs and revenues are calculated strictly at their native grain without duplicate counting.

#### Q23: How are Utilization % and Availability % defined and calculated in Tableau, and how do they differ?
**Answer:**  
- **Availability %:** Measures hardware uptime independent of driver demand:
  $$\text{Availability \%} = 1 - \frac{\text{Total Downtime Minutes}}{\text{Total Scheduled Minutes}}$$
  Across our network, hardware availability was **95.7%** (only 4.3% downtime).
- **Utilization %:** Measures active commercial throughput when the hardware was operational:
  $$\text{Utilization \%} = \frac{\text{Active Charging Minutes}}{\text{Scheduled Operating Minutes} - \text{Downtime Minutes}}$$
  Average network utilization was **11.2%**, proving that financial performance is driven by utilization bottlenecks rather than hardware unavailability.

#### Q24: Looking at Station Profitability, why are ISBT Sector 43 and Highway Corridor profitable while Sector 34 Office Complex is loss-making?
**Answer:**  
- **ISBT Sector 43 (ST06)** generated ₹10.37 Lakhs profit (39.9% margin) because it operates 24/7 with 6 DC fast chargers at a central transit hub where intercity buses, commercial taxis, and EV commuters charge continuously day and night.
- **Sector 34 Office Complex (ST10)** lost ₹1.50 Lakhs (-35.5% margin) because it only operates 12 hours/day, experiences near-zero traffic on weekends, and has fixed rent and staff expenses that cannot be recouped on a 5-day commuter window.

#### Q25: How does the Hourly & Weekly Demand Heatmap support the business case for Dynamic Time-of-Day (ToD) Pricing?
**Answer:**  
The heatmap proves that demand is severely concentrated between 08:00–11:00 (morning peak) and 17:00–21:00 (evening peak), while chargers sit idle between 23:00–06:00 (night) and 12:00–16:00 (afternoon). Implementing dynamic pricing—a ₹3.00/kWh premium during peak hours and a ₹4.00/kWh discount for overnight charging—would flatten the peak load, monetize idle capacity, and attract fleet operators (taxis, delivery vans) to charge overnight.

---

### Category 8: Data Quality, Testing & Limitations

#### Q24: What automated data quality checks were implemented in `validate_dataset.py`?
**Answer:**  
The validation script runs 34 automated checks categorized into:
- File existence and column schema validation
- Primary key uniqueness and non-null assertions
- Foreign key referential integrity (checking for orphan records)
- Timestamp consistency (`session_end > session_start`)
- Duration mathematical reconciliation
- Schedule collision audits (zero overlapping sessions or downtime on the same port)
- Financial formula verification (`Revenue == Energy * Price`)
- Cross-table reconciliation between session electricity costs and daily operating costs
- Utilization rate boundary constraints ($0.0 \le \text{utilization} \le 1.0$)

#### Q25: What Pytest tests were created, and what was their execution outcome?
**Answer:**  
We created `tests/test_data_validation.py` with 14 automated unit test functions covering scope dimensions, primary/foreign key integrity, timestamp order, schedule non-overlap, revenue reconciliation, rent allocation, and utilization limits. When executed via `pytest`, all 14 tests passed with 100% success rate in 0.56 seconds.

#### Q26: What are the main real-world limitations of this project?
**Answer:**  
1. **Synthetic Nature:** Data is simulated; while calibrated to realistic distributions, it does not capture unpredicted macroeconomic disruptions or real-world driver behavior.
2. **Simplified Financial Model:** Excludes corporate income tax, CapEx hardware depreciation, GST/VAT tax credits, and debt interest.
3. **Static Electricity Tariffs:** Electricity is modeled via two quarterly tariff tiers rather than real-time 15-minute Time-of-Day (ToD) utility spot pricing.
4. **Zero Battery Degradation:** Does not simulate individual vehicle battery health or dynamic thermal throttling during extreme summer heat.

---

### Category 9: Viva Rapid-Fire Technical Definitions

#### Q27: What is an orphan record in SQL?
**Answer:** An orphan record is a child row whose foreign key value references a parent primary key that does not exist in the parent table.

#### Q28: What is the difference between `INNER JOIN` and `LEFT JOIN`?
**Answer:** An `INNER JOIN` returns only records that have matching keys in both tables. A `LEFT JOIN` returns all rows from the left table, along with matching rows from the right table (filling with `NULL` if no match exists).

#### Q29: What is `local_infile` in MySQL?
**Answer:** A security configuration setting in MySQL that controls whether clients can load data from a local file on the client host into a database table using `LOAD DATA LOCAL INFILE`.

#### Q30: What is a B-Tree index?
**Answer:** A balanced tree data structure maintained by database engines that keeps data sorted and allows searches, sequential access, insertions, and deletions in logarithmic time ($O(\log N)$).

#### Q31: What is the purpose of `freeze_panes` in Excel?
**Answer:** It locks top header rows or left columns in place so they remain visible while scrolling through thousands of data rows.

#### Q32: What is the difference between Discrete and Continuous fields in Tableau?
**Answer:** Discrete fields (blue pills) create distinct headers/categories; Continuous fields (green pills) form continuous quantitative numeric or date axes.

#### Q33: What is the FAME II scheme?
**Answer:** Faster Adoption and Manufacturing of Electric Vehicles (FAME), a flagship Government of India subsidy program providing capital incentives for EV manufacturing and public charging infrastructure.

#### Q34: What is the difference between AC Type 2 and CCS2 charging?
**Answer:** Type 2 AC supplies alternating current (typically 7.4 kW to 22 kW) where the vehicle's onboard converter turns AC to DC; CCS2 (Combined Charging System) delivers high-voltage direct current (50 kW to 350 kW) directly into the battery pack for rapid DC fast charging.

#### Q35: If given another semester, what would you add to this project?
**Answer:** I would integrate a machine learning predictive pipeline using Scikit-Learn or XGBoost to forecast next-day charging demand based on weather and calendar features, and implement a linear programming optimization model for automated dynamic peak pricing.
