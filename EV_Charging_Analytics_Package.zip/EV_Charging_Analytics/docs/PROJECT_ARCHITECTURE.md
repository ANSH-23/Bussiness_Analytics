# EV Charging Station Analytics & Profitability Optimization
## System Architecture & End-to-End Data Pipeline Documentation

---

### 1. Executive Pipeline Overview

The **EV Charging Station Analytics & Profitability Optimization** system implements a robust, modular, end-to-end business intelligence and data engineering pipeline designed specifically for academic rigor and real-world applicability.

The architecture ingests raw synthetic operational logs, transforms and loads them into a normalized MySQL relational database, executes complex analytical queries and certified database views, powers a financial model in Microsoft Excel, and outputs executive BI dashboards in Tableau.

```mermaid
flowchart TD
    subgraph Data_Generation["1. Python Data Engineering Layer"]
        A[src/generate_dataset.py<br/>Fixed Seed 42] --> B[(data/raw/<br/>7 Master CSV Files)]
        B --> C[src/validate_dataset.py<br/>Automated Quality Audit]
        C --> D[src/calculate_kpis.py<br/>Multi-grain Aggregations]
        D --> E[(data/processed/<br/>5 KPI CSV Files)]
        B --> F[src/export_tableau_data.py<br/>Relational Tableau Prep]
        F --> G[(data/tableau/<br/>6 Tableau CSV Exports)]
    end

    subgraph Relational_RDBMS["2. MySQL 8.0 Relational Layer"]
        B -->|LOAD DATA LOCAL INFILE<br/>or Python Ingestion| H[(ev_charging_analytics<br/>MySQL 8.0 Database)]
        H --> I[sql/01_schema.sql<br/>DDL, PK/FK, Constraints]
        H --> J[sql/02_data_ingest.sql<br/>ETL Ingestion Scripts]
        H --> K[sql/03_analytics_queries.sql<br/>20+ Business SQL Queries]
        H --> L[sql/04_analytics_views.sql<br/>5 Certified Business Views]
        H --> M[sql/05_data_quality_checks.sql<br/>SQL Assertion Test Suite]
    end

    subgraph Business_Reporting["3. Analytics & Consumption Layer"]
        H -.->|MySQL ODBC 8.0 Connector| N[Microsoft Excel 2024<br/>EV_Charging_Analytics_Financial_Model.xlsx]
        H -.->|MySQL ODBC 8.0 / Native Connector| O[Tableau Desktop / Tableau Public<br/>4 Interactive Dashboards]
        E --> N
        G --> O
    end

    subgraph Decision_Support["4. Decision Support & Output"]
        N --> P[Financial Scenarios & What-If Forecasts]
        O --> Q[Executive Visibility & Reliability Audits]
        P & Q --> R[Academic Project Report<br/>EV_Charging_Analytics_Project_Report.docx]
    end
```

---

### 2. Component Breakdown & Responsibilities

| Pipeline Stage | Technology | Key Files | Core Purpose & Deliverables |
| :--- | :--- | :--- | :--- |
| **Data Generation** | Python 3.13, Standard Library | `src/generate_dataset.py` | 10 stations, 50 connectors, 23,325 sessions, 571 downtime events, 1,830 daily costs across Apr 1 - Sep 30, 2026 (Chandigarh, India) with zero schedule collisions. |
| **Data Quality & Testing** | Python, Pytest | `src/validate_dataset.py`, `tests/test_data_validation.py` | 34 automated schema, timestamp, collision, and reconciliation checks; 14 Pytest unit tests verifying mathematical consistency. |
| **Relational Database** | MySQL 8.0 Community Server (InnoDB) | `sql/01_schema.sql` to `sql/05_data_quality_checks.sql` | 3NF normalized schema, foreign key enforcement, 20 advanced business queries (CTEs, Window Functions, LAG, running totals), and 5 certified views. |
| **Financial Modeling** | Microsoft Excel (.xlsx), OpenPyXL | `src/build_excel_model.py`, `output/EV_Charging_Analytics_Financial_Model.xlsx` | 7-sheet workbook with dynamic formulas, station scorecards, monthly MoM trajectory, port yields, KPI callouts, native charts, and What-If scenario modeling. |
| **Business Intelligence** | Tableau Desktop / Public | `src/export_tableau_data.py`, `docs/TABLEAU_IMPLEMENTATION_GUIDE.md` | Clean non-denormalized extracts in `data/tableau/`, calculated fields, and a 4-dashboard layout guide (Executive, Demand, Downtime, Financial). |
| **Academic Documentation** | Microsoft Word (.docx), Markdown | `output/EV_Charging_Analytics_Project_Report.docx`, `docs/` | 27-chapter comprehensive MCA project report, data dictionary, architecture specification, and 30+ viva examination questions. |

---

### 3. Relational Schema Architecture (Entity-Relationship Diagram)

The database schema strictly adheres to Third Normal Form (3NF) to eliminate data redundancy and prevent update/delete anomalies.

```mermaid
erDiagram
    STATIONS ||--o{ CONNECTORS : "has (1 to M)"
    STATIONS ||--o{ CHARGING_SESSIONS : "hosts (1 to M)"
    STATIONS ||--o{ STATION_DOWNTIME : "experiences (1 to M)"
    STATIONS ||--o{ DAILY_STATION_OPERATING_COSTS : "incurs (1 to M)"
    CONNECTORS ||--o{ TARIFF_HISTORY : "priced by (1 to M)"
    CONNECTORS ||--o{ CHARGING_SESSIONS : "serves (1 to M)"
    CONNECTORS ||--o{ STATION_DOWNTIME : "undergoes (1 to M)"

    STATIONS {
        varchar(10) station_id PK
        varchar(100) station_name
        varchar(50) city
        varchar(50) area
        decimal(9,6) latitude
        decimal(9,6) longitude
        date installation_date
        int total_connectors
        varchar(50) station_type
        decimal(12,2) monthly_rent_inr
        decimal(12,2) maintenance_cost_monthly_inr
        int operating_hours_per_day
    }

    CONNECTORS {
        varchar(10) connector_id PK
        varchar(10) station_id FK
        varchar(30) connector_type
        decimal(6,2) rated_power_kw
        date installation_date
        varchar(20) connector_status
        decimal(8,2) electricity_tariff_per_kwh_inr
    }

    TARIFF_HISTORY {
        varchar(15) tariff_id PK
        varchar(10) connector_id FK
        datetime effective_from
        datetime effective_to
        decimal(8,2) electricity_tariff_per_kwh_inr
        decimal(8,2) customer_price_per_kwh_inr
    }

    CHARGING_SESSIONS {
        varchar(20) session_id PK
        varchar(10) connector_id FK
        varchar(10) station_id FK
        varchar(30) vehicle_id
        datetime session_start
        datetime session_end
        decimal(8,2) energy_delivered_kwh
        int charging_duration_minutes
        int idle_duration_minutes
        decimal(8,2) electricity_tariff_per_kwh_inr
        decimal(8,2) customer_price_per_kwh_inr
        decimal(10,2) charging_revenue_inr
        varchar(20) session_status
        varchar(20) payment_status
        varchar(15) day_type
        varchar(30) weather_condition
    }

    STATION_DOWNTIME {
        varchar(20) downtime_id PK
        varchar(10) connector_id FK
        varchar(10) station_id FK
        datetime downtime_start
        datetime downtime_end
        int downtime_duration_minutes
        varchar(100) downtime_reason
        varchar(30) maintenance_type
        decimal(10,2) maintenance_cost_inr
    }

    DAILY_STATION_OPERATING_COSTS {
        varchar(20) record_id PK
        varchar(10) station_id FK
        date operating_date
        decimal(10,2) electricity_cost_inr
        decimal(10,2) staff_cost_inr
        decimal(10,2) rent_cost_inr
        decimal(10,2) maintenance_cost_inr
        decimal(10,2) other_operating_cost_inr
    }
```

---

### 4. MySQL ODBC Connectivity & Workflow Integration

The system supports two complementary integration pathways:

#### Pathway A: Live Enterprise Connection via MySQL ODBC 8.0 Driver
1. **Download & Install Driver**:
   - Install the official **MySQL Connector/ODBC 8.0 (Windows 64-bit)** from Oracle.
2. **Configure Windows ODBC Data Source**:
   - Open Windows **ODBC Data Source Administrator (64-bit)** (`odbcad32.exe`).
   - Under the **System DSN** tab, click **Add...** and select **MySQL ODBC 8.0 Unicode Driver**.
   - Set parameters:
     - Data Source Name: `MySQL_EV_Analytics`
     - TCP/IP Server: `localhost` | Port: `3306`
     - User: `root` | Password: `<your_password>`
     - Database: `ev_charging_analytics`
   - Click **Test** to confirm successful connection.
3. **Connecting Microsoft Excel**:
   - Open Excel -> **Data** tab -> **Get Data** -> **From Other Sources** -> **From ODBC**.
   - Select DSN `MySQL_EV_Analytics` and choose SQL views such as `vw_station_profitability`.
4. **Connecting Tableau Desktop**:
   - Open Tableau Desktop -> **Connect** -> **To a Server** -> **MySQL**.
   - Server: `localhost`, Database: `ev_charging_analytics`, Username: `root`.
   - Select relational tables or certified analytical views (`vw_station_profitability`, `vw_daily_station_performance`).

#### Pathway B: Portable File-Based CSV Fallback (100% Offline Mode)
- In academic evaluation settings or machines without local MySQL server privileges, users can utilize the pre-packaged CSV files located in `data/tableau/` and `data/processed/`.
- Tableau Public and Microsoft Excel connect natively to text/CSV files with zero external drivers or database installations required.

---

### 5. Data Flow & Financial Integrity Controls

1. **Reconciliation Guarantee**:
   $$\text{Session Electricity Cost} = \sum (\text{energy\_delivered\_kwh} \times \text{electricity\_tariff\_per\_kwh\_inr})$$
   $$\text{Daily Table Electricity Cost} = \sum_{\text{stations, dates}} \text{electricity\_cost\_inr}$$
   $$\text{Variance} \le \text{INR } 0.15 \text{ (pure rounding artifact across 11,821 records)}$$

2. **Rent Allocation Reconciliation**:
   $$\sum_{d=1}^{\text{days\_in\_month}} \text{rent\_cost\_inr} = \text{monthly\_rent\_inr} \quad (\pm \text{INR } 0.00)$$

3. **Schedule Collision Prevention**:
   - Connector time lines are partitioned so that for any connector $C$:
     $$\forall i, j \ (i \neq j): \ [S_i, E_i] \cap [S_j, E_j] = \emptyset$$
     $$\forall i, k: \ [S_i, E_i] \cap [D_k^{\text{start}}, D_k^{\text{end}}] = \emptyset$$
   - This mathematically prevents double-booking a single charging plug.
