# EV Charging Station Analytics & Profitability Optimization
## Master Tableau Desktop Implementation Guide (Executive Dashboard Redesign)

**Project Title:** EV Charging Station Analytics & Profitability Optimization  
**Location:** Chandigarh, India (Synthetic Benchmark Dataset)  
**Target Environment:** Tableau Desktop 2023.x / 2024.x / 2026.x or Tableau Public  
**Primary Data Files:**  
- `tableau_station_daily.csv` (1,830 rows × 29 columns)  
- `tableau_sessions_flat.csv` (23,325 rows × 35 columns)  
**Canvas Dimensions:** 1400 × 800 Fixed Size, White Background `#FFFFFF`, 2px Solid Lavender Border `#8E7CC3`, 10px Padding  

---

## 1. Data Connection & Relationship Model (Avoiding Fan-Out)

### The Architecture: Why a Relationship (Not a Join)?
- `tableau_station_daily.csv` is at the **Station-Day Grain** (10 stations × 183 calendar days = 1,830 rows). It contains all fixed and allocated operating expenses (rent, staff, maintenance, other), as well as daily energy and charging revenues.
- `tableau_sessions_flat.csv` is at the **Session Transaction Grain** (23,325 rows).
- **The Cartesian Trap:** If you perform a physical `INNER JOIN` or `LEFT JOIN`, every daily rent and staff expense is multiplied by the number of sessions that occurred that day. A station hosting 30 sessions on a given day will duplicate its rent 30 times, blowing up network operating expenses from ₹79.11 Lakhs to over ₹10 Crores!
- **The Solution:** Establish a Tableau **Logical Relationship ("Noodle")**. Relationships query each table independently at its native level of detail and aggregate metrics on the fly without duplicating records.

### Click-by-Click Connection Setup
1. Launch **Tableau Desktop** or **Tableau Public**.
2. On the start page under **Connect -> To a File**, click **Text file**.
3. Navigate to `EV_Charging_Analytics/data/tableau/` (or the project root) and select **`tableau_station_daily.csv`**. Click **Open**.
4. In the Data Source canvas, click **Add** next to Connections (or drag from the left pane) and add **`tableau_sessions_flat.csv`**.
5. Drag `tableau_sessions_flat.csv` onto the canvas next to `tableau_station_daily.csv`. A flexible line (relationship "noodle") will appear.
6. In the Relationship definition dialog, configure two matching relationship clauses:
   - Clause 1: `[station_id]` = `[station_id (tableau_sessions_flat)]`
   - Clause 2: Click **Add more fields** $\rightarrow$ `[operating_date]` = `[session_date]`
7. Set Cardinality: **Many-to-Many** (or leave as Default).
8. Verify the connection name: `EV_Charging_Master`. Click on the **Sheet 1** tab to begin analysis.

> [!IMPORTANT]
> **Data Integrity Rule:**  
> Always use fields from **`tableau_station_daily`** for monetary and utilization metrics (`billed_revenue_inr`, `net_profit_inr`, `total_operating_cost_inr`, `charging_minutes`, `available_connector_minutes`).  
> Use fields from **`tableau_sessions_flat`** for transactional breakdowns (`charger_class`, `weather_condition`, `connector_type`, `start_hour`, `day_name`).

---

## 2. Parameters & Calculated Fields (Exact Tableau Syntax)

### Step 2.1: Create Parameters
Click the drop-down arrow next to the Search bar in the Data pane $\rightarrow$ **Create Parameter**:

1. **Parameter: `[Metric]`**
   - Data type: `String`
   - Allowable values: `List`
   - List of values:
     - `Revenue`
     - `Energy (kWh)`
     - `Sessions`
   - Current value: `Revenue`

2. **Parameter: `[Date Breakdown]`**
   - Data type: `String`
   - Allowable values: `List`
   - List of values:
     - `Week`
     - `Month`
   - Current value: `Month`

---

### Step 2.2: Create Calculated Fields
Go to **Analysis -> Create Calculated Field** for each formula:

#### 1. Core Financial Measures
```tableau
// Name: [Total Revenue]
SUM([billed_revenue_inr])
```
```tableau
// Name: [Net Profit]
SUM([net_profit_inr])
```
```tableau
// Name: [Profit Margin %]
SUM([net_profit_inr]) / SUM([billed_revenue_inr])
// Set default format: Percentage with 1 decimal place (0.0%)
```
```tableau
// Name: [Success Rate %]
SUM([completed_sessions]) / SUM([sessions])
// Set default format: Percentage (0.0%)
```
```tableau
// Name: [Failure Rate %]
SUM([failed_flag]) / COUNT([session_id])
// Set default format: Percentage (0.0%)
```
```tableau
// Name: [Avg Revenue / Session]
SUM([billed_revenue_inr]) / SUM([completed_sessions])
// Set default format: Currency Custom: ₹#,##0
```
```tableau
// Name: [Utilisation %]
SUM([charging_minutes]) / SUM([available_connector_minutes])
// Set default format: Percentage (0.0%)
```

#### 2. Dynamic Trend Controls
```tableau
// Name: [Date Axis]
CASE [Date Breakdown]
    WHEN 'Week' THEN DATETRUNC('week', [operating_date])
    ELSE DATETRUNC('month', [operating_date])
END
```
```tableau
// Name: [Selected Metric]
CASE [Metric]
    WHEN 'Revenue' THEN SUM([billed_revenue_inr])
    WHEN 'Energy (kWh)' THEN SUM([energy_delivered_kwh])
    WHEN 'Sessions' THEN SUM([sessions])
END
```

#### 3. Month-over-Month (MoM) Window Flags
```tableau
// Name: [Is Current Month]
DATETRUNC('month', [operating_date]) = DATETRUNC('month', {MAX([operating_date])})
```
```tableau
// Name: [Is Prior Month]
DATETRUNC('month', [operating_date]) = DATEADD('month', -1, DATETRUNC('month', {MAX([operating_date])}))
```

#### 4. MoM Growth Calculations & Delta Arrows
```tableau
// Name: [Revenue MoM %]
(SUM(IF [Is Current Month] THEN [billed_revenue_inr] END) - SUM(IF [Is Prior Month] THEN [billed_revenue_inr] END)) 
/ SUM(IF [Is Prior Month] THEN [billed_revenue_inr] END)
// Custom Number Format: "▲ +0.0%";"▼ -0.0%"
```
```tableau
// Name: [Net Profit MoM %]
(SUM(IF [Is Current Month] THEN [net_profit_inr] END) - SUM(IF [Is Prior Month] THEN [net_profit_inr] END)) 
/ ABS(SUM(IF [Is Prior Month] THEN [net_profit_inr] END))
// Custom Number Format: "▲ +0.0%";"▼ -0.0%"
```
```tableau
// Name: [Sessions MoM %]
(SUM(IF [Is Current Month] THEN [sessions] END) - SUM(IF [Is Prior Month] THEN [sessions] END)) 
/ SUM(IF [Is Prior Month] THEN [sessions] END)
// Custom Number Format: "▲ +0.0%";"▼ -0.0%"
```
```tableau
// Name: [Avg Rev MoM %]
(
  (SUM(IF [Is Current Month] THEN [billed_revenue_inr] END) / SUM(IF [Is Current Month] THEN [completed_sessions] END)) -
  (SUM(IF [Is Prior Month] THEN [billed_revenue_inr] END) / SUM(IF [Is Prior Month] THEN [completed_sessions] END))
) / (SUM(IF [Is Prior Month] THEN [billed_revenue_inr] END) / SUM(IF [Is Prior Month] THEN [completed_sessions] END))
// Custom Number Format: "▲ +0.0%";"▼ -0.0%"
```
```tableau
// Name: [Success Rate MoM %]
(
  (SUM(IF [Is Current Month] THEN [completed_sessions] END) / SUM(IF [Is Current Month] THEN [sessions] END)) -
  (SUM(IF [Is Prior Month] THEN [completed_sessions] END) / SUM(IF [Is Prior Month] THEN [sessions] END))
) / (SUM(IF [Is Prior Month] THEN [completed_sessions] END) / SUM(IF [Is Prior Month] THEN [sessions] END))
// Custom Number Format: "▲ +0.0%";"▼ -0.0%"
```
```tableau
// Name: [Revenue Delta Color]
IF [Revenue MoM %] >= 0 THEN 'Up' ELSE 'Down' END
```
*(Apply the same Delta Color logic for Profit, Sessions, Avg Rev, and Success Rate).*

---

## 3. Worksheet Construction (Click-by-Click)

### Worksheet 1: `1. KPI Strip`
1. Open a new worksheet and rename it `1. KPI Strip`.
2. Change the Mark type from *Automatic* to **Text**.
3. Drag `[Total Revenue]`, `[Net Profit]`, `[Profit Margin %]`, `[Total Sessions]`, `[Avg Revenue / Session]`, and `[Success Rate %]` onto **Detail**.
4. Drag their respective `MoM %` fields onto **Detail**.
5. Click **Text** on the Marks card $\rightarrow$ click the **`...`** button to edit text.
6. Lay out the 5 KPI tiles with custom formatting:
   - **Tile 1:** `TOTAL REVENUE` (9pt, `#595959`) $\rightarrow$ `<SUM(Total Revenue)>` (18pt Bold Navy `#1F3A5F`) $\rightarrow$ `<Revenue MoM %> MoM` (10pt Green `#2E9E5B`)
   - **Tile 2:** `NET PROFIT` (9pt) $\rightarrow$ `<SUM(Net Profit)>` (18pt Bold Navy) $\rightarrow$ `<Profit Margin %> | <Net Profit MoM %>` (10pt)
   - **Tile 3:** `TOTAL SESSIONS` (9pt) $\rightarrow$ `<SUM(sessions)>` (18pt Bold Navy) $\rightarrow$ `<Sessions MoM %> MoM` (10pt)
   - **Tile 4:** `AVG REV / SESSION` (9pt) $\rightarrow$ `<Avg Revenue / Session>` (18pt Bold Navy) $\rightarrow$ `<Avg Rev MoM %> MoM` (10pt)
   - **Tile 5:** `SUCCESS RATE` (9pt) $\rightarrow$ `<Success Rate %>` (18pt Bold Navy) $\rightarrow$ `<Success Rate MoM %> MoM` (10pt Red `#D64545`)
7. Alternatively, create 5 small separate sheets (`KPI - Revenue`, `KPI - Profit`, etc.) and place them inside a horizontal layout container on the dashboard with 1px gray dividers.

---

### Worksheet 2: `2. Trend` ("Revenue and Profit Margin Over Time")
1. Open a new worksheet and rename it `2. Trend`.
2. Title the sheet: `<font color="#1F3A5F"><b>Revenue</b></font> and <font color="#E8672A"><b>Profit Margin</b></font> Over Time`.
3. Drag `[Date Axis]` to the **Columns** shelf. Right-click it and select **Exact Date** (or Discrete Continuous).
4. Drag `[Selected Metric]` to the **Rows** shelf.
5. Drag `[Profit Margin %]` to the **Rows** shelf, placing it to the right of `[Selected Metric]`.
6. Right-click the `[Profit Margin %]` pill on Rows and select **Dual Axis**.
7. **Do NOT synchronize axes** (Selected Metric is Currency/Number on the left axis; Profit Margin is Percentage on the right axis).
8. On the Marks card for `[Selected Metric]`:
   - Set mark type to **Line**.
   - Set Color to Navy (`#1F3A5F`).
   - Click Color $\rightarrow$ Marker $\rightarrow$ select **Circle** (round dots on data points).
9. On the Marks card for `[Profit Margin %]`:
   - Set mark type to **Line**.
   - Set Color to Orange (`#E8672A`).
   - Click Color $\rightarrow$ Marker $\rightarrow$ select **Circle**.
10. Formatting:
    - Right-click anywhere in the chart $\rightarrow$ **Format**.
    - Under Lines $\rightarrow$ Gridlines: set to thin light gray (`#E2E8F0`).
    - Under Zero Lines: set to **None**.

---

### Worksheet 3: `3. Stations` ("Revenue and Profit Margin by Station")
1. Open a new worksheet and rename it `3. Stations`.
2. Title the sheet: `<font color="#4C9F93"><b>Revenue</b></font> and <font color="#E8672A"><b>Profit Margin</b></font> by Station`.
3. Drag `[station_name]` from `tableau_station_daily` to the **Rows** shelf.
4. Drag `[billed_revenue_inr]` to the **Columns** shelf.
5. Drag `[net_profit_inr]` (or `[Profit Margin %]`) to the **Columns** shelf next to revenue.
6. Right-click `[station_name]` on Rows $\rightarrow$ **Sort** $\rightarrow$ Sort by: **Field**, Field Name: `billed_revenue_inr`, Aggregation: `Sum`, Sort Order: **Descending**.
7. In the Marks card for `[billed_revenue_inr]`:
   - Mark type: **Bar**.
   - Color: Teal (`#4C9F93`).
   - Drag `[billed_revenue_inr]` to **Label**. Format label as Currency: `₹#,##0,,.0"L"` (e.g. `₹26.0L`).
8. In the Marks card for `[Profit Margin %]`:
   - Mark type: **Bar**.
   - Color: Orange (`#E8672A`).
   - Drag `[Profit Margin %]` to **Label**. Format label as Percentage: `+0.0%;-0.0%` (e.g. `+39.9%`).
9. Right-click both bottom axes and uncheck **Show Header** to eliminate clutter.

---

### Worksheet 4: `4. Connectors` ("Revenue and Success Rate by Charger Class")
1. Open a new worksheet and rename it `4. Connectors`.
2. Title the sheet: `<font color="#4C9F93"><b>Revenue</b></font> and <font color="#F2C45A"><b>Success Rate</b></font> by Charger Class`.
3. Drag `[charger_class]` from `tableau_sessions_flat` to the **Rows** shelf.
4. Drag `[billed_revenue_inr]` to the **Columns** shelf.
5. Drag `[Success Rate %]` to the **Columns** shelf.
6. On the `[billed_revenue_inr]` marks card:
   - Mark type: **Bar**. Color: Teal (`#4C9F93`).
   - Drag `[billed_revenue_inr]` to **Label** (`₹#,##0,,.0"L"`).
7. On the `[Success Rate %]` marks card:
   - Mark type: **Bar**. Color: Gold (`#F2C45A`).
   - Drag `[Success Rate %]` to **Label** (`0.0%`).
8. Uncheck axis headers for a clean card presentation.

---

### Worksheet 5: `5. Map` ("Revenue by Station")
1. Open a new worksheet and rename it `5. Map`.
2. Title the sheet: `<font color="#4C9F93"><b>Revenue</b></font> by Station`.
3. Drag `[longitude]` to the **Columns** shelf.
4. Drag `[latitude]` to the **Rows** shelf.
5. Ensure both fields have geographical roles assigned (right-click $\rightarrow$ *Geographic Role* $\rightarrow$ Latitude/Longitude).
6. Drag `[station_name]` to **Detail** on the Marks card.
7. Change Mark type to **Circle** (or Shape).
8. Drag `[billed_revenue_inr]` to **Size** (larger bubbles indicate high-revenue hubs).
9. Drag `[Profit Margin %]` to **Color**:
   - Click Color $\rightarrow$ **Edit Colors**.
   - Select Palette: **Orange-White-Teal Diverging** (or Red-White-Green).
   - Check **Center** and enter `0.00` (so 0% margin is neutral white, negative margins are orange/red, and positive margins are teal/green).
10. Drag `[station_name]` to **Label**. Select *Show mark labels*.
11. Map Options: Go to **Map -> Map Layers** $\rightarrow$ Style: **Light**. Uncheck extraneous layers for a clean minimalist city map of Chandigarh.

---

### Worksheet 6: `6. Weather` ("Revenue and Failure Rate by Weather")
1. Open a new worksheet and rename it `6. Weather`.
2. Title the sheet: `<font color="#4C9F93"><b>Revenue</b></font> and <font color="#F2C45A"><b>Failure Rate</b></font> by Weather`.
3. Drag `[weather_condition]` from `tableau_sessions_flat` to the **Rows** shelf.
4. Drag `[billed_revenue_inr]` to the **Columns** shelf.
5. Drag `[Failure Rate %]` to the **Columns** shelf.
6. On the `[billed_revenue_inr]` marks card:
   - Mark type: **Bar**. Color: Teal (`#4C9F93`). Label: Revenue in Lakhs.
7. On the `[Failure Rate %]` marks card:
   - Mark type: **Bar**. Color: Gold (`#F2C45A`). Label: Percentage with 1 decimal (`0.0%`).
8. Uncheck bottom axis headers.

---

## 4. Master Dashboard Assembly (Fixed 1400 × 800)

Follow this exact container layout structure to replicate the reference design:

```text
+---------------------------------------------------------------------------------------------------------+
| [OUTER CONTAINER: Fixed 1400 x 800 px | White Background | 2px Border #8E7CC3 | 10px Padding]           |
|                                                                                                         |
|  TITLE STRIP (Height: 50 px)                                                                            |
|  Title: EV Charging Station Analytics & Profitability Optimization       [Station Filter] [Day Type]   |
+---------------------------------------------------------------------------------------------------------+
|  ROW 1: KPI STRIP (Height: 90 px) - Horizontal Container                                                |
|  +----------------+ +----------------+ +----------------+ +----------------+ +----------------+        |
|  | TOTAL REVENUE  | |   NET PROFIT   | |    SESSIONS    | | AVG REV / SESS | |  SUCCESS RATE  |        |
|  |     ₹93.1L     | | ₹13.97L (15.0%)| |     23,325     | |      ₹437      | |     91.3%      |        |
|  |    ▲ +8.0%     | |    ▲ +33.5%    | |    ▲ +6.4%     | |    ▲ +2.3%     | |    ▼ -0.8%     |        |
|  +----------------+ +----------------+ +----------------+ +----------------+ +----------------+        |
+---------------------------------------------------------------------------------------------------------+
|  ROW 2: MIDDLE CHARTS (Height: 330 px) - Horizontal Container                                            |
|  +-------------------------------------------------------+ +-------------------------------------------+|
|  | 2. Trend (Width: 58% ~ 800 px)                        | | 3. Stations (Width: 42% ~ 580 px)         ||
|  | Controls: [Metric: Revenue] [Date: Month]             | | Horizontal bars: Revenue (Teal)           ||
|  | Dual-Axis: Revenue (Navy) & Profit Margin % (Orange)  | | & Margin % (Orange) with end-labels       ||
|  +-------------------------------------------------------+ +-------------------------------------------+|
+---------------------------------------------------------------------------------------------------------+
|  ROW 3: BOTTOM CHARTS (Height: 280 px) - Horizontal Container (Three Equal Columns ~ 460 px each)       |
|  +-------------------------------+ +-------------------------------+ +-------------------------------+|
|  | 4. Connectors (Width: 33%)    | | 5. Map (Width: 34%)           | | 6. Weather (Width: 33%)       ||
|  | Revenue & Success Rate by     | | Symbol map of Chandigarh      | | Revenue & Failure Rate by     ||
|  | Charger Class (Teal & Gold)   | | Sized by Rev, Colored by Marg | | Weather (Teal & Gold)         ||
|  +-------------------------------+ +-------------------------------+ +-------------------------------+|
+---------------------------------------------------------------------------------------------------------+
```

### Dashboard Layout Configuration Steps
1. Create a new Dashboard: Name it **`Executive Operations & Profitability Dashboard`**.
2. In the Dashboard panel on the left:
   - Size: Select **Fixed Size** $\rightarrow$ Set Width to **`1400`** and Height to **`800`**.
3. Outer Container:
   - Drag a **Vertical Container** onto the canvas.
   - Go to the **Layout** tab on the left panel:
     - Set Border: **2px solid lavender (`#8E7CC3`)**.
     - Set Outer Padding: **0px**, Inner Padding: **10px**.
     - Background: **White (`#FFFFFF`)**.
4. Title Strip (Top):
   - Drag a **Horizontal Container** inside the vertical container (Height: 50px).
   - Add a Text object on the left: `EV Charging Station Analytics & Profitability Optimization` (16pt Bold Navy `#1F3A5F`).
   - On the right, add filters for `[operating_date]` (slider), `[station_name]` (dropdown), and `[day_type]` (dropdown).
5. Row 1: KPI Strip (Height: 90px):
   - Drag a **Horizontal Container** beneath the Title strip.
   - Drag `1. KPI Strip` inside. Set height to exactly **90px**.
6. Row 2: Middle Charts (Height: 330px):
   - Drag a **Horizontal Container** beneath Row 1. Set height to **330px**.
   - Drag `2. Trend` into the left side. Right-click container $\rightarrow$ set Width to **58%** (~800px).
   - Show Parameter Controls: Click sheet menu $\rightarrow$ *Parameters* $\rightarrow$ check `[Metric]` and `[Date Breakdown]`. Position them above the trend chart.
   - Drag `3. Stations` into the right side (Width: **42%** ~580px).
7. Row 3: Bottom Charts (Height: 280px):
   - Drag a **Horizontal Container** beneath Row 2. Set height to **280px**.
   - Drag `4. Connectors` to the left (Width: ~460px).
   - Drag `5. Map` to the middle (Width: ~460px).
   - Drag `6. Weather` to the right (Width: ~460px).
8. Interactivity (Dashboard Filter Actions):
   - Go to **Dashboard -> Actions -> Add Action -> Filter**.
   - Name: `Cross Filter by Station`.
   - Source Sheets: Check `3. Stations` and `5. Map`.
   - Target Sheets: Check All sheets.
   - Run action on: **Select**. Clearing selection: **Show all values**.
   - Now, clicking any station on the bar chart or map dynamically filters every single KPI and chart on the dashboard!

---

## 5. Verified Data Sanity Checks (Read From Worksheets)

When viewing the dashboard with no filters applied, your numbers will match these exact benchmark values:

| Metric Name | Worksheet Source | Benchmark Value | Exact Formula Verification |
| :--- | :--- | :--- | :--- |
| **Total Billed Revenue** | `1. KPI Strip`, `2. Trend` | **₹ 93.07 Lakhs** (₹93,07,323.39) | `SUM(billed_revenue_inr)` across 1,830 rows |
| **Net Operating Profit** | `1. KPI Strip`, `2. Trend` | **₹ 13.97 Lakhs** (₹13,96,612.90) | `SUM(net_profit_inr)` = Revenue - All OPEX |
| **Operating Profit Margin**| `1. KPI Strip`, `3. Stations`| **15.0%** | `₹13.97L / ₹93.07L = 15.006%` |
| **Total Sessions** | `1. KPI Strip`, `2. Trend` | **23,325 Sessions** | `SUM(sessions)` = 21,299 completed + 1,008 failed + 1,018 cancelled |
| **Session Success Rate** | `1. KPI Strip`, `4. Connectors`| **91.3%** | `21,299 completed / 23,325 total = 91.31%` |
| **Avg Revenue / Session** | `1. KPI Strip` | **₹ 436.98 (~₹437)** | `₹93,07,323.39 / 21,299 completed sessions` |
| **Network Utilisation** | Calculated Field | **15.3%** | `3,995,744 charging min / 26,112,040 available min` |
| **Top Station (Profit)** | `3. Stations` | **ISBT Sector 43 (+₹10.37L | +39.9%)** | Highest throughput 24/7 transit terminal |
| **Bottom Station (Loss)**| `3. Stations` | **Manimajra Housing (-₹1.43L | -91.8%)**| Low residential charging demand vs. fixed rent |

---

## 6. Business Insights & Executive Analysis

1. **Revenue Growth vs. Margin Expansion (from `2. Trend`):**  
   *What the data shows:* Network revenue grew from **₹13.8 Lakhs** (April 2026) to **₹17.1 Lakhs** (September 2026), while monthly profit surged from **₹0.52 Lakhs (3.8% margin)** to **₹3.26 Lakhs (19.0% margin)**.  
   *Why it matters:* Fixed operating costs (rent and staffing) remained flat at ~₹7.5 Lakhs/month, allowing incremental revenue to flow directly to the bottom line, demonstrating strong operational leverage.  
   *Recommendation:* Reinvest positive monthly cash flows into adding DC fast-charging capacity at peak corridors.

2. **Severe Station Profitability Skew (from `3. Stations` & `5. Map`):**  
   *What the data shows:* Four stations generate 100% of network operating profits (**ISBT Sector 43** at +₹10.37L, **Highway Corridor Sector 28** at +₹4.80L, **Industrial Area Mall** at +₹3.51L, and **Sector 17 Plaza** at +₹0.76L), while six stations incur net operating losses (ranging from -5.2% at Sector 35 to -91.8% at Manimajra).  
   *Why it matters:* Stations operating 24/7 along commercial transit corridors have sufficient volume to overcome high facility leases, whereas restricted-hour residential sites (Manimajra, Sector 34) cannot cover fixed overheads.  
   *Recommendation:* Convert loss-making stations to automated, unstaffed sites to eliminate attendant wages (saving ₹19,500/month per site), and renegotiate commercial land leases into revenue-share contracts (10% of revenue).

3. **Fast Chargers Drive Network Yield (from `4. Connectors`):**  
   *What the data shows:* **DC rapid chargers ($\ge$60 kW)** generated **₹60.1 Lakhs** (64.6% of network revenue) across 11,529 sessions with a 91.6% success rate, while **AC slow chargers (7.4–22 kW)** generated only **₹19.1 Lakhs** across 7,779 sessions.  
   *Why it matters:* Urban EV drivers require rapid turnaround times (30–45 minutes) and actively avoid 4-hour slow AC charging during daytime operations.  
   *Recommendation:* Phase out underutilized 7.4 kW AC chargers at commercial transit hubs and redeploy capital toward dual-gun 60 kW DC fast chargers.

4. **Weather-Induced Reliability Degradation (from `6. Weather`):**  
   *What the data shows:* Session failure rates increase by **64% during monsoon rain** (5.9% failure rate on rainy days vs. 3.6% on clear days), accounting for ₹21.5 Lakhs in billed revenue.  
   *Why it matters:* Heavy rain causes moisture ingress in cable connector pins and triggers electrical ground-fault trips, leading to aborted sessions and driver dissatisfaction.  
   *Recommendation:* Install weatherproof canopy shelters and IP67-rated connector holsters at open-air stations (Sector 22 Parking and Highway Corridor).

---

## 7. How to Present This Dashboard in a Viva Voce Exam

> "Good morning, respected examiners. My MCA capstone project addresses the commercial viability of urban Electric Vehicle charging infrastructure in Chandigarh, India.  
> 
> As displayed on our Executive Dashboard, the network delivered **406,073 kWh** of energy across **23,325 charging sessions**, generating **₹93.1 Lakhs in top-line revenue** and **₹13.97 Lakhs in net operating profit**, achieving a **15.0% operating margin** at a **15.3% network utilization rate**.  
> 
> The executive layout is structured into three decision-making tiers:  
> First, the **Top KPI Strip** gives leadership an immediate health check on top-line revenue, bottom-line profit, throughput, and success rate, including month-over-month trends.  
> Second, the **Middle Tier** pairs our dynamic **Revenue vs. Profit Margin Trend** with our **Station Profitability Ranking**, revealing that profitability is concentrated in 24/7 transit hubs like ISBT Sector 43 (+39.9% margin), while restricted residential nodes like Manimajra (-91.8% margin) operate at an accounting loss.  
> Third, the **Bottom Tier** examines root operational drivers: our **Charger Class analysis** proves that DC rapid chargers drive 65% of revenue; the **Geographic Symbol Map** highlights regional spatial demand; and the **Weather breakdown** reveals that monsoon rains elevate session failure rates from 3.6% to 5.9%.  
> 
> Methodologically, we prevented data duplication by connecting our daily cost ledger and session transaction tables via **Tableau Logical Relationships on Station ID and Operating Date**, ensuring zero double-counting of fixed expenses without requiring complex physical joins."

---

## 8. Common Pitfalls & Mistakes to Avoid

1. **Double-Counting Operating Expenses (Physical Joins vs. Relationships):**  
   *The Mistake:* Performing a standard physical `INNER JOIN` between `tableau_station_daily` and `tableau_sessions_flat` on `station_id`.  
   *Why it is fatal:* Daily rent and staff costs are duplicated for every session that occurred on that day. In a physical join, operating costs multiply from ₹79.11 Lakhs to over ₹10 Crores!  
   *The Fix:* Use Tableau's logical Relationships (Noodles) on `station_id` AND `operating_date = session_date`.

2. **Confusing Billed Revenue with Collected Revenue:**  
   *The Mistake:* Using `collected_revenue_inr` when analyzing top-line commercial demand.  
   *Why it is fatal:* In our dataset, completed sessions have ₹93.07 Lakhs in billed revenue, but ₹2.1 Lakhs in customer invoices remain pending settlement or experienced payment gateway processing delays.  
   *The Fix:* Always use `billed_revenue_inr` for demand and P&L modeling, and evaluate `collected_revenue_inr` strictly when auditing working capital liquidity and payment gateway failure rates.

3. **Re-Adding Electricity Costs to Station Daily Costs:**  
   *The Mistake:* Adding `electricity_cost_inr` from `tableau_sessions_flat` to `total_operating_cost_inr` from `tableau_station_daily`.  
   *Why it is fatal:* `total_operating_cost_inr` in `tableau_station_daily` **already includes** the aggregated daily electricity cost! Adding it a second time inflates COGS by ₹33.64 Lakhs.

4. **Synchronizing Dual Axes with Incompatible Metric Scales:**  
   *The Mistake:* Checking "Synchronize Axis" on the `2. Trend` line chart.  
   *Why it is fatal:* The left axis represents Currency (`₹0` to `₹18,00,000`), while the right axis represents a Percentage (`0.0%` to `25.0%`). Synchronizing axes forces the percentage line to flatten into a straight line along the zero axis!  
   *The Fix:* Keep the axes unsynchronized, format the left axis as Currency (`₹`), and format the right axis as Percentage (`%`).
