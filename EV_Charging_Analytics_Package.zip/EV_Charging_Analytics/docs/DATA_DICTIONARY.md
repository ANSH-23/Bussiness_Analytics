# EV Charging Station Analytics & Profitability Optimization
## Master Data Dictionary & Enterprise Data Catalog
### Synthetic Dataset (Chandigarh, India) | Currency: INR (₹) | Energy: kWh | Power: kW | Duration: Minutes

---

### 1. Catalog Summary & Entity Overview

This data dictionary defines all entity structures, attribute schemas, business rules, constraints, and valid domain values across the synthetic relational tables comprising the EV Charging Network dataset.

| Entity Name | Primary Key | Parent Entity | Exact Row Count | Grain / Level of Detail |
| :--- | :--- | :--- | :--- | :--- |
| **stations.csv** | `station_id` | Master | 10 rows | 1 row per physical EV charging station facility in Chandigarh |
| **connectors.csv** | `connector_id` | stations | 50 rows | 1 row per physical charging connector / charging port |
| **tariff_history.csv** | `tariff_id` | connectors | 149 rows | 1 row per connector per distinct pricing validity window |
| **charging_sessions.csv** | `session_id` | connectors, stations | 23,325 rows | 1 row per EV charging session attempt |
| **station_downtime.csv** | `downtime_id` | connectors, stations | 571 rows | 1 row per outage or maintenance window event |
| **daily_station_operating_costs.csv** | `record_id` | stations | 1,830 rows | 1 row per station per calendar operating day (10 stations × 183 days) |
| **station_daily_kpis.csv** | `(operating_date, station_id)` | stations | 1,830 rows | 1 row per station per calendar day summarizing operational KPIs |

---

### 2. Entity Specifications

#### 2.1 Table: `stations.csv`
*Master entity defining physical charging hub locations, geographic coordinates, fixed leases, and capacity.*

| Column Name | Type (MySQL) | Nullable | Constraints / Domain | Unit | Description & Business Rules | Example Value |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `station_id` | VARCHAR(10) | No | PK, `ST01`..`ST10` | - | Unique station code. | `ST01` |
| `station_name` | VARCHAR(80) | No | Non-empty string | - | Descriptive commercial facility name. | `EV Hub Sector 17 Plaza` |
| `city` | VARCHAR(40) | No | Constant: `'Chandigarh'` | - | Municipal operating jurisdiction. | `Chandigarh` |
| `area` | VARCHAR(60) | No | Chandigarh sectors | - | Geographic neighborhood / commercial micro-market. | `Sector 17` |
| `latitude` | DECIMAL(9, 4) | No | Range: [30.70, 30.78] | Degrees | WGS84 latitude coordinate. | `30.7398` |
| `longitude` | DECIMAL(9, 4) | No | Range: [76.74, 76.85] | Degrees | WGS84 longitude coordinate. | `76.7827` |
| `installation_date` | DATE | No | Format: `YYYY-MM-DD` | - | Date station was commissioned and energized. | `2024-03-15` |
| `total_connectors` | INT | No | Range: [4, 6] | Count | Number of charging ports deployed at station. | `6` |
| `station_type` | VARCHAR(40) | No | Commercial, Mall, IT Park, Hospital, Transit, Parking, Highway, Residential, Office | - | Site category influencing daily footfall patterns. | `Commercial Market` |
| `monthly_rent_inr` | DECIMAL(12, 2) | No | $\ge 0$ | INR (₹) | Fixed monthly land/facility lease payable to landlord. | `48000.00` |
| `maintenance_cost_monthly_inr`| DECIMAL(12, 2) | No | $\ge 0$ | INR (₹) | Routine monthly upkeep and SLA maintenance contract. | `7200.00` |
| `operating_hours_per_day` | INT | No | 12, 16, 18, 24 | Hours | Daily operational accessibility (24 = 24/7). | `16` |

---

#### 2.2 Table: `connectors.csv`
*Physical charging connectors, hardware standards, grid power ratings, and base tariffs.*

| Column Name | Type (MySQL) | Nullable | Constraints / Domain | Unit | Description & Business Rules | Example Value |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `connector_id` | VARCHAR(10) | No | PK, `CN001`..`CN050` | - | Unique connector identifier across network. | `CN001` |
| `station_id` | VARCHAR(10) | No | FK -> `stations.station_id` | - | Station where connector is physically mounted. | `ST01` |
| `connector_type` | VARCHAR(20) | No | AC Type 2, DC CCS2, DC CHAdeMO | - | Standardized hardware plug standard. | `DC CCS2` |
| `rated_power_kw` | DECIMAL(5, 1) | No | 7.4, 22.0, 30.0, 50.0, 60.0, 120.0 | kW | Maximum rated power output capacity. | `60.0` |
| `installation_date` | DATE | No | Format: `YYYY-MM-DD` | - | Date port was commissioned. | `2024-03-20` |
| `connector_status` | VARCHAR(20) | No | Active, Under Maintenance | - | Operational status at study cut-off date. | `Active` |
| `electricity_tariff_per_kwh_inr` | DECIMAL(8, 2) | No | Range: [7.00, 9.00] | INR (₹) | Electricity cost tariff in force on 2026-09-30. | `8.55` |

---

#### 2.3 Table: `tariff_history.csv`
*Time-bound electricity purchase rates (COGS) and customer billing tariffs.*

| Column Name | Type (MySQL) | Nullable | Constraints / Domain | Unit | Description & Business Rules | Example Value |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `tariff_id` | VARCHAR(10) | No | PK, `TF0001`.. | - | Unique tariff period identifier. | `TF0001` |
| `connector_id` | VARCHAR(10) | No | FK -> `connectors.connector_id` | - | Connector the pricing schedule applies to. | `CN001` |
| `effective_from` | DATE | No | Format: `YYYY-MM-DD` | - | Start of validity period (inclusive). | `2026-01-01` |
| `effective_to` | DATE | No | Format: `YYYY-MM-DD` | - | End of validity period (inclusive). Non-overlapping. | `2026-05-31` |
| `electricity_tariff_per_kwh_inr`| DECIMAL(8, 2) | No | > 0 | INR (₹) | Grid procurement tariff paid to utility (landed cost). | `8.05` |
| `customer_price_per_kwh_inr` | DECIMAL(8, 2) | No | $\ge$ elec tariff | INR (₹) | Retail customer price per kWh billed to EV drivers. | `23.00` |

---

#### 2.4 Table: `charging_sessions.csv`
*Transactional charging session logs across all 50 connectors over 183 calendar days.*

| Column Name | Type (MySQL) | Nullable | Constraints / Domain | Unit | Description & Business Rules | Example Value |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `session_id` | VARCHAR(10) | No | PK, `S000001`.. | - | Unique transactional session identifier. | `S000001` |
| `connector_id` | VARCHAR(10) | No | FK -> `connectors.connector_id` | - | Charging connector utilized for session. | `CN009` |
| `station_id` | VARCHAR(10) | No | FK -> `stations.station_id` | - | Station identifier (redundant FK for query acceleration).| `ST02` |
| `vehicle_id` | VARCHAR(12) | No | Synthetic vehicle tag | - | Masked vehicle identifier (`VEH-xxxxxx`). | `VEH-331892` |
| `session_start` | DATETIME | No | Format: `YYYY-MM-DD HH:MM:SS` | - | Timestamp when connector cable was plugged in. | `2026-04-01 00:06:00` |
| `session_end` | DATETIME | No | `session_end > session_start` | - | Timestamp when session terminated and unplugged. | `2026-04-01 01:20:00` |
| `energy_delivered_kwh` | DECIMAL(8, 2) | No | $\ge 0$ | kWh | Net active electricity transferred into vehicle battery. | `2.21` |
| `charging_duration_minutes` | INT | No | $\ge 0$ | Minutes | Net active power delivery duration. | `45` |
| `idle_duration_minutes` | INT | No | $\ge 0$ | Minutes | Post-charge bay occupancy time (cable plugged, not charging). | `29` |
| `electricity_tariff_per_kwh_inr`| DECIMAL(8, 2) | No | > 0 | INR (₹) | COGS electricity tariff applicable at session start. | `7.44` |
| `charging_revenue_inr` | DECIMAL(10, 2) | No | $\ge 0$ | INR (₹) | Gross billed revenue ($Energy \times CustomerPrice$). | `33.15` |
| `session_status` | VARCHAR(12) | No | Completed, Failed, Cancelled | - | Operational outcome of session. | `Completed` |
| `payment_status` | VARCHAR(16) | No | Paid, Payment Failed, Pending, Not Charged | - | Settlement status of customer invoice. | `Paid` |
| `day_type` | VARCHAR(10) | No | Weekday, Weekend, Holiday | - | Calendar day classification. | `Weekday` |
| `weather_condition` | VARCHAR(10) | No | Clear, Cloudy, Hot, Rain | - | City-wide prevailing meteorological condition. | `Clear` |

---

#### 2.5 Table: `station_downtime.csv`
*Granular outage, hardware fault, communication failure, and routine maintenance logs.*

| Column Name | Type (MySQL) | Nullable | Constraints / Domain | Unit | Description & Business Rules | Example Value |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `downtime_id` | VARCHAR(10) | No | PK, `DT00001`.. | - | Unique downtime incident identifier. | `DT00001` |
| `connector_id` | VARCHAR(10) | No | FK -> `connectors.connector_id` | - | Charging connector rendered unavailable. | `CN004` |
| `station_id` | VARCHAR(10) | No | FK -> `stations.station_id` | - | Station identifier where incident occurred. | `ST01` |
| `downtime_start` | DATETIME | No | Format: `YYYY-MM-DD HH:MM:SS` | - | Timestamp when connector went offline. | `2026-04-01 09:48:00` |
| `downtime_end` | DATETIME | No | `downtime_end > downtime_start` | - | Timestamp when connector was restored to service. | `2026-04-01 11:47:00` |
| `downtime_duration_minutes` | INT | No | $\ge 0$ | Minutes | Total outage duration ($End - Start$). | `119` |
| `downtime_reason` | VARCHAR(40) | No | Planned Maintenance, Equipment Fault, Cable/Connector Damage, Power Outage, Software/Communication Error, Firmware Update, Vandalism | - | Root cause category for Pareto analysis. | `Planned Maintenance` |
| `maintenance_type` | VARCHAR(25) | No | Preventive, Corrective, Remote Resolution, Software Update, None (Grid Event) | - | Field technician intervention classification. | `Preventive` |
| `maintenance_cost_inr` | DECIMAL(10, 2) | No | $\ge 0$ | INR (₹) | Direct unscheduled repair invoice cost (parts + labor). | `1350.00` |

---

#### 2.6 Table: `daily_station_operating_costs.csv`
*Daily allocated operating cost ledger reconciling electricity, staff, rent, maintenance, and overheads.*

| Column Name | Type (MySQL) | Nullable | Constraints / Domain | Unit | Description & Business Rules | Example Value |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `record_id` | VARCHAR(10) | No | PK, `OC000001`.. | - | Unique daily operating cost record identifier. | `OC000001` |
| `station_id` | VARCHAR(10) | No | FK -> `stations.station_id` | - | Charging station incurred operating expenses. | `ST01` |
| `operating_date` | DATE | No | Format: `YYYY-MM-DD` | - | Accounting calendar date (2026-04-01 .. 2026-09-30). | `2026-04-01` |
| `electricity_cost_inr` | DECIMAL(12, 2) | No | $\ge 0$ | INR (₹) | Daily electricity procurement cost (sum of session kWh × tariff).| `1747.40` |
| `staff_cost_inr` | DECIMAL(12, 2) | No | $\ge 0$ | INR (₹) | Daily site attendant / security shift cost. | `650.00` |
| `rent_cost_inr` | DECIMAL(12, 2) | No | $\ge 0$ | INR (₹) | Allocated daily lease ($MonthlyRent / DaysInMonth$). | `1600.00` |
| `maintenance_cost_inr` | DECIMAL(12, 2) | No | $\ge 0$ | INR (₹) | Routine daily maintenance allocation + daily incident repairs. | `1590.00` |
| `other_operating_cost_inr` | DECIMAL(12, 2) | No | $\ge 0$ | INR (₹) | Daily internet, software licenses, cleaning, and security fees. | `205.62` |

---

#### 2.7 Table: `station_daily_kpis.csv`
*Derived daily operational scorecard reconciling sessions, utilization, uptime, revenue, and profit.*

| Column Name | Type (MySQL) | Nullable | Description & Formula | Example Value |
| :--- | :--- | :--- | :--- | :--- |
| `operating_date` | DATE | No | Calendar operating date. | `2026-04-01` |
| `station_id` | VARCHAR(10) | No | Unique station identifier. | `ST01` |
| `total_sessions` | INT | No | Total plug-in attempts recorded on date. | `17` |
| `completed_sessions` | INT | No | Sessions successfully completed and paid. | `16` |
| `failed_sessions` | INT | No | Failed or cancelled charging attempts. | `1` |
| `energy_delivered_kwh` | DECIMAL(8, 2) | No | Total net energy dispensed (kWh). | `211.55` |
| `charging_revenue_inr` | DECIMAL(10, 2) | No | Total gross billed revenue from completed sessions. | `4865.65` |
| `electricity_cost_inr` | DECIMAL(12, 2) | No | COGS utility electricity expense. | `1747.40` |
| `available_connector_minutes` | INT | No | Scheduled connector capacity ($Ports \times OperatingHours \times 60$). | `5760` |
| `downtime_minutes` | INT | No | Total equipment downtime minutes recorded. | `119` |
| `utilization_rate` | DECIMAL(6, 4) | No | Active charging minutes / (Available minutes - Downtime minutes). | `0.1580` |
| `operating_profit_inr` | DECIMAL(12, 2) | No | Billed Revenue - Total Daily Operating Costs. | `-927.37` |
