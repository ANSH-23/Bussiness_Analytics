#!/usr/bin/env python3
"""Builds DATA_DICTIONARY.md. Examples are taken from the real generated CSV files,
so they always match the data.   Usage: python build_data_dictionary.py --data data --out DATA_DICTIONARY.md"""
import argparse
import csv
import os

SPEC = {
    "stations.csv": ("Station master data (10 rows). One row per charging station.", None, [
        ("station_id", "VARCHAR(10) PK", "Unique station code (ST01..ST10)."),
        ("station_name", "VARCHAR(80)", "Synthetic station name (not a real operator)."),
        ("city", "VARCHAR(40)", "City of operation (Chandigarh)."),
        ("area", "VARCHAR(60)", "Sector / locality inside the city (approximate, illustrative)."),
        ("latitude", "DECIMAL(9,4)", "Approximate latitude in decimal degrees (for Tableau maps)."),
        ("longitude", "DECIMAL(9,4)", "Approximate longitude in decimal degrees."),
        ("installation_date", "DATE", "Date the station was commissioned (before the study period)."),
        ("total_connectors", "INT", "Number of connector rows belonging to this station (validated against connectors.csv)."),
        ("station_type", "VARCHAR(40)", "Site category: Commercial Market, Shopping Mall, IT Park / Office, Hospital Campus, Transit Hub, Public Parking, Highway Corridor, Residential Complex, Government Office Complex."),
        ("monthly_rent_inr", "DECIMAL(12,2)", "Monthly site rent in INR. Spread across calendar days in daily_station_operating_costs.rent_cost_inr."),
        ("maintenance_cost_monthly_inr", "DECIMAL(12,2)", "Routine monthly maintenance contract in INR. Event repair costs are separate (station_downtime.maintenance_cost_inr)."),
        ("operating_hours_per_day", "INT", "Hours open per day. 24 = always open. Otherwise the station opens at 06:00 and closes at 06:00 + hours."),
    ]),
    "connectors.csv": ("Connector master data (50 rows). One row per physical charging connector.", None, [
        ("connector_id", "VARCHAR(10) PK", "Unique connector code (CN001..CN050)."),
        ("station_id", "VARCHAR(10) FK", "Parent station (stations.station_id)."),
        ("connector_type", "VARCHAR(20)", "AC Type 2, DC CCS2 or DC CHAdeMO."),
        ("rated_power_kw", "DECIMAL(5,1)", "Rated charger power in kW (7.4, 22, 30, 50, 60 or 120)."),
        ("installation_date", "DATE", "Commissioning date. Two connectors were added during the study period."),
        ("connector_status", "VARCHAR(20)", "Status at the data cut-off 2026-09-30: Active or Under Maintenance."),
        ("electricity_tariff_per_kwh_inr", "DECIMAL(8,2)", "Electricity (cost) tariff in force on 2026-09-30, INR per kWh. History is in tariff_history.csv."),
    ]),
    "charging_sessions.csv": ("Charging sessions (fact table). One row per plug-in attempt.", "Completed", [
        ("session_id", "VARCHAR(10) PK", "Unique session code (S000001...), ordered by start time."),
        ("connector_id", "VARCHAR(10) FK", "Connector used (connectors.connector_id)."),
        ("station_id", "VARCHAR(10) FK", "Station of that connector (stations.station_id); always equals the connector's station."),
        ("vehicle_id", "VARCHAR(12)", "Anonymised synthetic vehicle identifier. Vehicles repeat across sessions."),
        ("session_start", "DATETIME", "Plug-in / start time, local time, second precision (seconds are 00)."),
        ("session_end", "DATETIME", "Session end time. May be after midnight at 24-hour stations (overnight sessions)."),
        ("energy_delivered_kwh", "DECIMAL(8,2)", "Energy delivered to the vehicle in kWh. 0.00 for cancelled and start-failed sessions; partial for mid-session failures."),
        ("charging_duration_minutes", "INT", "Minutes actually charging. charging + idle = session_end - session_start."),
        ("idle_duration_minutes", "INT", "Minutes plugged in but not charging (waiting, finished, or after a failure)."),
        ("electricity_tariff_per_kwh_inr", "DECIMAL(8,2)", "Electricity cost tariff applicable on the session start date (matches tariff_history)."),
        ("charging_revenue_inr", "DECIMAL(10,2)", "Billed amount = ROUND_HALF_UP(energy x customer_price_per_kwh_inr, 2) for Completed sessions; 0.00 for Failed / Cancelled."),
        ("session_status", "VARCHAR(12)", "Completed, Failed or Cancelled."),
        ("payment_status", "VARCHAR(16)", "Paid, Payment Failed (billed, not collected), Pending (last 2 days only) or Not Charged (failed/cancelled)."),
        ("day_type", "VARCHAR(10)", "Weekday, Weekend or Holiday (holiday dates are illustrative)."),
        ("weather_condition", "VARCHAR(10)", "City-wide daily weather: Clear, Cloudy, Hot or Rain."),
    ]),
    "station_downtime.csv": ("Connector downtime events (571 rows).", None, [
        ("downtime_id", "VARCHAR(10) PK", "Unique downtime event code (DT00001...)."),
        ("connector_id", "VARCHAR(10) FK", "Connector that was unavailable."),
        ("station_id", "VARCHAR(10) FK", "Station of that connector."),
        ("downtime_start", "DATETIME", "Start of unavailability."),
        ("downtime_end", "DATETIME", "End of unavailability. Truncated at 2026-10-01 00:00:00 for connectors still down at the cut-off."),
        ("downtime_duration_minutes", "INT", "downtime_end - downtime_start in minutes (validated)."),
        ("downtime_reason", "VARCHAR(40)", "Planned Maintenance, Equipment Fault, Cable/Connector Damage, Power Outage, Software/Communication Error, Firmware Update or Vandalism/Physical Damage. A power outage creates one row per connector of the station."),
        ("maintenance_type", "VARCHAR(25)", "Preventive, Corrective, Remote Resolution, Software Update or None (Grid Event)."),
        ("maintenance_cost_inr", "DECIMAL(10,2)", "Cost of the event in INR (parts + labour). Included in the daily maintenance cost on the event's start date."),
    ]),
    "daily_station_operating_costs.csv": ("Daily operating cost per station (1,830 rows = 10 stations x 183 days).", None, [
        ("record_id", "VARCHAR(10) PK", "Unique record code (OC000001...)."),
        ("station_id", "VARCHAR(10) FK", "Station. (station_id, operating_date) is also unique."),
        ("operating_date", "DATE", "Calendar date (2026-04-01 .. 2026-09-30)."),
        ("electricity_cost_inr", "DECIMAL(12,2)", "Sum over sessions starting that day of round(energy x session electricity tariff, 2). Includes energy of failed sessions."),
        ("staff_cost_inr", "DECIMAL(12,2)", "Fixed daily attendant / shift cost for the station."),
        ("rent_cost_inr", "DECIMAL(12,2)", "Monthly rent / days in month; the last day of each month absorbs rounding so each month sums exactly to the monthly rent."),
        ("maintenance_cost_inr", "DECIMAL(12,2)", "Routine monthly contract spread over days + cost of downtime events that started that day."),
        ("other_operating_cost_inr", "DECIMAL(12,2)", "Insurance, internet, security, software, cleaning (fixed daily level x random 0.85-1.20)."),
    ]),
    "tariff_history.csv": ("Tariff history (149 rows). Electricity cost tariff and customer price per connector and period.", None, [
        ("tariff_id", "VARCHAR(10) PK", "Unique tariff row code (TF0001...)."),
        ("connector_id", "VARCHAR(10) FK", "Connector the tariff applies to."),
        ("effective_from", "DATE", "First day the tariff applies (inclusive)."),
        ("effective_to", "DATE", "Last day the tariff applies (inclusive). Periods never overlap and have no gaps."),
        ("electricity_tariff_per_kwh_inr", "DECIMAL(8,2)", "What the station pays for electricity, INR per kWh (blended landed cost)."),
        ("customer_price_per_kwh_inr", "DECIMAL(8,2)", "What the customer pays, INR per kWh. Join to a session by connector_id and DATE(session_start) BETWEEN effective_from AND effective_to."),
    ]),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="DATA_DICTIONARY.md")
    a = ap.parse_args()
    out = ["# Data Dictionary", "",
           "Synthetic dataset for *EV Charging Station Analytics & Profitability Optimization* (Chandigarh, India). "
           "Units: INR, kWh, kW, minutes. Timestamps `YYYY-MM-DD HH:MM:SS` (local time), dates `YYYY-MM-DD`. "
           "Examples below are read from the actual CSV files.", ""]
    for fname, (desc, prefer, cols) in SPEC.items():
        with open(os.path.join(a.data, fname), newline="", encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        header = list(rows[0].keys())
        assert header == [c[0] for c in cols], f"{fname}: dictionary columns differ from CSV header"
        ex = next((r for r in rows if prefer and r.get("session_status") == prefer), rows[0])
        out += [f"## {fname}", "", f"{desc} Rows: **{len(rows):,}**.", "",
                "| Column | Type (MySQL) | Meaning | Example |", "|---|---|---|---|"]
        for col, typ, meaning in cols:
            out.append(f"| `{col}` | {typ} | {meaning} | `{ex[col]}` |")
        out.append("")
    with open(a.out, "w", encoding="utf-8") as f:
        f.write("\n".join(out))
    print("wrote", a.out)


if __name__ == "__main__":
    main()
