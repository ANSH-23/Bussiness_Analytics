#!/usr/bin/env python3
"""
generate_ev_dataset.py
======================
Synthetic dataset for the MCA project
"EV Charging Station Analytics & Profitability Optimization".

*** ALL DATA IS SYNTHETIC. It does not represent any real EV charging company,
    station, customer or vehicle. Place names are used only as plausible,
    approximate locations in Chandigarh, India. ***

Usage
-----
    python generate_ev_dataset.py                 # writes ./data/*.csv  (seed 42)
    python generate_ev_dataset.py --out data --seed 42

Requires only the Python standard library (tested on Python 3.9 - 3.13).
Same seed  ->  byte-identical CSV files.

Network modelled
----------------
* 10 stations, 50 connectors (Chandigarh), period 2026-04-01 .. 2026-09-30.
* Units: INR, kWh, kW, minutes.  Timestamps are local (IST), 'YYYY-MM-DD HH:MM:SS'.

Key modelling assumptions (also in README / data dictionary)
------------------------------------------------------------
A1  Stations with < 24 operating hours open at 06:00 (open = 06:00, close =
    06:00 + operating_hours_per_day). Sessions at those stations start and end
    inside that window. 24-hour stations may have overnight sessions that
    cross midnight (mainly residential AC charging).
A2  Demand per connector-day = Poisson(rate). Rate = base x station popularity
    x connector attractiveness x day-type factor (weekday / weekend / holiday,
    per station profile) x weather factor x gentle monthly growth.
    Start hour is drawn from a station-profile hourly curve (mall, highway,
    office, residential, hospital, parking). Sessions on one connector never
    overlap; if a connector is busy the next customer waits (queue); long
    waits raise the cancellation probability.
A3  Energy = average accepted power x charging minutes / 60.  Average power =
    min(connector rated kW, vehicle limit) x efficiency/taper factor, so
    higher-kW connectors charge faster but energy still depends on vehicle,
    battery state and session length.  Vehicle attributes are internal only;
    the CSV exposes just an anonymous vehicle_id.
A4  Session status: Completed / Failed / Cancelled.
      Completed  -> billed: revenue = energy x customer price (tariff_history
                    row valid on session start date), ROUND_HALF_UP to 2 dp.
      Failed     -> revenue 0, payment 'Not Charged' (full goodwill waiver).
                    Partial energy may have been delivered; the station still
                    pays electricity for it (electricity cost uses ALL energy).
      Cancelled  -> 0 energy, 0 revenue, no cancellation fee.
    Completed payment_status: Paid / Payment Failed (billed but not collected)
    / Pending (only for the last 2 days of the data).
    charging_duration + idle_duration = session_end - session_start (minutes).
A5  Downtime rows are per connector and never overlap (10-minute buffer).
    Reasons: Planned Maintenance, Equipment Fault, Cable/Connector Damage,
    Power Outage (station-wide, one row per affected connector), Software/
    Communication Error, Firmware Update, Vandalism/Physical Damage.
    No session starts inside a downtime. A session running when an UNPLANNED
    downtime begins ends as 'Failed' exactly at the downtime start.
    Three connectors are 'Under Maintenance' at the data cut-off: their last
    downtime is truncated at 2026-10-01 00:00:00 (period end).
A6  Tariffs: 3 periods per connector (2026-01-01..05-31, 06-01..08-31,
    09-01..12-31; periods start at the connector installation date if later).
    electricity_tariff = blended landed cost (energy + demand + taxes) so no
    separate demand charge is modelled. connectors.electricity_tariff_per_kwh_inr
    is the tariff in force on 2026-09-30.
A7  Daily costs per station:
      electricity_cost = sum over sessions STARTING that day of
                         round(energy x session electricity tariff, 2)
      rent_cost        = monthly rent spread over calendar days (cent-exact;
                         the last day of the month absorbs the rounding)
      maintenance_cost = routine monthly contract spread like rent
                         + corrective/preventive event cost of downtime events
                         that START on that day
      staff_cost       = fixed daily attendant/shift cost by station type
      other_operating  = fixed daily (insurance, internet, security, software)
                         x random 0.85..1.20
    No grid-loss factor, payment-gateway fee, GST or depreciation is modelled.
A8  Public-holiday dates are illustrative (approximate) and used only to
    create the 'Holiday' day_type.
"""
import argparse
import csv
import math
import os
import random
from collections import defaultdict
from datetime import date, datetime, time, timedelta
from decimal import Decimal, ROUND_HALF_UP
from itertools import accumulate

# --------------------------------------------------------------------------
# Global configuration
# --------------------------------------------------------------------------
DEFAULT_SEED = 42
PERIOD_START = date(2026, 4, 1)
PERIOD_END = date(2026, 9, 30)                 # inclusive
PERIOD_START_DT = datetime(2026, 4, 1, 0, 0, 0)
PERIOD_END_DT = datetime(2026, 10, 1, 0, 0, 0)  # exclusive upper bound
OPEN_HOUR = 6                                   # opening hour for stations < 24 h
PENDING_FROM = date(2026, 9, 29)

BASE_RATE = 2.20           # base sessions per connector-day (calibration knob)
GROWTH_PER_MONTH = 0.03

TARIFF_BOUNDS = [
    (date(2026, 1, 1), date(2026, 5, 31)),
    (date(2026, 6, 1), date(2026, 8, 31)),
    (date(2026, 9, 1), date(2026, 12, 31)),
]
ELEC_STEP = [Decimal("0.00"), Decimal("0.30"), Decimal("0.50")]   # cumulative vs period 1
PRICE_STEP = [Decimal("0.00"), Decimal("1.00"), Decimal("2.00")]  # cumulative vs period 1

HOLIDAYS = {
    date(2026, 4, 3): "Good Friday", date(2026, 4, 14): "Ambedkar Jayanti",
    date(2026, 5, 1): "Buddha Purnima", date(2026, 5, 27): "Eid al-Adha",
    date(2026, 8, 15): "Independence Day", date(2026, 9, 4): "Janmashtami",
}

CENT = Decimal("0.01")


def D(x):
    return Decimal(str(x))


def q2(x):
    return D(x).quantize(CENT, rounding=ROUND_HALF_UP)


def sub_rng(seed, name):
    return random.Random(f"{seed}-{name}")


def poisson(rng, lam):
    if lam <= 0:
        return 0
    limit, k, p = math.exp(-lam), 0, 1.0
    while True:
        k += 1
        p *= rng.random()
        if p <= limit:
            return k - 1


# --------------------------------------------------------------------------
# Connector catalogue
# --------------------------------------------------------------------------
AC74 = ("AC Type 2", 7.4)
AC22 = ("AC Type 2", 22.0)
D30 = ("DC CCS2", 30.0)
D60 = ("DC CCS2", 60.0)
D120 = ("DC CCS2", 120.0)
CHD = ("DC CHAdeMO", 50.0)

BASE_PRICE = {AC74: "16.00", AC22: "18.00", D30: "20.00", D60: "22.00", D120: "25.00", CHD: "21.00"}
ATTRACT = {AC74: 0.75, AC22: 0.85, D30: 0.90, D60: 1.15, D120: 1.35, CHD: 0.45}

STATIONS = [
    dict(id="ST01", name="EV Hub Sector 17 Plaza", area="Sector 17", lat=30.7398, lon=76.7827,
         installed=date(2024, 3, 15), stype="Commercial Market", profile="mall", hours=16,
         rent=48000, maint=7200, staff=650, other=210, pop=1.45, elec=7.85, price_adj=1.0,
         connectors=[D60, D30, D30, AC22, AC74, AC74]),
    dict(id="ST02", name="EV Hub Sector 35 Residency", area="Sector 35", lat=30.7226, lon=76.7589,
         installed=date(2024, 9, 1), stype="Residential Complex", profile="residential", hours=24,
         rent=16000, maint=4400, staff=220, other=160, pop=0.75, elec=7.40, price_adj=-1.0,
         connectors=[AC74, AC74, AC74, AC22, D30]),
    dict(id="ST03", name="EV Hub Industrial Area Mall", area="Industrial Area Phase 1", lat=30.7059, lon=76.8013,
         installed=date(2023, 11, 20), stype="Shopping Mall", profile="mall", hours=16,
         rent=62000, maint=9600, staff=800, other=265, pop=1.70, elec=8.10, price_adj=1.0,
         connectors=[D120, D60, D60, D30, AC22, AC74]),
    dict(id="ST04", name="EV Hub Technology Park", area="Rajiv Gandhi Technology Park", lat=30.7279, lon=76.8453,
         installed=date(2024, 6, 10), stype="IT Park / Office", profile="office", hours=16,
         rent=26000, maint=5600, staff=480, other=190, pop=1.20, elec=7.60, price_adj=0.0,
         connectors=[AC74, AC74, AC74, AC22, D60]),
    dict(id="ST05", name="EV Hub Sector 12 Medical Campus", area="Sector 12", lat=30.7646, lon=76.7762,
         installed=date(2025, 1, 18), stype="Hospital Campus", profile="hospital", hours=24,
         rent=24000, maint=5200, staff=550, other=200, pop=1.10, elec=7.50, price_adj=0.0,
         connectors=[AC22, AC74, D30, D60]),
    dict(id="ST06", name="EV Hub ISBT Sector 43", area="Sector 43", lat=30.7203, lon=76.7467,
         installed=date(2024, 12, 5), stype="Transit Hub", profile="highway", hours=24,
         rent=50000, maint=10400, staff=950, other=300, pop=1.80, elec=8.00, price_adj=2.0,
         connectors=[D120, D120, D60, D60, CHD, AC22]),
    dict(id="ST07", name="EV Hub Manimajra Housing", area="Manimajra", lat=30.7195, lon=76.8366,
         installed=date(2025, 3, 22), stype="Residential Complex", profile="residential", hours=18,
         rent=14000, maint=3600, staff=200, other=150, pop=0.65, elec=7.30, price_adj=-1.5,
         connectors=[AC74, AC74, AC74, D30]),
    dict(id="ST08", name="EV Hub Sector 22 Parking", area="Sector 22", lat=30.7330, lon=76.7737,
         installed=date(2025, 5, 30), stype="Public Parking", profile="parking", hours=16,
         rent=28000, maint=4800, staff=420, other=185, pop=0.95, elec=7.70, price_adj=0.5,
         connectors=[AC22, AC22, AC74, AC74, D30]),
    dict(id="ST09", name="EV Hub Highway Corridor Sector 28", area="Sector 28", lat=30.7412, lon=76.8195,
         installed=date(2025, 8, 14), stype="Highway Corridor", profile="highway", hours=24,
         rent=40000, maint=8800, staff=850, other=270, pop=1.50, elec=8.00, price_adj=2.0,
         connectors=[D120, D120, D60, D60, CHD]),
    dict(id="ST10", name="EV Hub Sector 34 Office Complex", area="Sector 34", lat=30.7227, lon=76.7706,
         installed=date(2025, 10, 9), stype="Government Office Complex", profile="office", hours=12,
         rent=20000, maint=4000, staff=400, other=170, pop=0.80, elec=7.50, price_adj=0.0,
         connectors=[AC74, AC74, AC22, D30]),
]
STATION_BY_ID = {s["id"]: s for s in STATIONS}

# (station_id, 0-based connector index) overrides
NEW_CONNECTORS = {("ST09", 2): date(2026, 5, 12), ("ST03", 5): date(2026, 7, 3)}
UNDER_MAINT = {("ST07", 3): datetime(2026, 9, 20, 10, 30),
               ("ST08", 1): datetime(2026, 9, 25, 15, 10),
               ("ST10", 3): datetime(2026, 9, 27, 9, 45)}
PROBLEM_CONNECTORS = {("ST03", 3): 2.2, ("ST06", 2): 2.0, ("ST09", 4): 2.4}  # reliability multipliers

# --------------------------------------------------------------------------
# Demand model
# --------------------------------------------------------------------------


def make_profile(peaks, base):
    out = []
    for h in range(24):
        v = base
        for mu, sig, amp in peaks:
            d = min(abs(h - mu), 24 - abs(h - mu))
            v += amp * math.exp(-0.5 * (d / sig) ** 2)
        out.append(v)
    return out


HOURLY = {
    "mall": make_profile([(13, 2.0, 0.7), (19.5, 1.8, 1.0)], 0.08),
    "highway": make_profile([(9, 2.5, 0.7), (14, 3.0, 0.5), (19, 2.5, 0.9)], 0.18),
    "office": make_profile([(9.5, 1.4, 1.0), (13, 2.0, 0.35), (17.5, 1.3, 0.5)], 0.03),
    "residential": make_profile([(7, 1.5, 0.35), (21, 2.2, 1.0), (23, 1.5, 0.5)], 0.06),
    "hospital": make_profile([(10, 3.0, 0.7), (16, 3.0, 0.6)], 0.15),
    "parking": make_profile([(11, 2.5, 0.6), (17, 2.5, 0.8)], 0.10),
}
DAYTYPE_MULT = {
    "mall": {"Weekday": 1.0, "Weekend": 1.35, "Holiday": 1.40},
    "highway": {"Weekday": 1.0, "Weekend": 1.25, "Holiday": 1.30},
    "office": {"Weekday": 1.0, "Weekend": 0.45, "Holiday": 0.40},
    "residential": {"Weekday": 1.0, "Weekend": 1.15, "Holiday": 1.15},
    "hospital": {"Weekday": 1.0, "Weekend": 0.90, "Holiday": 0.85},
    "parking": {"Weekday": 1.0, "Weekend": 1.10, "Holiday": 1.10},
}
DOW_FACTOR = {0: 0.96, 1: 1.0, 2: 1.0, 3: 1.02, 4: 1.08, 5: 1.0, 6: 1.0}  # weekdays only
WEATHER_DEMAND = {"Clear": 1.0, "Cloudy": 1.0, "Hot": 0.96, "Rain": 0.82}
WEATHER_FAIL = {"Clear": 1.0, "Cloudy": 1.0, "Hot": 1.25, "Rain": 1.8}
WEATHER_BY_MONTH = {
    4: [("Clear", 60), ("Cloudy", 20), ("Hot", 15), ("Rain", 5)],
    5: [("Clear", 45), ("Hot", 35), ("Cloudy", 15), ("Rain", 5)],
    6: [("Hot", 40), ("Clear", 25), ("Cloudy", 15), ("Rain", 20)],
    7: [("Rain", 55), ("Cloudy", 30), ("Clear", 10), ("Hot", 5)],
    8: [("Rain", 50), ("Cloudy", 32), ("Clear", 14), ("Hot", 4)],
    9: [("Rain", 25), ("Cloudy", 30), ("Clear", 40), ("Hot", 5)],
}
FAIL_BASE = {"AC": 0.015, "DC": 0.035, "CHD": 0.055}
CANCEL_BASE = 0.022
CANCEL_AFTER_WAIT = 0.14


def day_type(d):
    if d in HOLIDAYS:
        return "Holiday"
    return "Weekend" if d.weekday() >= 5 else "Weekday"


def all_days():
    d = PERIOD_START
    while d <= PERIOD_END:
        yield d
        d += timedelta(days=1)


# --------------------------------------------------------------------------
# Master data
# --------------------------------------------------------------------------


def build_stations_connectors_tariffs(seed):
    rng = sub_rng(seed, "structure")
    connectors, tariffs = [], []
    n = 0
    for st in STATIONS:
        st["outage_prone"] = round(rng.uniform(0.8, 1.6), 2)
        for idx, (ctype, kw) in enumerate(st["connectors"]):
            n += 1
            jitter = rng.randint(0, 45)
            rel_draw = round(rng.uniform(0.7, 1.4), 2)
            key = (st["id"], idx)
            installed = NEW_CONNECTORS.get(key, st["installed"] + timedelta(days=jitter))
            kind = "CHD" if ctype == "DC CHAdeMO" else ("DC" if ctype.startswith("DC") else "AC")
            connectors.append(dict(
                connector_id=f"CN{n:03d}", station_id=st["id"], connector_type=ctype, rated_power_kw=kw,
                installed=installed, status="Under Maintenance" if key in UNDER_MAINT else "Active",
                kind=kind, key=(ctype, kw), rel=PROBLEM_CONNECTORS.get(key, rel_draw), idx=idx))
    tn = 0
    for c in connectors:
        st = STATION_BY_ID[c["station_id"]]
        elec1 = D(st["elec"]) + (D("0.30") if c["kind"] != "AC" else D("0.00")) + D(round(rng.uniform(-0.15, 0.15), 2))
        elec1 = q2(elec1)
        price1 = q2(D(BASE_PRICE[c["key"]]) + D(st["price_adj"]))
        c["tariffs"] = []
        for pi, (a, b) in enumerate(TARIFF_BOUNDS):
            start = max(a, c["installed"])
            if start > b:
                continue
            tn += 1
            t = dict(tariff_id=f"TF{tn:04d}", connector_id=c["connector_id"], effective_from=start,
                     effective_to=b, elec=q2(elec1 + ELEC_STEP[pi]), price=q2(price1 + PRICE_STEP[pi]))
            c["tariffs"].append(t)
            tariffs.append(t)
        c["current_elec"] = tariff_at(c, PERIOD_END)["elec"]
    return connectors, tariffs


def tariff_at(conn, d):
    for t in conn["tariffs"]:
        if t["effective_from"] <= d <= t["effective_to"]:
            return t
    raise ValueError(f"no tariff for {conn['connector_id']} on {d}")


# --------------------------------------------------------------------------
# Downtime
# --------------------------------------------------------------------------
PLANNED_REASONS = {"Planned Maintenance", "Firmware Update"}


def rand_ts(rng, a, b):
    mins = int((b - a).total_seconds() // 60)
    return a + timedelta(minutes=rng.randrange(max(1, mins)))


def build_downtime(seed, connectors):
    rng = sub_rng(seed, "downtime")
    events = defaultdict(list)          # connector_id -> [(start, end, reason, mtype, cost)]

    def add(c, start, end, reason, mtype, cost):
        avail = max(PERIOD_START_DT, datetime.combine(c["installed"], time(0)))
        if start < avail or end > PERIOD_END_DT or end <= start:
            return False
        for s2, e2, *_ in events[c["connector_id"]]:
            if start < e2 + timedelta(minutes=10) and end > s2 - timedelta(minutes=10):
                return False
        events[c["connector_id"]].append((start, end, reason, mtype, q2(cost)))
        return True

    def cost_draw(median, cap):
        return min(cap, int(rng.lognormvariate(math.log(median), 0.6)) // 50 * 50)

    # reserve the truncated 'Under Maintenance' events first
    for c in connectors:
        key = (c["station_id"], c["idx"])
        if key in UNDER_MAINT:
            add(c, UNDER_MAINT[key], PERIOD_END_DT, "Equipment Fault", "Corrective", 8500 + 500 * (c["idx"] % 3))

    for c in connectors:
        kind, rel = c["kind"], c["rel"]
        # preventive maintenance: roughly one per quarter
        for a, b in [(datetime(2026, 4, 1), datetime(2026, 6, 30)), (datetime(2026, 7, 1), datetime(2026, 9, 30))]:
            if rng.random() < 0.85:
                day = a + timedelta(days=rng.randrange((b - a).days))
                start = day.replace(hour=rng.randint(9, 13), minute=rng.randrange(60))
                dur = rng.randint(90, 180) if kind == "AC" else rng.randint(120, 300)
                add(c, start, start + timedelta(minutes=dur), "Planned Maintenance", "Preventive",
                    rng.randrange(600, 1500, 50) if kind == "AC" else rng.randrange(1500, 4000, 50))
        # equipment faults / cable damage
        lam = {"AC": 0.8, "DC": 1.8, "CHD": 2.5}[kind] * rel
        for _ in range(poisson(rng, lam)):
            start = rand_ts(rng, PERIOD_START_DT, PERIOD_END_DT)
            dur = int(min(4320, max(60, rng.lognormvariate(math.log(420), 0.8))))
            if rng.random() < 0.7:
                reason, cost = "Equipment Fault", cost_draw(2500 if kind == "AC" else 9000, 40000)
            else:
                reason, cost = "Cable/Connector Damage", cost_draw(1500 if kind == "AC" else 4500, 20000)
            add(c, start, start + timedelta(minutes=dur), reason, "Corrective", cost)
        # software / communication errors (mostly remote)
        for _ in range(poisson(rng, 1.0)):
            start = rand_ts(rng, PERIOD_START_DT, PERIOD_END_DT)
            dur = rng.randint(10, 150)
            cost = rng.randrange(150, 500, 50) if rng.random() < 0.3 else 0
            add(c, start, start + timedelta(minutes=dur), "Software/Communication Error", "Remote Resolution", cost)
        # firmware update at night
        if rng.random() < 0.7:
            day = PERIOD_START_DT + timedelta(days=rng.randrange(183))
            start = day.replace(hour=rng.randint(1, 3), minute=rng.randrange(60))
            add(c, start, start + timedelta(minutes=rng.randint(30, 90)), "Firmware Update", "Software Update", 0)
        # rare vandalism
        if rng.random() < 0.03:
            start = rand_ts(rng, PERIOD_START_DT, PERIOD_END_DT - timedelta(days=4))
            add(c, start, start + timedelta(minutes=rng.randint(1440, 4320)), "Vandalism/Physical Damage",
                "Corrective", rng.randrange(4000, 20000, 100))

    # station-wide power outages -> one row per connector
    month_w = {4: 0.8, 5: 1.3, 6: 1.6, 7: 1.4, 8: 1.2, 9: 0.7}
    by_station = defaultdict(list)
    for c in connectors:
        by_station[c["station_id"]].append(c)
    for st in STATIONS:
        for _ in range(poisson(rng, 5.0 * st["outage_prone"])):
            while True:                       # month-weighted start time
                start = rand_ts(rng, PERIOD_START_DT, PERIOD_END_DT)
                if rng.random() < month_w[start.month] / 1.6:
                    break
            dur = int(min(480, max(15, rng.lognormvariate(math.log(60), 0.7))))
            for c in by_station[st["id"]]:
                add(c, start, start + timedelta(minutes=dur), "Power Outage", "None (Grid Event)", 0)

    rows = []
    for cid, evs in events.items():
        for s, e, reason, mtype, cost in evs:
            rows.append(dict(connector_id=cid, start=s, end=e, reason=reason, mtype=mtype, cost=cost))
    cmap = {c["connector_id"]: c for c in connectors}
    rows.sort(key=lambda r: (r["start"], r["connector_id"]))
    for i, r in enumerate(rows, 1):
        r["downtime_id"] = f"DT{i:05d}"
        r["station_id"] = cmap[r["connector_id"]]["station_id"]
        r["minutes"] = int((r["end"] - r["start"]).total_seconds() // 60)
    return rows


# --------------------------------------------------------------------------
# Vehicles
# --------------------------------------------------------------------------
VEH_SPECS = [
    ("2W", 600, ("u", 2.4, 4.2), [3.3], [0.0]),
    ("3W", 300, ("u", 7.5, 11.5), [3.3], [0.0]),
    ("Hatchback", 1100, ("c", [19.2, 24.0, 26.0, 29.2]), [3.3, 7.2], [25.0, 50.0]),
    ("SUV", 1500, ("c", [30.2, 39.4, 40.5, 45.0, 50.3]), [7.2], [50.0, 60.0, 80.0]),
    ("Premium", 500, ("c", [60.0, 64.0, 72.0, 75.0, 79.0]), [11.0], [100.0, 120.0, 150.0]),
]


def build_vehicles(seed):
    rng = sub_rng(seed, "vehicles")
    total = sum(s[1] for s in VEH_SPECS)
    ids = rng.sample(range(100000, 1000000), total)
    pools, k = {}, 0
    chademo = []
    for cls, count, batt, acs, dcs in VEH_SPECS:
        vs = []
        for _ in range(count):
            b = rng.uniform(batt[1], batt[2]) if batt[0] == "u" else rng.choice(batt[1])
            v = dict(id=f"VEH-{ids[k]}", cls=cls, battery=round(b, 1), ac_max=rng.choice(acs),
                     dc_max=rng.choice(dcs), chademo=cls in ("Hatchback", "SUV") and rng.random() < 0.07)
            k += 1
            vs.append(v)
            if v["chademo"]:
                chademo.append(v)
        w = [rng.lognormvariate(0, 1.0) for _ in vs]      # repeat-customer behaviour
        pools[cls] = (vs, list(accumulate(w)))
    w = [rng.lognormvariate(0, 1.0) for _ in chademo]
    pools["_chademo"] = (chademo, list(accumulate(w)))
    return pools


def class_weights(ctype, kw):
    if ctype == "AC Type 2":
        if kw <= 7.4:
            return {"2W": .22, "3W": .12, "Hatchback": .26, "SUV": .30, "Premium": .10}
        return {"2W": .08, "3W": .06, "Hatchback": .26, "SUV": .38, "Premium": .22}
    if kw >= 100:
        return {"Hatchback": .08, "SUV": .42, "Premium": .50}
    return {"Hatchback": .25, "SUV": .50, "Premium": .25}


def pick_vehicle(rng, pools, conn):
    if conn["connector_type"] == "DC CHAdeMO":
        pool, cum = pools["_chademo"]
    else:
        cw = class_weights(conn["connector_type"], conn["rated_power_kw"])
        cls = rng.choices(list(cw), weights=list(cw.values()))[0]
        pool, cum = pools[cls]
    return rng.choices(pool, cum_weights=cum, k=1)[0]


# --------------------------------------------------------------------------
# Sessions
# --------------------------------------------------------------------------
def window(st, d):
    if st["hours"] >= 24:
        return None
    o = datetime.combine(d, time(OPEN_HOUR))
    return o, o + timedelta(hours=st["hours"])


def build_one_session(rng, pools, conn, st, start, wait_min, weather, dts, veh_busy):
    veh = pick_vehicle(rng, pools, conn)
    kind, kw = conn["kind"], conn["rated_power_kw"]
    u = rng.random()
    pf = FAIL_BASE[kind] * conn["rel"] * WEATHER_FAIL[weather]
    pc = CANCEL_AFTER_WAIT if wait_min > 10 else CANCEL_BASE
    status = "Failed" if u < pf else ("Cancelled" if u < pf + pc else "Completed")

    # ---- charging physics
    if kind == "AC":
        p_avg = min(kw, veh["ac_max"]) * rng.uniform(0.88, 0.97)
    else:
        limit = min(kw, veh["dc_max"], 50.0 if kind == "CHD" else 1e9)
        p_avg = limit * rng.uniform(0.55, 0.82)
    soc = min(0.85, max(0.05, rng.betavariate(2.0, 3.0)))
    target = rng.uniform(0.80, 0.95) if kind != "AC" else rng.uniform(0.85, 1.0)
    frac = max(0.12, target - soc)
    if rng.random() < 0.10:
        frac = max(0.08, frac * rng.uniform(0.4, 0.7))
    planned = max(4, int(round(veh["battery"] * frac / p_avg * 60)))
    planned = min(planned, 540 if kind == "AC" else 150)

    if kind != "AC":
        idle_full = min(25, int(rng.expovariate(1 / 4.5)))
    elif st["profile"] == "residential":
        idle_full = min(300, int(rng.expovariate(1 / 70)))
    else:
        idle_full = min(90, int(rng.expovariate(1 / 22)))

    if status == "Completed":
        charge, idle = planned, idle_full
    elif status == "Cancelled":
        charge, idle = 0, rng.randint(1, 8)
    else:                                              # Failed
        if rng.random() < 0.5:
            charge, idle = 0, rng.randint(2, 12)
        else:
            charge, idle = max(2, int(planned * rng.uniform(0.1, 0.8))), rng.randint(1, 10)

    # ---- operating-window fit
    win = window(st, start.date())
    if win:
        avail = int((win[1] - start).total_seconds() // 60)
        if avail < 6:
            return None
        if charge + idle > avail:
            idle = max(0, avail - charge)
            if charge > avail:
                charge, idle = avail, 0
    if status == "Completed" and charge < 3:
        return None
    end = start + timedelta(minutes=charge + idle)

    # ---- downtime interaction
    for ds, de, reason in dts:
        if ds < end and de > start:
            if ds <= start or reason in PLANNED_REASONS:
                return None
            elapsed = int((ds - start).total_seconds() // 60)
            if elapsed < 2:
                return None
            status = "Failed"
            charge = min(charge if charge else max(2, int(planned * 0.5)), elapsed)
            idle = elapsed - charge
            end = ds
            break

    # ---- vehicle cannot be in two places at once
    for s2, e2 in veh_busy.get(veh["id"], ()):
        if start < e2 + timedelta(minutes=30) and end > s2 - timedelta(minutes=30):
            return None

    energy = q2(p_avg * charge / 60) if charge > 0 else Decimal("0.00")
    d0 = start.date()
    tar = tariff_at(conn, d0)
    if status == "Completed":
        revenue = q2(energy * tar["price"])
        r = rng.random()
        payment = "Pending" if (d0 >= PENDING_FROM and r < 0.15) else ("Payment Failed" if rng.random() < 0.02 else "Paid")
    else:
        revenue, payment = Decimal("0.00"), "Not Charged"
    veh_busy.setdefault(veh["id"], []).append((start, end))
    return dict(connector_id=conn["connector_id"], station_id=st["id"], vehicle_id=veh["id"], start=start,
                end=end, energy=energy, charge=charge, idle=idle, elec=tar["elec"], revenue=revenue,
                status=status, payment=payment, day_type=day_type(d0), weather=weather)


def build_sessions(seed, connectors, downtime):
    rng = sub_rng(seed, "sessions")
    wrng = sub_rng(seed, "weather")
    weather = {}
    for d in all_days():
        opts = WEATHER_BY_MONTH[d.month]
        weather[d] = wrng.choices([o[0] for o in opts], weights=[o[1] for o in opts])[0]

    pools = build_vehicles(seed)
    dt_by_conn = defaultdict(list)
    for r in downtime:
        dt_by_conn[r["connector_id"]].append((r["start"], r["end"], r["reason"]))
    for v in dt_by_conn.values():
        v.sort()

    hour_w = {}
    for st in STATIONS:
        w = []
        for h in range(24):
            inside = st["hours"] >= 24 or OPEN_HOUR <= h < OPEN_HOUR + st["hours"]
            w.append(HOURLY[st["profile"]][h] if inside else 0.0)
        hour_w[st["id"]] = w

    sessions, veh_busy = [], {}
    for c in connectors:
        st = STATION_BY_ID[c["station_id"]]
        last_end = datetime(2000, 1, 1)
        first_day = max(PERIOD_START, c["installed"])
        d = first_day
        while d <= PERIOD_END:
            dt = day_type(d)
            dmult = DAYTYPE_MULT[st["profile"]][dt] * (DOW_FACTOR[d.weekday()] if dt == "Weekday" else 1.0)
            growth = 1 + GROWTH_PER_MONTH * ((d.year - 2026) * 12 + d.month - 4)
            lam = (BASE_RATE * st["pop"] * ATTRACT[c["key"]] * dmult * WEATHER_DEMAND[weather[d]] * growth)
            n = poisson(rng, lam)
            hours = rng.choices(range(24), weights=hour_w[st["id"]], k=n)
            offs = sorted(h * 60 + rng.randrange(60) for h in hours)
            for off in offs:
                req = datetime.combine(d, time(0)) + timedelta(minutes=off)
                start = max(req, last_end + timedelta(minutes=rng.randint(1, 5)))
                if start >= PERIOD_END_DT:
                    continue
                win = window(st, start.date())
                if win and not (win[0] <= start < win[1]):
                    continue
                if any(ds <= start < de for ds, de, _ in dt_by_conn[c["connector_id"]]):
                    continue
                wait = int((start - req).total_seconds() // 60)
                rec = None
                for _ in range(10):
                    rec = build_one_session(rng, pools, c, st, start, wait, weather[start.date()],
                                            dt_by_conn[c["connector_id"]], veh_busy)
                    if rec:
                        break
                if rec:
                    sessions.append(rec)
                    last_end = rec["end"]
            d += timedelta(days=1)
    sessions.sort(key=lambda r: (r["start"], r["connector_id"]))
    for i, r in enumerate(sessions, 1):
        r["session_id"] = f"S{i:06d}"
    return sessions


# --------------------------------------------------------------------------
# Daily operating costs
# --------------------------------------------------------------------------
def allocate(monthly, d):
    monthly = q2(monthly)
    days = (date(d.year + (d.month == 12), d.month % 12 + 1, 1) - date(d.year, d.month, 1)).days
    share = q2(monthly / days)
    return share if d.day < days else monthly - share * (days - 1)


def build_daily_costs(seed, sessions, downtime):
    rng = sub_rng(seed, "costs")
    elec = defaultdict(lambda: Decimal("0.00"))
    cmap = {}
    for s in sessions:
        elec[(s["station_id"], s["start"].date())] += q2(s["energy"] * s["elec"])
    event_cost = defaultdict(lambda: Decimal("0.00"))
    for r in downtime:
        event_cost[(r["station_id"], r["start"].date())] += r["cost"]
    rows, n = [], 0
    for st in STATIONS:
        for d in all_days():
            n += 1
            rows.append(dict(
                record_id=f"OC{n:06d}", station_id=st["id"], date=d,
                electricity=elec[(st["id"], d)], staff=q2(st["staff"]), rent=allocate(st["rent"], d),
                maintenance=allocate(st["maint"], d) + event_cost[(st["id"], d)],
                other=q2(st["other"] * rng.uniform(0.85, 1.20))))
    return rows


# --------------------------------------------------------------------------
# Output
# --------------------------------------------------------------------------
def write_csv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(header)
        w.writerows(rows)


def ts(x):
    return x.strftime("%Y-%m-%d %H:%M:%S")


def main():
    ap = argparse.ArgumentParser(description="Generate synthetic EV charging dataset")
    ap.add_argument("--out", default="data")
    ap.add_argument("--seed", type=int, default=DEFAULT_SEED)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    connectors, tariffs = build_stations_connectors_tariffs(a.seed)
    downtime = build_downtime(a.seed, connectors)
    sessions = build_sessions(a.seed, connectors, downtime)
    costs = build_daily_costs(a.seed, sessions, downtime)

    count = defaultdict(int)
    for c in connectors:
        count[c["station_id"]] += 1

    write_csv(os.path.join(a.out, "stations.csv"),
              ["station_id", "station_name", "city", "area", "latitude", "longitude", "installation_date",
               "total_connectors", "station_type", "monthly_rent_inr", "maintenance_cost_monthly_inr",
               "operating_hours_per_day"],
              [[s["id"], s["name"], "Chandigarh", s["area"], f"{s['lat']:.4f}", f"{s['lon']:.4f}",
                s["installed"].isoformat(), count[s["id"]], s["stype"], f"{q2(s['rent'])}",
                f"{q2(s['maint'])}", s["hours"]] for s in STATIONS])
    write_csv(os.path.join(a.out, "connectors.csv"),
              ["connector_id", "station_id", "connector_type", "rated_power_kw", "installation_date",
               "connector_status", "electricity_tariff_per_kwh_inr"],
              [[c["connector_id"], c["station_id"], c["connector_type"], f"{c['rated_power_kw']:.1f}",
                c["installed"].isoformat(), c["status"], f"{c['current_elec']}"] for c in connectors])
    write_csv(os.path.join(a.out, "charging_sessions.csv"),
              ["session_id", "connector_id", "station_id", "vehicle_id", "session_start", "session_end",
               "energy_delivered_kwh", "charging_duration_minutes", "idle_duration_minutes",
               "electricity_tariff_per_kwh_inr", "charging_revenue_inr", "session_status", "payment_status",
               "day_type", "weather_condition"],
              [[s["session_id"], s["connector_id"], s["station_id"], s["vehicle_id"], ts(s["start"]),
                ts(s["end"]), f"{s['energy']}", s["charge"], s["idle"], f"{s['elec']}", f"{s['revenue']}",
                s["status"], s["payment"], s["day_type"], s["weather"]] for s in sessions])
    write_csv(os.path.join(a.out, "station_downtime.csv"),
              ["downtime_id", "connector_id", "station_id", "downtime_start", "downtime_end",
               "downtime_duration_minutes", "downtime_reason", "maintenance_type", "maintenance_cost_inr"],
              [[r["downtime_id"], r["connector_id"], r["station_id"], ts(r["start"]), ts(r["end"]),
                r["minutes"], r["reason"], r["mtype"], f"{r['cost']}"] for r in downtime])
    write_csv(os.path.join(a.out, "daily_station_operating_costs.csv"),
              ["record_id", "station_id", "operating_date", "electricity_cost_inr", "staff_cost_inr",
               "rent_cost_inr", "maintenance_cost_inr", "other_operating_cost_inr"],
              [[r["record_id"], r["station_id"], r["date"].isoformat(), f"{r['electricity']}", f"{r['staff']}",
                f"{r['rent']}", f"{r['maintenance']}", f"{r['other']}"] for r in costs])
    write_csv(os.path.join(a.out, "tariff_history.csv"),
              ["tariff_id", "connector_id", "effective_from", "effective_to",
               "electricity_tariff_per_kwh_inr", "customer_price_per_kwh_inr"],
              [[t["tariff_id"], t["connector_id"], t["effective_from"].isoformat(), t["effective_to"].isoformat(),
                f"{t['elec']}", f"{t['price']}"] for t in tariffs])

    print(f"seed={a.seed}  stations={len(STATIONS)}  connectors={len(connectors)}  sessions={len(sessions)}  "
          f"downtime={len(downtime)}  daily_costs={len(costs)}  tariffs={len(tariffs)}  -> {a.out}/")


if __name__ == "__main__":
    main()
