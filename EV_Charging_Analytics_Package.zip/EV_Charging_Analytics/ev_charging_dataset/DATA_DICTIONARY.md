# Data Dictionary

Synthetic dataset for *EV Charging Station Analytics & Profitability Optimization* (Chandigarh, India). Units: INR, kWh, kW, minutes. Timestamps `YYYY-MM-DD HH:MM:SS` (local time), dates `YYYY-MM-DD`. Examples below are read from the actual CSV files.

## stations.csv

Station master data (10 rows). One row per charging station. Rows: **10**.

| Column | Type (MySQL) | Meaning | Example |
|---|---|---|---|
| `station_id` | VARCHAR(10) PK | Unique station code (ST01..ST10). | `ST01` |
| `station_name` | VARCHAR(80) | Synthetic station name (not a real operator). | `EV Hub Sector 17 Plaza` |
| `city` | VARCHAR(40) | City of operation (Chandigarh). | `Chandigarh` |
| `area` | VARCHAR(60) | Sector / locality inside the city (approximate, illustrative). | `Sector 17` |
| `latitude` | DECIMAL(9,4) | Approximate latitude in decimal degrees (for Tableau maps). | `30.7398` |
| `longitude` | DECIMAL(9,4) | Approximate longitude in decimal degrees. | `76.7827` |
| `installation_date` | DATE | Date the station was commissioned (before the study period). | `2024-03-15` |
| `total_connectors` | INT | Number of connector rows belonging to this station (validated against connectors.csv). | `6` |
| `station_type` | VARCHAR(40) | Site category: Commercial Market, Shopping Mall, IT Park / Office, Hospital Campus, Transit Hub, Public Parking, Highway Corridor, Residential Complex, Government Office Complex. | `Commercial Market` |
| `monthly_rent_inr` | DECIMAL(12,2) | Monthly site rent in INR. Spread across calendar days in daily_station_operating_costs.rent_cost_inr. | `48000.00` |
| `maintenance_cost_monthly_inr` | DECIMAL(12,2) | Routine monthly maintenance contract in INR. Event repair costs are separate (station_downtime.maintenance_cost_inr). | `7200.00` |
| `operating_hours_per_day` | INT | Hours open per day. 24 = always open. Otherwise the station opens at 06:00 and closes at 06:00 + hours. | `16` |

## connectors.csv

Connector master data (50 rows). One row per physical charging connector. Rows: **50**.

| Column | Type (MySQL) | Meaning | Example |
|---|---|---|---|
| `connector_id` | VARCHAR(10) PK | Unique connector code (CN001..CN050). | `CN001` |
| `station_id` | VARCHAR(10) FK | Parent station (stations.station_id). | `ST01` |
| `connector_type` | VARCHAR(20) | AC Type 2, DC CCS2 or DC CHAdeMO. | `DC CCS2` |
| `rated_power_kw` | DECIMAL(5,1) | Rated charger power in kW (7.4, 22, 30, 50, 60 or 120). | `60.0` |
| `installation_date` | DATE | Commissioning date. Two connectors were added during the study period. | `2024-03-20` |
| `connector_status` | VARCHAR(20) | Status at the data cut-off 2026-09-30: Active or Under Maintenance. | `Active` |
| `electricity_tariff_per_kwh_inr` | DECIMAL(8,2) | Electricity (cost) tariff in force on 2026-09-30, INR per kWh. History is in tariff_history.csv. | `8.55` |

## charging_sessions.csv

Charging sessions (fact table). One row per plug-in attempt. Rows: **23,325**.

| Column | Type (MySQL) | Meaning | Example |
|---|---|---|---|
| `session_id` | VARCHAR(10) PK | Unique session code (S000001...), ordered by start time. | `S000001` |
| `connector_id` | VARCHAR(10) FK | Connector used (connectors.connector_id). | `CN009` |
| `station_id` | VARCHAR(10) FK | Station of that connector (stations.station_id); always equals the connector's station. | `ST02` |
| `vehicle_id` | VARCHAR(12) | Anonymised synthetic vehicle identifier. Vehicles repeat across sessions. | `VEH-331892` |
| `session_start` | DATETIME | Plug-in / start time, local time, second precision (seconds are 00). | `2026-04-01 00:06:00` |
| `session_end` | DATETIME | Session end time. May be after midnight at 24-hour stations (overnight sessions). | `2026-04-01 01:20:00` |
| `energy_delivered_kwh` | DECIMAL(8,2) | Energy delivered to the vehicle in kWh. 0.00 for cancelled and start-failed sessions; partial for mid-session failures. | `2.21` |
| `charging_duration_minutes` | INT | Minutes actually charging. charging + idle = session_end - session_start. | `45` |
| `idle_duration_minutes` | INT | Minutes plugged in but not charging (waiting, finished, or after a failure). | `29` |
| `electricity_tariff_per_kwh_inr` | DECIMAL(8,2) | Electricity cost tariff applicable on the session start date (matches tariff_history). | `7.44` |
| `charging_revenue_inr` | DECIMAL(10,2) | Billed amount = ROUND_HALF_UP(energy x customer_price_per_kwh_inr, 2) for Completed sessions; 0.00 for Failed / Cancelled. | `33.15` |
| `session_status` | VARCHAR(12) | Completed, Failed or Cancelled. | `Completed` |
| `payment_status` | VARCHAR(16) | Paid, Payment Failed (billed, not collected), Pending (last 2 days only) or Not Charged (failed/cancelled). | `Paid` |
| `day_type` | VARCHAR(10) | Weekday, Weekend or Holiday (holiday dates are illustrative). | `Weekday` |
| `weather_condition` | VARCHAR(10) | City-wide daily weather: Clear, Cloudy, Hot or Rain. | `Clear` |

## station_downtime.csv

Connector downtime events (571 rows). Rows: **571**.

| Column | Type (MySQL) | Meaning | Example |
|---|---|---|---|
| `downtime_id` | VARCHAR(10) PK | Unique downtime event code (DT00001...). | `DT00001` |
| `connector_id` | VARCHAR(10) FK | Connector that was unavailable. | `CN004` |
| `station_id` | VARCHAR(10) FK | Station of that connector. | `ST01` |
| `downtime_start` | DATETIME | Start of unavailability. | `2026-04-01 09:48:00` |
| `downtime_end` | DATETIME | End of unavailability. Truncated at 2026-10-01 00:00:00 for connectors still down at the cut-off. | `2026-04-01 11:47:00` |
| `downtime_duration_minutes` | INT | downtime_end - downtime_start in minutes (validated). | `119` |
| `downtime_reason` | VARCHAR(40) | Planned Maintenance, Equipment Fault, Cable/Connector Damage, Power Outage, Software/Communication Error, Firmware Update or Vandalism/Physical Damage. A power outage creates one row per connector of the station. | `Planned Maintenance` |
| `maintenance_type` | VARCHAR(25) | Preventive, Corrective, Remote Resolution, Software Update or None (Grid Event). | `Preventive` |
| `maintenance_cost_inr` | DECIMAL(10,2) | Cost of the event in INR (parts + labour). Included in the daily maintenance cost on the event's start date. | `1350.00` |

## daily_station_operating_costs.csv

Daily operating cost per station (1,830 rows = 10 stations x 183 days). Rows: **1,830**.

| Column | Type (MySQL) | Meaning | Example |
|---|---|---|---|
| `record_id` | VARCHAR(10) PK | Unique record code (OC000001...). | `OC000001` |
| `station_id` | VARCHAR(10) FK | Station. (station_id, operating_date) is also unique. | `ST01` |
| `operating_date` | DATE | Calendar date (2026-04-01 .. 2026-09-30). | `2026-04-01` |
| `electricity_cost_inr` | DECIMAL(12,2) | Sum over sessions starting that day of round(energy x session electricity tariff, 2). Includes energy of failed sessions. | `1747.40` |
| `staff_cost_inr` | DECIMAL(12,2) | Fixed daily attendant / shift cost for the station. | `650.00` |
| `rent_cost_inr` | DECIMAL(12,2) | Monthly rent / days in month; the last day of each month absorbs rounding so each month sums exactly to the monthly rent. | `1600.00` |
| `maintenance_cost_inr` | DECIMAL(12,2) | Routine monthly contract spread over days + cost of downtime events that started that day. | `1590.00` |
| `other_operating_cost_inr` | DECIMAL(12,2) | Insurance, internet, security, software, cleaning (fixed daily level x random 0.85-1.20). | `205.62` |

## tariff_history.csv

Tariff history (149 rows). Electricity cost tariff and customer price per connector and period. Rows: **149**.

| Column | Type (MySQL) | Meaning | Example |
|---|---|---|---|
| `tariff_id` | VARCHAR(10) PK | Unique tariff row code (TF0001...). | `TF0001` |
| `connector_id` | VARCHAR(10) FK | Connector the tariff applies to. | `CN001` |
| `effective_from` | DATE | First day the tariff applies (inclusive). | `2026-01-01` |
| `effective_to` | DATE | Last day the tariff applies (inclusive). Periods never overlap and have no gaps. | `2026-05-31` |
| `electricity_tariff_per_kwh_inr` | DECIMAL(8,2) | What the station pays for electricity, INR per kWh (blended landed cost). | `8.05` |
| `customer_price_per_kwh_inr` | DECIMAL(8,2) | What the customer pays, INR per kWh. Join to a session by connector_id and DATE(session_start) BETWEEN effective_from AND effective_to. | `23.00` |
