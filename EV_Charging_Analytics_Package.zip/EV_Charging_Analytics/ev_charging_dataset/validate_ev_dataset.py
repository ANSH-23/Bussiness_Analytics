#!/usr/bin/env python3
"""
validate_ev_dataset.py
======================
Independent data-quality validation of the six synthetic EV-charging CSV files.
It reads ONLY the CSV files (it does not import the generator), runs the 12
required checks plus extra operational/reconciliation checks, and writes:

    reports/data_quality_validation_report.md
    reports/dataset_summary.md

Usage:
    python validate_ev_dataset.py --data data --out reports \
        [--generator generate_ev_dataset.py --seed 42]   # adds a reproducibility check

Exit code 0 = all checks passed, 1 = at least one check failed.
Standard library only.
"""
import argparse
import csv
import hashlib
import os
import subprocess
import sys
import tempfile
from collections import defaultdict
from datetime import date, datetime, time, timedelta
from decimal import Decimal, ROUND_HALF_UP

CENT = Decimal("0.01")
FILES = ["stations.csv", "connectors.csv", "charging_sessions.csv", "station_downtime.csv",
         "daily_station_operating_costs.csv", "tariff_history.csv"]
PKS = {"stations.csv": "station_id", "connectors.csv": "connector_id", "charging_sessions.csv": "session_id",
       "station_downtime.csv": "downtime_id", "daily_station_operating_costs.csv": "record_id",
       "tariff_history.csv": "tariff_id"}
PERIOD_START, PERIOD_END = date(2026, 4, 1), date(2026, 9, 30)
PERIOD_START_DT, PERIOD_END_DT = datetime(2026, 4, 1), datetime(2026, 10, 1)
OPEN_HOUR = 6
HOLIDAYS = {date(2026, 4, 3), date(2026, 4, 14), date(2026, 5, 1), date(2026, 5, 27),
            date(2026, 8, 15), date(2026, 9, 4)}
MAX_SHOW = 5


def D(x):
    return Decimal(x)


def q2(x):
    return x.quantize(CENT, rounding=ROUND_HALF_UP)


def pdt(s):
    return datetime.strptime(s, "%Y-%m-%d %H:%M:%S")


def pd_(s):
    return datetime.strptime(s, "%Y-%m-%d").date()


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def load(data, name):
    with open(os.path.join(data, name), newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


class Result:
    def __init__(self, num, title):
        self.num, self.title, self.errors, self.info = num, title, [], []

    def err(self, msg):
        self.errors.append(msg)

    def note(self, msg):
        self.info.append(msg)

    @property
    def ok(self):
        return not self.errors


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="reports")
    ap.add_argument("--generator", default=None)
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    raw = {f: load(a.data, f) for f in FILES}
    results = []

    # ------------------------------------------------------------------ typed load
    parse_errors = Result(3, "Dates and timestamps are valid and chronologically consistent")
    stations, connectors, tariffs_by_conn = {}, {}, defaultdict(list)
    sessions, downtime, costs = [], [], []

    def safe(fn, val, where):
        try:
            return fn(val)
        except Exception:
            parse_errors.err(f"unparseable value {val!r} in {where}")
            return None

    for r in raw["stations.csv"]:
        stations[r["station_id"]] = dict(r, installed=safe(pd_, r["installation_date"], "stations.installation_date"),
                                         n=int(r["total_connectors"]), rent=D(r["monthly_rent_inr"]),
                                         maint=D(r["maintenance_cost_monthly_inr"]), hours=int(r["operating_hours_per_day"]))
    for r in raw["connectors.csv"]:
        connectors[r["connector_id"]] = dict(r, installed=safe(pd_, r["installation_date"], "connectors.installation_date"),
                                             kw=D(r["rated_power_kw"]), elec=D(r["electricity_tariff_per_kwh_inr"]))
    for r in raw["tariff_history.csv"]:
        tariffs_by_conn[r["connector_id"]].append(dict(
            id=r["tariff_id"], f=safe(pd_, r["effective_from"], "tariff.effective_from"),
            t=safe(pd_, r["effective_to"], "tariff.effective_to"),
            elec=D(r["electricity_tariff_per_kwh_inr"]), price=D(r["customer_price_per_kwh_inr"])))
    for r in raw["charging_sessions.csv"]:
        sessions.append(dict(r, start=safe(pdt, r["session_start"], "session_start"),
                             end=safe(pdt, r["session_end"], "session_end"),
                             energy=D(r["energy_delivered_kwh"]), charge=int(r["charging_duration_minutes"]),
                             idle=int(r["idle_duration_minutes"]), elec=D(r["electricity_tariff_per_kwh_inr"]),
                             rev=D(r["charging_revenue_inr"])))
    for r in raw["station_downtime.csv"]:
        downtime.append(dict(r, start=safe(pdt, r["downtime_start"], "downtime_start"),
                             end=safe(pdt, r["downtime_end"], "downtime_end"),
                             minutes=int(r["downtime_duration_minutes"]), cost=D(r["maintenance_cost_inr"])))
    for r in raw["daily_station_operating_costs.csv"]:
        costs.append(dict(r, d=safe(pd_, r["operating_date"], "costs.operating_date"),
                          e=D(r["electricity_cost_inr"]), staff=D(r["staff_cost_inr"]), rent=D(r["rent_cost_inr"]),
                          maint=D(r["maintenance_cost_inr"]), other=D(r["other_operating_cost_inr"])))

    def tariff_at(cid, d):
        return [t for t in tariffs_by_conn.get(cid, []) if t["f"] <= d <= t["t"]]

    # ------------------------------------------------------------------ 1. primary keys
    r1 = Result(1, "All primary keys are unique and non-null")
    for f in FILES:
        pk = PKS[f]
        vals = [row[pk] for row in raw[f]]
        nulls = sum(1 for v in vals if v is None or v.strip() == "")
        dups = len(vals) - len(set(vals))
        if nulls:
            r1.err(f"{f}: {nulls} null/blank {pk}")
        if dups:
            r1.err(f"{f}: {dups} duplicate {pk}")
        r1.note(f"{f}.{pk}: {len(vals):,} rows, 0 nulls, 0 duplicates" if not (nulls or dups) else f"{f}: FAIL")
    results.append(r1)

    # ------------------------------------------------------------------ 2. foreign keys
    r2 = Result(2, "All foreign keys reference valid parent records")
    n_fk = 0

    def fk(rows, col, parents, label):
        nonlocal n_fk
        bad = [x for x in rows if x[col] not in parents]
        n_fk += len(rows)
        if bad:
            r2.err(f"{label}: {len(bad)} orphan values (e.g. {bad[0][col]})")
        else:
            r2.note(f"{label}: {len(rows):,} values, 0 orphans")
    fk(raw["connectors.csv"], "station_id", stations, "connectors.station_id -> stations")
    fk(raw["charging_sessions.csv"], "connector_id", connectors, "charging_sessions.connector_id -> connectors")
    fk(raw["charging_sessions.csv"], "station_id", stations, "charging_sessions.station_id -> stations")
    fk(raw["station_downtime.csv"], "connector_id", connectors, "station_downtime.connector_id -> connectors")
    fk(raw["station_downtime.csv"], "station_id", stations, "station_downtime.station_id -> stations")
    fk(raw["daily_station_operating_costs.csv"], "station_id", stations, "daily_station_operating_costs.station_id -> stations")
    fk(raw["tariff_history.csv"], "connector_id", connectors, "tariff_history.connector_id -> connectors")
    mism = [s["session_id"] for s in sessions if s["connector_id"] in connectors
            and connectors[s["connector_id"]]["station_id"] != s["station_id"]]
    if mism:
        r2.err(f"{len(mism)} sessions whose station_id differs from their connector's station (e.g. {mism[0]})")
    else:
        r2.note("session.station_id equals the parent connector's station_id for every session")
    mism = [d["downtime_id"] for d in downtime if d["connector_id"] in connectors
            and connectors[d["connector_id"]]["station_id"] != d["station_id"]]
    if mism:
        r2.err(f"{len(mism)} downtime rows whose station_id differs from their connector's station (e.g. {mism[0]})")
    else:
        r2.note("downtime.station_id equals the parent connector's station_id for every row")
    results.append(r2)
    if not (r1.ok and r2.ok):          # later joins are meaningless if keys are broken
        lines = ["# Data-Quality Validation Report", "", "**STOPPED: key integrity failed; dependent checks skipped.**", ""]
        for r in (r1, r2):
            lines.append(f"- Check {r.num} ({r.title}): {'PASS' if r.ok else 'FAIL'}")
            lines += [f"  - ERROR: {e}" for e in r.errors[:MAX_SHOW]]
        with open(os.path.join(a.out, "data_quality_validation_report.md"), "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
        print("\n".join(lines))
        sys.exit(1)

    # ------------------------------------------------------------------ 3. dates / chronology
    r3 = parse_errors
    for s in sessions:
        if s["start"] is None or s["end"] is None:
            continue
        mins = int((s["end"] - s["start"]).total_seconds() // 60)
        if not s["end"] > s["start"]:
            r3.err(f"{s['session_id']}: session_end not after session_start")
        if s["charge"] + s["idle"] != mins:
            r3.err(f"{s['session_id']}: charging+idle ({s['charge']+s['idle']}) != end-start ({mins})")
        if not (PERIOD_START_DT <= s["start"] < PERIOD_END_DT):
            r3.err(f"{s['session_id']}: start outside study period")
        c, st = connectors.get(s["connector_id"]), stations.get(s["station_id"])
        if c and s["start"].date() < c["installed"]:
            r3.err(f"{s['session_id']}: starts before connector installation")
        if st and s["start"].date() < st["installed"]:
            r3.err(f"{s['session_id']}: starts before station installation")
    for d in downtime:
        if d["start"] is None or d["end"] is None:
            continue
        if not d["end"] > d["start"]:
            r3.err(f"{d['downtime_id']}: downtime_end not after downtime_start")
        if not (PERIOD_START_DT <= d["start"] and d["end"] <= PERIOD_END_DT):
            r3.err(f"{d['downtime_id']}: outside study period")
        c = connectors.get(d["connector_id"])
        if c and d["start"].date() < c["installed"]:
            r3.err(f"{d['downtime_id']}: starts before connector installation")
    for cid, c in connectors.items():
        st = stations.get(c["station_id"])
        if st and c["installed"] < st["installed"]:
            r3.err(f"{cid}: installed before its station")
        if c["installed"] > PERIOD_END:
            r3.err(f"{cid}: installation after period end")
    for cid, ts_ in tariffs_by_conn.items():
        for t in ts_:
            if t["f"] > t["t"]:
                r3.err(f"{t['id']}: effective_from after effective_to")
    r3.note(f"Checked {len(sessions):,} sessions, {len(downtime):,} downtime rows, {len(tariffs_by_conn):,} tariff groups; "
            f"identity charging+idle = end-start verified for every session")
    results.append(r3)

    # ------------------------------------------------------------------ 4. non-negative
    r4 = Result(4, "Energy, duration and financial values are non-negative")
    neg = defaultdict(int)
    for s in sessions:
        for k in ("energy", "charge", "idle", "elec", "rev"):
            if s[k] < 0:
                neg[f"charging_sessions.{k}"] += 1
    for d in downtime:
        if d["minutes"] < 0 or d["cost"] < 0:
            neg["station_downtime"] += 1
    for c in costs:
        for k in ("e", "staff", "rent", "maint", "other"):
            if c[k] < 0:
                neg[f"daily_costs.{k}"] += 1
    for t in sum(tariffs_by_conn.values(), []):
        if t["elec"] < 0 or t["price"] < 0:
            neg["tariff_history"] += 1
    for st in stations.values():
        if st["rent"] < 0 or st["maint"] < 0 or st["hours"] <= 0 or st["n"] <= 0:
            neg["stations"] += 1
    for c in connectors.values():
        if c["kw"] <= 0 or c["elec"] < 0:
            neg["connectors"] += 1
    for k, v in neg.items():
        r4.err(f"{k}: {v} negative/invalid values")
    r4.note("All energy, duration, tariff, revenue and cost columns are >= 0; rated power > 0")
    results.append(r4)

    # ------------------------------------------------------------------ 5. revenue rule
    r5 = Result(5, "Revenue = energy x applicable customer tariff (status rules applied)")
    n_ok = n_zero = 0
    for s in sessions:
        ts_ = tariff_at(s["connector_id"], s["start"].date())
        if len(ts_) != 1:
            r5.err(f"{s['session_id']}: {len(ts_)} matching tariff rows")
            continue
        price = ts_[0]["price"]
        if s["session_status"] == "Completed":
            if s["energy"] <= 0:
                r5.err(f"{s['session_id']}: completed with zero energy")
            if s["rev"] != q2(s["energy"] * price):
                r5.err(f"{s['session_id']}: revenue {s['rev']} != {q2(s['energy']*price)}")
            else:
                n_ok += 1
            if s["payment_status"] not in ("Paid", "Payment Failed", "Pending"):
                r5.err(f"{s['session_id']}: completed with payment_status {s['payment_status']}")
        else:
            if s["rev"] != 0 or s["payment_status"] != "Not Charged":
                r5.err(f"{s['session_id']}: {s['session_status']} but revenue/payment = {s['rev']}/{s['payment_status']}")
            else:
                n_zero += 1
            if s["session_status"] == "Cancelled" and (s["energy"] != 0 or s["charge"] != 0):
                r5.err(f"{s['session_id']}: cancelled session with energy/charging time")
            if s["session_status"] not in ("Failed", "Cancelled"):
                r5.err(f"{s['session_id']}: unknown status {s['session_status']}")
    r5.note(f"{n_ok:,} completed sessions: revenue == ROUND_HALF_UP(energy x customer_price, 2) exactly")
    r5.note(f"{n_zero:,} failed/cancelled sessions: revenue 0.00 and payment_status 'Not Charged' (no fee modelled)")
    results.append(r5)

    # ------------------------------------------------------------------ 6. electricity cost
    r6 = Result(6, "Electricity costs use the applicable electricity tariff")
    bad = 0
    expected = defaultdict(lambda: Decimal("0.00"))
    for s in sessions:
        ts_ = tariff_at(s["connector_id"], s["start"].date())
        if len(ts_) == 1 and s["elec"] != ts_[0]["elec"]:
            bad += 1
        expected[(s["station_id"], s["start"].date())] += q2(s["energy"] * s["elec"])
    if bad:
        r6.err(f"{bad} sessions whose electricity tariff differs from tariff_history on the start date")
    else:
        r6.note("session electricity tariff equals tariff_history value valid on session start date for every session")
    mism = 0
    for c in costs:
        if c["e"] != expected.get((c["station_id"], c["d"]), Decimal("0.00")):
            mism += 1
    if mism:
        r6.err(f"{mism} station-days where electricity_cost_inr != sum(energy x session tariff)")
    else:
        r6.note(f"All {len(costs):,} station-day electricity costs equal the sum of round(energy x tariff, 2) of that day's sessions")
    badc = [cid for cid, c in connectors.items()
            if len(tariff_at(cid, PERIOD_END)) != 1 or tariff_at(cid, PERIOD_END)[0]["elec"] != c["elec"]]
    if badc:
        r6.err(f"{len(badc)} connectors whose current tariff != tariff_history on {PERIOD_END}")
    else:
        r6.note("connectors.electricity_tariff_per_kwh_inr equals the tariff in force on 2026-09-30 for all 50 connectors")
    results.append(r6)

    # ------------------------------------------------------------------ 7. rent allocation
    r7 = Result(7, "Monthly rent allocations sum to the station's monthly rent (and maintenance reconciles)")
    by_sm = defaultdict(lambda: [Decimal("0.00"), Decimal("0.00"), 0])
    for c in costs:
        k = (c["station_id"], c["d"].year, c["d"].month)
        by_sm[k][0] += c["rent"]
        by_sm[k][1] += c["maint"]
        by_sm[k][2] += 1
    ev = defaultdict(lambda: Decimal("0.00"))
    for d in downtime:
        ev[(d["station_id"], d["start"].year, d["start"].month)] += d["cost"]
    months = 0
    for (sid, y, m), (rent, maint, n) in sorted(by_sm.items()):
        days = (date(y + (m == 12), m % 12 + 1, 1) - date(y, m, 1)).days
        if n != days:
            r7.err(f"{sid} {y}-{m:02d}: {n} daily rows, expected {days}")
        if rent != stations[sid]["rent"]:
            r7.err(f"{sid} {y}-{m:02d}: rent allocations {rent} != monthly rent {stations[sid]['rent']}")
        want = stations[sid]["maint"] + ev[(sid, y, m)]
        if maint != want:
            r7.err(f"{sid} {y}-{m:02d}: maintenance {maint} != routine {stations[sid]['maint']} + events {ev[(sid, y, m)]}")
        months += 1
    r7.note(f"{months} station-months (10 stations x 6 full months): rent sums equal monthly rent exactly")
    r7.note("Daily maintenance per station-month = monthly routine contract + cost of downtime events starting that month (exact)")
    results.append(r7)

    # ------------------------------------------------------------------ 8. connector counts
    r8 = Result(8, "Connector counts match station master data")
    cnt = defaultdict(int)
    for c in connectors.values():
        cnt[c["station_id"]] += 1
    for sid, st in stations.items():
        if cnt[sid] != st["n"]:
            r8.err(f"{sid}: total_connectors={st['n']} but {cnt[sid]} connector rows")
    if len(connectors) != 50 or len(stations) != 10:
        r8.err(f"expected 10 stations / 50 connectors, found {len(stations)} / {len(connectors)}")
    r8.note(f"{len(stations)} stations, {len(connectors)} connectors; per-station counts: " +
            ", ".join(f"{k}={cnt[k]}" for k in sorted(cnt)))
    results.append(r8)

    # ------------------------------------------------------------------ 9. downtime durations / overlap
    r9 = Result(9, "Downtime durations match timestamps; no overlapping downtime per connector")
    for d in downtime:
        real = int((d["end"] - d["start"]).total_seconds() // 60)
        if real != d["minutes"]:
            r9.err(f"{d['downtime_id']}: stated {d['minutes']} min vs actual {real}")
    dt_by = defaultdict(list)
    for d in downtime:
        dt_by[d["connector_id"]].append((d["start"], d["end"], d["downtime_id"]))
    ov = 0
    for cid, lst in dt_by.items():
        lst.sort()
        for (s1, e1, i1), (s2, e2, i2) in zip(lst, lst[1:]):
            if s2 < e1:
                ov += 1
                r9.err(f"{cid}: {i1} overlaps {i2}")
    r9.note(f"{len(downtime):,} downtime rows: duration == end-start for all; {ov} overlaps across {len(dt_by)} connectors")
    results.append(r9)

    # ------------------------------------------------------------------ 10. tariff overlap / coverage
    r10 = Result(10, "Tariff periods do not overlap; every session maps to exactly one tariff")
    for cid in connectors:
        lst = sorted(tariffs_by_conn.get(cid, []), key=lambda t: t["f"])
        if not lst:
            r10.err(f"{cid}: no tariff rows")
            continue
        for t1, t2 in zip(lst, lst[1:]):
            if t2["f"] <= t1["t"]:
                r10.err(f"{cid}: {t1['id']} overlaps {t2['id']}")
            elif t2["f"] != t1["t"] + timedelta(days=1):
                r10.err(f"{cid}: gap between {t1['id']} and {t2['id']}")
        first_needed = max(PERIOD_START, connectors[cid]["installed"])
        if lst[0]["f"] > first_needed or lst[-1]["t"] < PERIOD_END:
            r10.err(f"{cid}: tariffs do not cover {first_needed}..{PERIOD_END}")
    multi = sum(1 for s in sessions if len(tariff_at(s["connector_id"], s["start"].date())) != 1)
    if multi:
        r10.err(f"{multi} sessions do not match exactly one tariff row")
    r10.note(f"{sum(len(v) for v in tariffs_by_conn.values())} tariff rows for {len(tariffs_by_conn)} connectors; "
             f"contiguous, non-overlapping; all {len(sessions):,} sessions match exactly one row")
    results.append(r10)

    # ------------------------------------------------------------------ 11. join duplication
    r11 = Result(11, "Datasets join without unintended row duplication")
    cost_keys = {}
    for c in costs:
        k = (c["station_id"], c["d"])
        if k in cost_keys:
            r11.err(f"duplicate (station_id, operating_date) {k} in daily costs")
        cost_keys[k] = 1
    n_sc = n_ss = n_st = n_oc = 0
    for s in sessions:
        n_sc += 1 if s["connector_id"] in connectors else 0
        n_ss += 1 if s["station_id"] in stations else 0
        n_st += len(tariff_at(s["connector_id"], s["start"].date()))
        n_oc += 1 if (s["station_id"], s["start"].date()) in cost_keys else 0
    for label, n in (("sessions JOIN connectors", n_sc), ("sessions JOIN stations", n_ss),
                     ("sessions JOIN tariff_history (connector + date range)", n_st),
                     ("sessions JOIN daily_costs (station + date)", n_oc)):
        if n != len(sessions):
            r11.err(f"{label}: {n:,} rows vs {len(sessions):,} sessions")
        else:
            r11.note(f"{label}: {n:,} rows (== sessions, no duplication, no loss)")
    results.append(r11)

    # ------------------------------------------------------------------ 12. sufficiency
    r12 = Result(12, "Enough records for utilisation, hourly demand, downtime, revenue, cost and profit analysis")
    if len(sessions) < 5000:
        r12.err(f"only {len(sessions)} sessions")
    span = (max(s["start"] for s in sessions).date() - min(s["start"] for s in sessions).date()).days + 1
    if span < 180:
        r12.err(f"sessions span only {span} days")
    hrs = {s["start"].hour for s in sessions}
    if len(hrs) < 24:
        r12.err(f"only {len(hrs)} distinct start hours")
    for k in ("Completed", "Failed", "Cancelled"):
        if not any(s["session_status"] == k for s in sessions):
            r12.err(f"no {k} sessions")
    for k in ("Weekday", "Weekend", "Holiday"):
        if not any(s["day_type"] == k for s in sessions):
            r12.err(f"no {k} sessions")
    per_st = defaultdict(int)
    for s in sessions:
        per_st[s["station_id"]] += 1
    if min(per_st.values()) < 500:
        r12.err(f"a station has fewer than 500 sessions ({min(per_st.values())})")
    reasons = {d["downtime_reason"] for d in downtime}
    if len(reasons) < 5:
        r12.err(f"only {len(reasons)} downtime reasons")
    r12.note(f"{len(sessions):,} sessions over {span} days; 24/24 start hours; per-station min/max sessions "
             f"{min(per_st.values()):,}/{max(per_st.values()):,}; {len(reasons)} downtime reasons; "
             f"{len(downtime):,} downtime rows; {len(costs):,} station-days of costs")
    results.append(r12)

    # ------------------------------------------------------------------ 13. operational integrity (extra)
    r13 = Result(13, "Operational integrity: no overlaps, operating hours, physical plausibility, calendar tags")
    by_conn = defaultdict(list)
    by_veh = defaultdict(list)
    for s in sessions:
        by_conn[s["connector_id"]].append(s)
        by_veh[s["vehicle_id"]].append(s)
    n_ov = n_dt = 0
    for cid, lst in by_conn.items():
        lst.sort(key=lambda x: x["start"])
        for p, q in zip(lst, lst[1:]):
            if q["start"] < p["end"]:
                n_ov += 1
                r13.err(f"{cid}: {p['session_id']} overlaps {q['session_id']}")
        for s in lst:
            for ds, de, did in dt_by.get(cid, ()):
                if ds < s["end"] and de > s["start"]:
                    n_dt += 1
                    r13.err(f"{s['session_id']} overlaps downtime {did}")
    n_vo = 0
    for vid, lst in by_veh.items():
        lst.sort(key=lambda x: x["start"])
        for p, q in zip(lst, lst[1:]):
            if q["start"] < p["end"]:
                n_vo += 1
                r13.err(f"{vid}: simultaneous sessions {p['session_id']} / {q['session_id']}")
    n_win = n_pow = n_cal = 0
    wx = defaultdict(set)
    n_overnight = 0
    for s in sessions:
        st = stations[s["station_id"]]
        if st["hours"] < 24:
            o = datetime.combine(s["start"].date(), time(OPEN_HOUR))
            if not (o <= s["start"] and s["end"] <= o + timedelta(hours=st["hours"])):
                n_win += 1
                r13.err(f"{s['session_id']}: outside operating window of {s['station_id']}")
        elif s["end"].date() != s["start"].date():
            n_overnight += 1
        if s["charge"] > 0:
            kw = s["energy"] / (Decimal(s["charge"]) / 60)
            if kw > connectors[s["connector_id"]]["kw"] * Decimal("1.01"):
                n_pow += 1
                r13.err(f"{s['session_id']}: implied {kw:.1f} kW exceeds rating")
        d = s["start"].date()
        want = "Holiday" if d in HOLIDAYS else ("Weekend" if d.weekday() >= 5 else "Weekday")
        if s["day_type"] != want:
            n_cal += 1
            r13.err(f"{s['session_id']}: day_type {s['day_type']} != {want}")
        wx[d].add(s["weather_condition"])
    n_wx = sum(1 for v in wx.values() if len(v) > 1)
    if n_wx:
        r13.err(f"{n_wx} dates with more than one weather_condition (weather is city-wide)")
    r13.note(f"Same-connector overlaps: {n_ov}; sessions overlapping downtime: {n_dt}; same-vehicle simultaneous sessions: {n_vo}")
    r13.note(f"Outside operating window: {n_win}; implied power above rating: {n_pow}; day_type mismatches: {n_cal}; "
             f"multi-weather dates: {n_wx}")
    r13.note(f"Overnight sessions crossing midnight (24-hour stations only): {n_overnight:,}")
    results.append(r13)

    # ------------------------------------------------------------------ 14. reconciliation (extra)
    r14 = Result(14, "Station-level and connector-level totals reconcile")
    cs = defaultdict(lambda: [0, Decimal("0"), Decimal("0")])
    ss = defaultdict(lambda: [0, Decimal("0"), Decimal("0")])
    for s in sessions:
        for tab, key in ((cs, s["connector_id"]), (ss, s["station_id"])):
            tab[key][0] += 1
            tab[key][1] += s["energy"]
            tab[key][2] += s["rev"]
    roll = defaultdict(lambda: [0, Decimal("0"), Decimal("0")])
    for cid, v in cs.items():
        sid = connectors[cid]["station_id"]
        for i in range(3):
            roll[sid][i] += v[i]
    for sid in stations:
        if list(roll[sid]) != list(ss[sid]):
            r14.err(f"{sid}: connector roll-up {roll[sid]} != station total {ss[sid]}")
    e_sessions = sum(q2(s["energy"] * s["elec"]) for s in sessions)
    e_costs = sum(c["e"] for c in costs)
    if e_sessions != e_costs:
        r14.err(f"electricity: sessions {e_sessions} != daily costs {e_costs}")
    if len(costs) != len(stations) * ((PERIOD_END - PERIOD_START).days + 1):
        r14.err(f"daily cost rows {len(costs)} != stations x days")
    r14.note("Sum over connectors == station total for session count, kWh and revenue (all 10 stations)")
    r14.note(f"Total electricity cost: sessions INR {e_sessions:,.2f} == daily cost table INR {e_costs:,.2f}")
    r14.note(f"daily_station_operating_costs has {len(costs):,} rows = {len(stations)} stations x "
             f"{(PERIOD_END - PERIOD_START).days + 1} days")
    results.append(r14)

    # ------------------------------------------------------------------ 15. reproducibility (optional)
    if a.generator:
        r15 = Result(15, "Reproducibility: regenerating with the same seed yields identical files")
        with tempfile.TemporaryDirectory() as tmp:
            subprocess.run([sys.executable, a.generator, "--out", tmp, "--seed", str(a.seed)],
                           check=True, stdout=subprocess.DEVNULL)
            for f in FILES:
                if sha(os.path.join(tmp, f)) != sha(os.path.join(a.data, f)):
                    r15.err(f"{f}: SHA-256 differs after regeneration")
                else:
                    r15.note(f"{f}: SHA-256 identical ({sha(os.path.join(a.data, f))[:16]}...)")
        results.append(r15)

    # ------------------------------------------------------------------ report
    results.sort(key=lambda r: r.num)
    lines = ["# Data-Quality Validation Report", "",
             "Synthetic dataset: *EV Charging Station Analytics & Profitability Optimization* (Chandigarh, India).",
             f"Generated by `validate_ev_dataset.py` against the CSV files in `{a.data}/` "
             f"(run on {datetime.now():%Y-%m-%d %H:%M}). Every result below is computed from the files, not asserted.", "",
             "| # | Check | Result |", "|---|-------|--------|"]
    for r in results:
        lines.append(f"| {r.num} | {r.title} | {'PASS' if r.ok else 'FAIL (' + str(len(r.errors)) + ')'} |")
    passed = sum(r.ok for r in results)
    lines += ["", f"**Overall: {passed}/{len(results)} checks passed.**", "", "## Details", ""]
    for r in results:
        lines.append(f"### {r.num}. {r.title} - {'PASS' if r.ok else 'FAIL'}")
        for n in r.info:
            lines.append(f"- {n}")
        for e in r.errors[:MAX_SHOW]:
            lines.append(f"- **ERROR:** {e}")
        if len(r.errors) > MAX_SHOW:
            lines.append(f"- ... and {len(r.errors) - MAX_SHOW} more errors")
        lines.append("")
    lines += ["## Assumptions and limitations", "",
              "- All data is synthetic; place names are approximate real locations used only as realistic context.",
              "- Revenue rule: only `Completed` sessions are billed; `Failed` and `Cancelled` sessions have revenue 0.00 and "
              "`Not Charged` payment status (no cancellation fee, no partial billing). Failed sessions may still have "
              "delivered partial energy, which the station pays for.",
              "- `charging_revenue_inr` is the billed amount. `Payment Failed` / `Pending` sessions are billed but not yet "
              "collected; filter `payment_status = 'Paid'` for collected revenue.",
              "- Customer price is not stored on the session row; join `tariff_history` on connector_id and "
              "session start date (verified 1:1).",
              "- Electricity cost uses a blended landed tariff; no grid losses, separate demand charges, GST, "
              "payment-gateway fees, depreciation or capital cost are modelled.",
              "- Operating window rule: stations with fewer than 24 hours open at 06:00 (not stored in stations.csv).",
              "- Holiday dates are illustrative. Weather is one city-wide value per day.",
              "- Three connectors are 'Under Maintenance' at the cut-off; their final downtime is truncated at 2026-10-01 00:00:00.",
              "- Two connectors were installed during the study period (new capacity ramp-up).",
              "- Utilisation and demand levels are plausible but invented; do not use absolute figures as industry benchmarks.", ""]
    with open(os.path.join(a.out, "data_quality_validation_report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    # ------------------------------------------------------------------ dataset summary
    rng_of = {
        "stations.csv": ("installation_date", pd_), "connectors.csv": ("installation_date", pd_),
        "charging_sessions.csv": ("session_start", pdt), "station_downtime.csv": ("downtime_start", pdt),
        "daily_station_operating_costs.csv": ("operating_date", pd_), "tariff_history.csv": ("effective_from", pd_)}
    sm = ["# Dataset Summary", "", "| File | Rows | Columns | Date column | Earliest | Latest |", "|---|---:|---:|---|---|---|"]
    for f in FILES:
        col, fn = rng_of[f]
        vals = sorted(fn(r[col]) for r in raw[f])
        sm.append(f"| {f} | {len(raw[f]):,} | {len(raw[f][0])} | {col} | {vals[0]} | {vals[-1]} |")
    extra = {"charging_sessions.csv (session_end)": max(s["end"] for s in sessions),
             "station_downtime.csv (downtime_end)": max(d["end"] for d in downtime),
             "tariff_history.csv (effective_to)": max(t["t"] for v in tariffs_by_conn.values() for t in v)}
    sm += ["", "Latest end timestamps: " + "; ".join(f"{k} = {v}" for k, v in extra.items()), "",
           f"Study period: {PERIOD_START} to {PERIOD_END} (183 days, 6 full calendar months).", ""]
    stat = defaultdict(int)
    for s in sessions:
        stat[s["session_status"]] += 1
    pay = defaultdict(int)
    for s in sessions:
        pay[s["payment_status"]] += 1
    tot_rev = sum(s["rev"] for s in sessions)
    tot_kwh = sum(s["energy"] for s in sessions)
    tot_cost = sum(c["e"] + c["staff"] + c["rent"] + c["maint"] + c["other"] for c in costs)
    sm += ["## Key totals (reconciliation snapshot)", "",
           f"- Sessions: {len(sessions):,} (" + ", ".join(f"{k} {v:,} = {v/len(sessions):.1%}" for k, v in sorted(stat.items())) + ")",
           "- Payment status: " + ", ".join(f"{k} {v:,}" for k, v in sorted(pay.items())),
           f"- Energy delivered: {tot_kwh:,.2f} kWh; billed revenue: INR {tot_rev:,.2f}",
           f"- Total operating cost (all five cost columns): INR {tot_cost:,.2f}",
           f"- Downtime: {len(downtime):,} events, {sum(d['minutes'] for d in downtime)/60:,.1f} connector-hours",
           "", "## Station snapshot", "",
           "| Station | Name | Connectors | Sessions | kWh | Billed revenue (INR) | Operating cost (INR) |",
           "|---|---|---:|---:|---:|---:|---:|"]
    cost_by = defaultdict(lambda: Decimal("0"))
    for c in costs:
        cost_by[c["station_id"]] += c["e"] + c["staff"] + c["rent"] + c["maint"] + c["other"]
    for sid in sorted(stations):
        sm.append(f"| {sid} | {stations[sid]['station_name']} | {stations[sid]['n']} | {ss[sid][0]:,} | "
                  f"{ss[sid][1]:,.0f} | {ss[sid][2]:,.0f} | {cost_by[sid]:,.0f} |")
    with open(os.path.join(a.out, "dataset_summary.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(sm) + "\n")

    for r in results:
        print(f"[{'PASS' if r.ok else 'FAIL'}] {r.num:>2}. {r.title}")
        for e in r.errors[:MAX_SHOW]:
            print(f"        ERROR: {e}")
    print(f"\n{passed}/{len(results)} checks passed -> {a.out}/")
    sys.exit(0 if passed == len(results) else 1)


if __name__ == "__main__":
    main()
