# Dataset Summary

| File | Rows | Columns | Date column | Earliest | Latest |
|---|---:|---:|---|---|---|
| stations.csv | 10 | 12 | installation_date | 2023-11-20 | 2025-10-09 |
| connectors.csv | 50 | 7 | installation_date | 2023-11-20 | 2026-07-03 |
| charging_sessions.csv | 23,325 | 15 | session_start | 2026-04-01 00:06:00 | 2026-09-30 23:45:00 |
| station_downtime.csv | 571 | 9 | downtime_start | 2026-04-01 09:48:00 | 2026-09-30 09:55:00 |
| daily_station_operating_costs.csv | 1,830 | 8 | operating_date | 2026-04-01 | 2026-09-30 |
| tariff_history.csv | 149 | 6 | effective_from | 2026-01-01 | 2026-09-01 |

Latest end timestamps: charging_sessions.csv (session_end) = 2026-10-01 08:48:00; station_downtime.csv (downtime_end) = 2026-10-01 00:00:00; tariff_history.csv (effective_to) = 2026-12-31

Study period: 2026-04-01 to 2026-09-30 (183 days, 6 full calendar months).

## Key totals (reconciliation snapshot)

- Sessions: 23,325 (Cancelled 1,018 = 4.4%, Completed 21,299 = 91.3%, Failed 1,008 = 4.3%)
- Payment status: Not Charged 2,026, Paid 20,831, Payment Failed 432, Pending 36
- Energy delivered: 406,073.17 kWh; billed revenue: INR 9,307,323.39
- Total operating cost (all five cost columns): INR 7,910,710.49
- Downtime: 571 events, 1,885.4 connector-hours

## Station snapshot

| Station | Name | Connectors | Sessions | kWh | Billed revenue (INR) | Operating cost (INR) |
|---|---|---:|---:|---:|---:|---:|
| ST01 | EV Hub Sector 17 Plaza | 6 | 3,077 | 47,022 | 992,952 | 916,939 |
| ST02 | EV Hub Sector 35 Residency | 5 | 1,302 | 19,302 | 336,368 | 353,889 |
| ST03 | EV Hub Industrial Area Mall | 6 | 4,069 | 72,933 | 1,722,112 | 1,370,640 |
| ST04 | EV Hub Technology Park | 5 | 1,684 | 25,086 | 483,549 | 577,260 |
| ST05 | EV Hub Sector 12 Medical Campus | 4 | 1,536 | 26,319 | 529,862 | 588,558 |
| ST06 | EV Hub ISBT Sector 43 | 6 | 5,096 | 102,058 | 2,599,746 | 1,562,890 |
| ST07 | EV Hub Manimajra Housing | 4 | 757 | 9,152 | 155,190 | 297,699 |
| ST08 | EV Hub Sector 22 Parking | 5 | 1,536 | 22,306 | 427,968 | 513,400 |
| ST09 | EV Hub Highway Corridor Sector 28 | 5 | 3,422 | 69,926 | 1,835,934 | 1,355,743 |
| ST10 | EV Hub Sector 34 Office Complex | 4 | 846 | 11,969 | 223,643 | 373,693 |
