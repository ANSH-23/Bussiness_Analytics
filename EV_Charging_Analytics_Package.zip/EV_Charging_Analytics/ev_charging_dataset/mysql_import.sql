-- =====================================================================
-- EV Charging Station Analytics & Profitability Optimization
-- MySQL 8.0 schema + CSV import  (SYNTHETIC DATA)
--
-- Before running:
--   1. Edit the data folder path in the LOAD DATA statements below
--      (use forward slashes, e.g. 'C:/ev_project/data/').
--   2. The client must allow LOCAL INFILE:
--        mysql --local-infile=1 -u root -p < mysql_import.sql
--      and the server needs:  SET GLOBAL local_infile = 1;
--      (MySQL Workbench: Edit Connection > Advanced > Others:  OPT_LOCAL_INFILE=1)
--   Alternative: Workbench "Table Data Import Wizard" on each table, in the
--   load order shown here (parents before children).
-- =====================================================================

CREATE DATABASE IF NOT EXISTS ev_charging CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE ev_charging;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS daily_station_operating_costs;
DROP TABLE IF EXISTS station_downtime;
DROP TABLE IF EXISTS charging_sessions;
DROP TABLE IF EXISTS tariff_history;
DROP TABLE IF EXISTS connectors;
DROP TABLE IF EXISTS stations;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE stations (
    station_id                    VARCHAR(10)   NOT NULL,
    station_name                  VARCHAR(80)   NOT NULL,
    city                          VARCHAR(40)   NOT NULL,
    area                          VARCHAR(60)   NOT NULL,
    latitude                      DECIMAL(9,4)  NOT NULL,
    longitude                     DECIMAL(9,4)  NOT NULL,
    installation_date             DATE          NOT NULL,
    total_connectors              INT           NOT NULL,
    station_type                  VARCHAR(40)   NOT NULL,
    monthly_rent_inr              DECIMAL(12,2) NOT NULL,
    maintenance_cost_monthly_inr  DECIMAL(12,2) NOT NULL,
    operating_hours_per_day       INT           NOT NULL,
    PRIMARY KEY (station_id),
    CONSTRAINT chk_st_hours CHECK (operating_hours_per_day BETWEEN 1 AND 24),
    CONSTRAINT chk_st_money CHECK (monthly_rent_inr >= 0 AND maintenance_cost_monthly_inr >= 0)
) ENGINE=InnoDB;

CREATE TABLE connectors (
    connector_id                    VARCHAR(10)  NOT NULL,
    station_id                      VARCHAR(10)  NOT NULL,
    connector_type                  VARCHAR(20)  NOT NULL,
    rated_power_kw                  DECIMAL(5,1) NOT NULL,
    installation_date               DATE         NOT NULL,
    connector_status                VARCHAR(20)  NOT NULL,
    electricity_tariff_per_kwh_inr  DECIMAL(8,2) NOT NULL,
    PRIMARY KEY (connector_id),
    KEY idx_conn_station (station_id),
    CONSTRAINT fk_conn_station FOREIGN KEY (station_id) REFERENCES stations (station_id),
    CONSTRAINT chk_conn_power CHECK (rated_power_kw > 0)
) ENGINE=InnoDB;

CREATE TABLE tariff_history (
    tariff_id                       VARCHAR(10)  NOT NULL,
    connector_id                    VARCHAR(10)  NOT NULL,
    effective_from                  DATE         NOT NULL,
    effective_to                    DATE         NOT NULL,
    electricity_tariff_per_kwh_inr  DECIMAL(8,2) NOT NULL,
    customer_price_per_kwh_inr      DECIMAL(8,2) NOT NULL,
    PRIMARY KEY (tariff_id),
    UNIQUE KEY uq_tariff_conn_from (connector_id, effective_from),
    CONSTRAINT fk_tariff_conn FOREIGN KEY (connector_id) REFERENCES connectors (connector_id),
    CONSTRAINT chk_tariff_dates CHECK (effective_from <= effective_to),
    CONSTRAINT chk_tariff_vals CHECK (electricity_tariff_per_kwh_inr >= 0 AND customer_price_per_kwh_inr >= 0)
) ENGINE=InnoDB;

CREATE TABLE charging_sessions (
    session_id                      VARCHAR(10)  NOT NULL,
    connector_id                    VARCHAR(10)  NOT NULL,
    station_id                      VARCHAR(10)  NOT NULL,
    vehicle_id                      VARCHAR(12)  NOT NULL,
    session_start                   DATETIME     NOT NULL,
    session_end                     DATETIME     NOT NULL,
    energy_delivered_kwh            DECIMAL(8,2) NOT NULL,
    charging_duration_minutes       INT          NOT NULL,
    idle_duration_minutes           INT          NOT NULL,
    electricity_tariff_per_kwh_inr  DECIMAL(8,2) NOT NULL,
    charging_revenue_inr            DECIMAL(10,2) NOT NULL,
    session_status                  VARCHAR(12)  NOT NULL,
    payment_status                  VARCHAR(16)  NOT NULL,
    day_type                        VARCHAR(10)  NOT NULL,
    weather_condition               VARCHAR(10)  NOT NULL,
    PRIMARY KEY (session_id),
    KEY idx_sess_conn_start (connector_id, session_start),
    KEY idx_sess_station_start (station_id, session_start),
    KEY idx_sess_start (session_start),
    CONSTRAINT fk_sess_conn    FOREIGN KEY (connector_id) REFERENCES connectors (connector_id),
    CONSTRAINT fk_sess_station FOREIGN KEY (station_id)   REFERENCES stations (station_id),
    CONSTRAINT chk_sess_time   CHECK (session_end > session_start),
    CONSTRAINT chk_sess_nonneg CHECK (energy_delivered_kwh >= 0 AND charging_duration_minutes >= 0
                                      AND idle_duration_minutes >= 0 AND charging_revenue_inr >= 0),
    CONSTRAINT chk_sess_status CHECK (session_status IN ('Completed','Failed','Cancelled'))
) ENGINE=InnoDB;

CREATE TABLE station_downtime (
    downtime_id                 VARCHAR(10)   NOT NULL,
    connector_id                VARCHAR(10)   NOT NULL,
    station_id                  VARCHAR(10)   NOT NULL,
    downtime_start              DATETIME      NOT NULL,
    downtime_end                DATETIME      NOT NULL,
    downtime_duration_minutes   INT           NOT NULL,
    downtime_reason             VARCHAR(40)   NOT NULL,
    maintenance_type            VARCHAR(25)   NOT NULL,
    maintenance_cost_inr        DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (downtime_id),
    KEY idx_dt_conn_start (connector_id, downtime_start),
    KEY idx_dt_station (station_id),
    CONSTRAINT fk_dt_conn    FOREIGN KEY (connector_id) REFERENCES connectors (connector_id),
    CONSTRAINT fk_dt_station FOREIGN KEY (station_id)   REFERENCES stations (station_id),
    CONSTRAINT chk_dt_time   CHECK (downtime_end > downtime_start),
    CONSTRAINT chk_dt_nonneg CHECK (downtime_duration_minutes >= 0 AND maintenance_cost_inr >= 0)
) ENGINE=InnoDB;

CREATE TABLE daily_station_operating_costs (
    record_id                 VARCHAR(10)   NOT NULL,
    station_id                VARCHAR(10)   NOT NULL,
    operating_date            DATE          NOT NULL,
    electricity_cost_inr      DECIMAL(12,2) NOT NULL,
    staff_cost_inr            DECIMAL(12,2) NOT NULL,
    rent_cost_inr             DECIMAL(12,2) NOT NULL,
    maintenance_cost_inr      DECIMAL(12,2) NOT NULL,
    other_operating_cost_inr  DECIMAL(12,2) NOT NULL,
    PRIMARY KEY (record_id),
    UNIQUE KEY uq_cost_station_date (station_id, operating_date),
    CONSTRAINT fk_cost_station FOREIGN KEY (station_id) REFERENCES stations (station_id),
    CONSTRAINT chk_cost_nonneg CHECK (electricity_cost_inr >= 0 AND staff_cost_inr >= 0 AND rent_cost_inr >= 0
                                      AND maintenance_cost_inr >= 0 AND other_operating_cost_inr >= 0)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Load order: parents first.  EDIT THE PATH.
-- ---------------------------------------------------------------------
LOAD DATA LOCAL INFILE 'data/stations.csv' INTO TABLE stations
  FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'data/connectors.csv' INTO TABLE connectors
  FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'data/tariff_history.csv' INTO TABLE tariff_history
  FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'data/charging_sessions.csv' INTO TABLE charging_sessions
  FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'data/station_downtime.csv' INTO TABLE station_downtime
  FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'data/daily_station_operating_costs.csv' INTO TABLE daily_station_operating_costs
  FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 LINES;

-- ---------------------------------------------------------------------
-- Import check only (expected: 10, 50, 149, 23325, 571, 1830)
-- ---------------------------------------------------------------------
SELECT 'stations' AS table_name, COUNT(*) AS row_count FROM stations
UNION ALL SELECT 'connectors', COUNT(*) FROM connectors
UNION ALL SELECT 'tariff_history', COUNT(*) FROM tariff_history
UNION ALL SELECT 'charging_sessions', COUNT(*) FROM charging_sessions
UNION ALL SELECT 'station_downtime', COUNT(*) FROM station_downtime
UNION ALL SELECT 'daily_station_operating_costs', COUNT(*) FROM daily_station_operating_costs;
