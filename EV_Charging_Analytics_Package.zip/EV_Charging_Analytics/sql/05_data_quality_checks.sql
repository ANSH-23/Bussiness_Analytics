-- =============================================================================
-- EV Charging Station Analytics & Profitability Optimization
-- Script 05: SQL Data Quality & Integrity Validation Test Suite
-- Target RDBMS: MySQL 8.0 Community Server
-- Author: Senior QA & Database Engineer
-- Description:
--   Executes automated SQL assertion checks verifying database integrity:
--   1. Primary key uniqueness & NULL detection
--   2. Foreign key orphan detection
--   3. Timestamp chronological consistency (start < end)
--   4. Duration calculation consistency
--   5. Schedule collision detection (overlapping sessions or downtime)
--   6. Financial reconciliation (Revenue formula & Electricity cost cross-reconciliation)
--   Each check returns 0 records when the database is in a healthy, valid state.
-- =============================================================================

USE ev_charging_analytics;

-- =============================================================================
-- TEST 1: Primary Key Uniqueness & NULL Verification
-- Expectation: 0 rows returned
-- =============================================================================
SELECT 'Duplicate/NULL Station IDs' AS issue_type, station_id, COUNT(*) AS count
FROM stations
GROUP BY station_id
HAVING COUNT(*) > 1 OR station_id IS NULL

UNION ALL

SELECT 'Duplicate/NULL Connector IDs', connector_id, COUNT(*)
FROM connectors
GROUP BY connector_id
HAVING COUNT(*) > 1 OR connector_id IS NULL

UNION ALL

SELECT 'Duplicate/NULL Session IDs', session_id, COUNT(*)
FROM charging_sessions
GROUP BY session_id
HAVING COUNT(*) > 1 OR session_id IS NULL

UNION ALL

SELECT 'Duplicate/NULL Downtime IDs', downtime_id, COUNT(*)
FROM station_downtime
GROUP BY downtime_id
HAVING COUNT(*) > 1 OR downtime_id IS NULL

UNION ALL

SELECT 'Duplicate Station-Date Costs', CONCAT(station_id, ' | ', operating_date), COUNT(*)
FROM daily_station_operating_costs
GROUP BY station_id, operating_date
HAVING COUNT(*) > 1;

-- =============================================================================
-- TEST 2: Foreign Key Orphan Record Checks
-- Expectation: 0 rows returned
-- =============================================================================
-- Check for connectors with non-existent station_id
SELECT 'Connectors Orphan Station' AS check_name, c.connector_id, c.station_id
FROM connectors c
LEFT JOIN stations s ON c.station_id = s.station_id
WHERE s.station_id IS NULL

UNION ALL

-- Check for charging sessions with non-existent connector_id
SELECT 'Sessions Orphan Connector', cs.session_id, cs.connector_id
FROM charging_sessions cs
LEFT JOIN connectors c ON cs.connector_id = c.connector_id
WHERE c.connector_id IS NULL

UNION ALL

-- Check for downtime with non-existent connector_id
SELECT 'Downtime Orphan Connector', sd.downtime_id, sd.connector_id
FROM station_downtime sd
LEFT JOIN connectors c ON sd.connector_id = c.connector_id
WHERE c.connector_id IS NULL

UNION ALL

-- Check for daily costs with non-existent station_id
SELECT 'Daily Costs Orphan Station', dc.record_id, dc.station_id
FROM daily_station_operating_costs dc
LEFT JOIN stations s ON dc.station_id = s.station_id
WHERE s.station_id IS NULL;

-- =============================================================================
-- TEST 3: Chronological Timestamp & Duration Consistency Checks
-- Expectation: 0 rows returned
-- =============================================================================
-- Check for sessions where session_end <= session_start OR duration mismatch
SELECT 
    'Session Timestamp / Duration Invalid' AS issue_type,
    session_id,
    session_start,
    session_end,
    charging_duration_minutes,
    idle_duration_minutes,
    TIMESTAMPDIFF(MINUTE, session_start, session_end) AS actual_minutes
FROM charging_sessions
WHERE session_end <= session_start
   OR TIMESTAMPDIFF(MINUTE, session_start, session_end) != (charging_duration_minutes + idle_duration_minutes)

UNION ALL

-- Check for downtime where downtime_end <= downtime_start OR duration mismatch
SELECT 
    'Downtime Timestamp / Duration Invalid',
    downtime_id,
    downtime_start,
    downtime_end,
    downtime_duration_minutes,
    0,
    TIMESTAMPDIFF(MINUTE, downtime_start, downtime_end)
FROM station_downtime
WHERE downtime_end <= downtime_start
   OR TIMESTAMPDIFF(MINUTE, downtime_start, downtime_end) != downtime_duration_minutes;

-- =============================================================================
-- TEST 4: Schedule Overlap & Collision Assertion Checks
-- Expectation: 0 rows returned
-- =============================================================================
-- Overlapping sessions on the same connector
SELECT 
    'Overlapping Charging Sessions' AS collision_type,
    s1.connector_id,
    s1.session_id AS session_1,
    s2.session_id AS session_2,
    s1.session_start AS s1_start,
    s1.session_end AS s1_end,
    s2.session_start AS s2_start,
    s2.session_end AS s2_end
FROM charging_sessions s1
JOIN charging_sessions s2 
  ON s1.connector_id = s2.connector_id 
 AND s1.session_id < s2.session_id
WHERE s1.session_start < s2.session_end 
  AND s1.session_end > s2.session_start

UNION ALL

-- Overlapping downtime events on the same connector
SELECT 
    'Overlapping Downtime Events',
    d1.connector_id,
    d1.downtime_id,
    d2.downtime_id,
    d1.downtime_start,
    d1.downtime_end,
    d2.downtime_start,
    d2.downtime_end
FROM station_downtime d1
JOIN station_downtime d2 
  ON d1.connector_id = d2.connector_id 
 AND d1.downtime_id < d2.downtime_id
WHERE d1.downtime_start < d2.downtime_end 
  AND d1.downtime_end > d2.downtime_start

UNION ALL

-- Collision between a charging session and connector downtime
SELECT 
    'Session & Downtime Collision',
    cs.connector_id,
    cs.session_id,
    sd.downtime_id,
    cs.session_start,
    cs.session_end,
    sd.downtime_start,
    sd.downtime_end
FROM charging_sessions cs
JOIN station_downtime sd 
  ON cs.connector_id = sd.connector_id
WHERE cs.session_start < sd.downtime_end 
  AND cs.session_end > sd.downtime_start;

-- =============================================================================
-- TEST 5: Financial Formula Reconciliation Checks
-- Expectation: 0 rows returned
-- =============================================================================
-- Check completed sessions where revenue != energy * customer_price
SELECT 
    'Revenue Formula Mismatch' AS error_type,
    session_id,
    energy_delivered_kwh,
    customer_price_per_kwh_inr,
    charging_revenue_inr,
    ROUND(energy_delivered_kwh * customer_price_per_kwh_inr, 2) AS expected_revenue_inr
FROM charging_sessions
WHERE session_status = 'Completed'
  AND ABS(charging_revenue_inr - ROUND(energy_delivered_kwh * customer_price_per_kwh_inr, 2)) > 0.01

UNION ALL

-- Check failed sessions with non-zero revenue
SELECT 
    'Non-Zero Failed Session Revenue',
    session_id,
    energy_delivered_kwh,
    customer_price_per_kwh_inr,
    charging_revenue_inr,
    0.00
FROM charging_sessions
WHERE session_status IN ('Failed', 'Cancelled')
  AND charging_revenue_inr > 0;

-- =============================================================================
-- TEST 6: Macro Cross-Table Financial Reconciliation Summary
-- Expectation: Difference should be negligible (< INR 1.00 rounding)
-- =============================================================================
SELECT 
    'Session Total vs Daily Table Electricity Cost' AS reconciliation_check,
    ROUND(SUM(cs.energy_delivered_kwh * cs.electricity_tariff_per_kwh_inr), 2) AS sessions_elec_cost_inr,
    (SELECT ROUND(SUM(electricity_cost_inr), 2) FROM daily_station_operating_costs) AS daily_table_elec_cost_inr,
    ROUND(ABS(SUM(cs.energy_delivered_kwh * cs.electricity_tariff_per_kwh_inr) - 
              (SELECT SUM(electricity_cost_inr) FROM daily_station_operating_costs)), 2) AS rounding_variance_inr
FROM charging_sessions cs;
