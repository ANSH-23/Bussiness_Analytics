-- =============================================================================
-- EV Charging Station Analytics & Profitability Optimization
-- Script 04: Analytical Views DDL
-- Target RDBMS: MySQL 8.0 Community Server
-- Author: Senior MySQL Database Engineer
-- Description:
--   Creates 5 production analytical views providing reusable, certified
--   business metrics for reporting layers (Excel, Tableau, Python, PowerBI).
--   Avoids fan-out join multiplication and guarantees exact financial reconciliation.
-- =============================================================================

USE ev_charging_analytics;

-- Drop existing views in case of re-run
DROP VIEW IF EXISTS vw_monthly_financial_summary;
DROP VIEW IF EXISTS vw_connector_utilization;
DROP VIEW IF EXISTS vw_daily_station_performance;
DROP VIEW IF EXISTS vw_station_profitability;
DROP VIEW IF EXISTS vw_session_financials;

-- =============================================================================
-- View 1: vw_session_financials
-- Provides granular session unit economics, COGS, and gross contribution.
-- =============================================================================
CREATE VIEW vw_session_financials AS
SELECT 
    cs.session_id,
    cs.connector_id,
    cs.station_id,
    s.station_name,
    s.area,
    c.connector_type,
    c.rated_power_kw,
    cs.vehicle_id,
    cs.session_start,
    cs.session_end,
    DATE(cs.session_start) AS session_date,
    HOUR(cs.session_start) AS session_hour,
    DATE_FORMAT(cs.session_start, '%Y-%m') AS session_month,
    cs.day_type,
    cs.weather_condition,
    cs.session_status,
    cs.payment_status,
    cs.energy_delivered_kwh,
    cs.charging_duration_minutes,
    cs.idle_duration_minutes,
    (cs.charging_duration_minutes + cs.idle_duration_minutes) AS total_occupancy_minutes,
    cs.electricity_tariff_per_kwh_inr,
    cs.customer_price_per_kwh_inr,
    cs.charging_revenue_inr,
    ROUND(cs.energy_delivered_kwh * cs.electricity_tariff_per_kwh_inr, 2) AS electricity_cost_inr,
    ROUND(cs.charging_revenue_inr - (cs.energy_delivered_kwh * cs.electricity_tariff_per_kwh_inr), 2) AS gross_contribution_inr,
    CASE 
        WHEN cs.charging_revenue_inr > 0 THEN 
            ROUND(((cs.charging_revenue_inr - (cs.energy_delivered_kwh * cs.electricity_tariff_per_kwh_inr)) / cs.charging_revenue_inr) * 100, 2)
        ELSE 0.00
    END AS gross_margin_pct
FROM charging_sessions cs
JOIN stations s ON cs.station_id = s.station_id
JOIN connectors c ON cs.connector_id = c.connector_id;

-- =============================================================================
-- View 2: vw_station_profitability
-- Aggregates station-level revenue, full operating expenses, and net profit.
-- =============================================================================
CREATE VIEW vw_station_profitability AS
WITH StationRevenue AS (
    SELECT 
        station_id,
        COUNT(session_id) AS total_sessions,
        SUM(CASE WHEN session_status = 'Completed' THEN 1 ELSE 0 END) AS completed_sessions,
        SUM(CASE WHEN session_status = 'Failed' THEN 1 ELSE 0 END) AS failed_sessions,
        SUM(energy_delivered_kwh) AS total_energy_kwh,
        SUM(charging_revenue_inr) AS total_revenue_inr,
        SUM(charging_duration_minutes) AS total_charging_minutes
    FROM charging_sessions
    GROUP BY station_id
),
StationOpex AS (
    SELECT 
        station_id,
        SUM(electricity_cost_inr) AS total_elec_cost_inr,
        SUM(staff_cost_inr) AS total_staff_cost_inr,
        SUM(rent_cost_inr) AS total_rent_cost_inr,
        SUM(maintenance_cost_inr) AS total_maint_cost_inr,
        SUM(other_operating_cost_inr) AS total_other_cost_inr,
        SUM(electricity_cost_inr + staff_cost_inr + rent_cost_inr + maintenance_cost_inr + other_operating_cost_inr) AS total_opex_inr
    FROM daily_station_operating_costs
    GROUP BY station_id
)
SELECT 
    s.station_id,
    s.station_name,
    s.area,
    s.station_type,
    s.total_connectors,
    s.operating_hours_per_day,
    sr.total_sessions,
    sr.completed_sessions,
    sr.failed_sessions,
    ROUND(sr.completed_sessions * 100.0 / NULLIF(sr.total_sessions, 0), 2) AS success_rate_pct,
    ROUND(sr.total_energy_kwh, 2) AS total_energy_kwh,
    ROUND(sr.total_revenue_inr, 2) AS total_revenue_inr,
    ROUND(so.total_elec_cost_inr, 2) AS electricity_cost_inr,
    ROUND(sr.total_revenue_inr - so.total_elec_cost_inr, 2) AS gross_contribution_inr,
    ROUND(so.total_staff_cost_inr, 2) AS staff_cost_inr,
    ROUND(so.total_rent_cost_inr, 2) AS rent_cost_inr,
    ROUND(so.total_maint_cost_inr, 2) AS maintenance_cost_inr,
    ROUND(so.total_other_cost_inr, 2) AS other_operating_cost_inr,
    ROUND(so.total_opex_inr, 2) AS total_operating_costs_inr,
    ROUND(sr.total_revenue_inr - so.total_opex_inr, 2) AS operating_profit_inr,
    ROUND(((sr.total_revenue_inr - so.total_opex_inr) / NULLIF(sr.total_revenue_inr, 0)) * 100, 2) AS operating_margin_pct,
    (s.total_connectors * s.operating_hours_per_day * 60 * 182) AS total_available_minutes,
    sr.total_charging_minutes,
    ROUND(sr.total_charging_minutes * 100.0 / (s.total_connectors * s.operating_hours_per_day * 60 * 182), 2) AS utilization_rate_pct
FROM stations s
LEFT JOIN StationRevenue sr ON s.station_id = sr.station_id
LEFT JOIN StationOpex so ON s.station_id = so.station_id;

-- =============================================================================
-- View 3: vw_daily_station_performance
-- Daily station activity reconciling session revenue against daily OPEX.
-- =============================================================================
CREATE VIEW vw_daily_station_performance AS
WITH DailySessions AS (
    SELECT 
        station_id,
        DATE(session_start) AS op_date,
        COUNT(session_id) AS total_sessions,
        SUM(CASE WHEN session_status = 'Completed' THEN 1 ELSE 0 END) AS completed_sessions,
        SUM(CASE WHEN session_status = 'Failed' THEN 1 ELSE 0 END) AS failed_sessions,
        SUM(energy_delivered_kwh) AS total_energy_kwh,
        SUM(charging_revenue_inr) AS daily_revenue_inr,
        SUM(charging_duration_minutes) AS daily_charging_minutes
    FROM charging_sessions
    GROUP BY station_id, DATE(session_start)
),
DailyDowntime AS (
    SELECT 
        station_id,
        DATE(downtime_start) AS dt_date,
        SUM(downtime_duration_minutes) AS downtime_minutes
    FROM station_downtime
    GROUP BY station_id, DATE(downtime_start)
)
SELECT 
    c.operating_date,
    c.station_id,
    s.station_name,
    s.area,
    COALESCE(ds.total_sessions, 0) AS total_sessions,
    COALESCE(ds.completed_sessions, 0) AS completed_sessions,
    COALESCE(ds.failed_sessions, 0) AS failed_sessions,
    COALESCE(ROUND(ds.total_energy_kwh, 2), 0.00) AS energy_delivered_kwh,
    COALESCE(ROUND(ds.daily_revenue_inr, 2), 0.00) AS charging_revenue_inr,
    ROUND(c.electricity_cost_inr, 2) AS electricity_cost_inr,
    ROUND(c.staff_cost_inr, 2) AS staff_cost_inr,
    ROUND(c.rent_cost_inr, 2) AS rent_cost_inr,
    ROUND(c.maintenance_cost_inr, 2) AS maintenance_cost_inr,
    ROUND(c.other_operating_cost_inr, 2) AS other_operating_cost_inr,
    ROUND(c.electricity_cost_inr + c.staff_cost_inr + c.rent_cost_inr + c.maintenance_cost_inr + c.other_operating_cost_inr, 2) AS total_daily_costs_inr,
    ROUND(COALESCE(ds.daily_revenue_inr, 0.00) - 
          (c.electricity_cost_inr + c.staff_cost_inr + c.rent_cost_inr + c.maintenance_cost_inr + c.other_operating_cost_inr), 2) AS daily_operating_profit_inr,
    (s.total_connectors * s.operating_hours_per_day * 60) AS available_connector_minutes,
    COALESCE(dd.downtime_minutes, 0) AS downtime_minutes,
    ROUND(COALESCE(ds.daily_charging_minutes, 0) * 100.0 / (s.total_connectors * s.operating_hours_per_day * 60), 2) AS utilization_rate_pct
FROM daily_station_operating_costs c
JOIN stations s ON c.station_id = s.station_id
LEFT JOIN DailySessions ds ON c.station_id = ds.station_id AND c.operating_date = ds.op_date
LEFT JOIN DailyDowntime dd ON c.station_id = dd.station_id AND c.operating_date = dd.dt_date;

-- =============================================================================
-- View 4: vw_connector_utilization
-- Evaluates port-level uptime, downtime, and capacity utilization.
-- =============================================================================
CREATE VIEW vw_connector_utilization AS
WITH ConnSessions AS (
    SELECT 
        connector_id,
        COUNT(session_id) AS total_sessions,
        SUM(CASE WHEN session_status = 'Completed' THEN 1 ELSE 0 END) AS completed_sessions,
        SUM(CASE WHEN session_status = 'Failed' THEN 1 ELSE 0 END) AS failed_sessions,
        SUM(energy_delivered_kwh) AS energy_kwh,
        SUM(charging_revenue_inr) AS revenue_inr,
        SUM(charging_duration_minutes) AS active_charging_mins,
        SUM(idle_duration_minutes) AS idle_mins
    FROM charging_sessions
    GROUP BY connector_id
),
ConnDowntime AS (
    SELECT 
        connector_id,
        SUM(downtime_duration_minutes) AS downtime_mins
    FROM station_downtime
    GROUP BY connector_id
)
SELECT 
    c.connector_id,
    c.station_id,
    s.station_name,
    c.connector_type,
    c.rated_power_kw,
    COALESCE(cs.total_sessions, 0) AS total_sessions,
    COALESCE(cs.completed_sessions, 0) AS completed_sessions,
    COALESCE(cs.failed_sessions, 0) AS failed_sessions,
    COALESCE(ROUND(cs.energy_kwh, 2), 0.00) AS total_energy_kwh,
    COALESCE(ROUND(cs.revenue_inr, 2), 0.00) AS total_revenue_inr,
    (s.operating_hours_per_day * 60 * 182) AS total_available_minutes,
    COALESCE(cs.active_charging_mins, 0) AS active_charging_minutes,
    COALESCE(cs.idle_mins, 0) AS idle_minutes,
    COALESCE(cd.downtime_mins, 0) AS downtime_minutes,
    ROUND(COALESCE(cs.active_charging_mins, 0) * 100.0 / (s.operating_hours_per_day * 60 * 182), 2) AS utilization_rate_pct,
    ROUND(COALESCE(cd.downtime_mins, 0) * 100.0 / (s.operating_hours_per_day * 60 * 182), 2) AS downtime_rate_pct
FROM connectors c
JOIN stations s ON c.station_id = s.station_id
LEFT JOIN ConnSessions cs ON c.connector_id = cs.connector_id
LEFT JOIN ConnDowntime cd ON c.connector_id = cd.connector_id;

-- =============================================================================
-- View 5: vw_monthly_financial_summary
-- Executive monthly network-wide financial performance report.
-- =============================================================================
CREATE VIEW vw_monthly_financial_summary AS
WITH MonthlySessions AS (
    SELECT 
        DATE_FORMAT(session_start, '%Y-%m') AS billing_month,
        COUNT(session_id) AS total_sessions,
        SUM(CASE WHEN session_status = 'Completed' THEN 1 ELSE 0 END) AS completed_sessions,
        SUM(energy_delivered_kwh) AS total_energy_kwh,
        SUM(charging_revenue_inr) AS charging_revenue_inr
    FROM charging_sessions
    GROUP BY DATE_FORMAT(session_start, '%Y-%m')
),
MonthlyCosts AS (
    SELECT 
        DATE_FORMAT(operating_date, '%Y-%m') AS cost_month,
        SUM(electricity_cost_inr) AS electricity_cost_inr,
        SUM(staff_cost_inr) AS staff_cost_inr,
        SUM(rent_cost_inr) AS rent_cost_inr,
        SUM(maintenance_cost_inr) AS maintenance_cost_inr,
        SUM(other_operating_cost_inr) AS other_operating_cost_inr,
        SUM(electricity_cost_inr + staff_cost_inr + rent_cost_inr + maintenance_cost_inr + other_operating_cost_inr) AS total_opex_inr
    FROM daily_station_operating_costs
    GROUP BY DATE_FORMAT(operating_date, '%Y-%m')
)
SELECT 
    ms.billing_month,
    ms.total_sessions,
    ms.completed_sessions,
    ROUND(ms.total_energy_kwh, 2) AS energy_delivered_kwh,
    ROUND(ms.charging_revenue_inr, 2) AS charging_revenue_inr,
    ROUND(mc.electricity_cost_inr, 2) AS electricity_cost_inr,
    ROUND(ms.charging_revenue_inr - mc.electricity_cost_inr, 2) AS gross_contribution_inr,
    ROUND(mc.staff_cost_inr, 2) AS staff_cost_inr,
    ROUND(mc.rent_cost_inr, 2) AS rent_cost_inr,
    ROUND(mc.maintenance_cost_inr, 2) AS maintenance_cost_inr,
    ROUND(mc.other_operating_cost_inr, 2) AS other_operating_cost_inr,
    ROUND(mc.total_opex_inr, 2) AS total_operating_costs_inr,
    ROUND(ms.charging_revenue_inr - mc.total_opex_inr, 2) AS operating_profit_inr,
    ROUND(((ms.charging_revenue_inr - mc.total_opex_inr) / ms.charging_revenue_inr) * 100, 2) AS operating_profit_margin_pct
FROM MonthlySessions ms
JOIN MonthlyCosts mc ON ms.billing_month = mc.cost_month;
