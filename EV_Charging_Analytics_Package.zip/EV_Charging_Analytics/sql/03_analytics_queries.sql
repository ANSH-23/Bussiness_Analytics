-- =============================================================================
-- EV Charging Station Analytics & Profitability Optimization
-- Script 03: Analytical Business Queries (20+ Documented SQL Queries)
-- Target RDBMS: MySQL 8.0 Community Server
-- Author: Senior Data Analytics Engineer
-- Description:
--   Comprehensive suite of 20 production-grade analytical SQL queries designed
--   to solve core business questions across four domains:
--   - Section A: Database Overview & Scope (Queries 1-3)
--   - Section B: Demand Analytics & Temporal Dynamics (Queries 4-7)
--   - Section C: Operational Performance, Reliability & Utilization (Queries 8-14)
--   - Section D: Financial Performance, Profitability & Cost Optimization (Queries 15-20)
--   Demonstrates: CTEs, Window Functions (RANK, ROW_NUMBER, LAG, Running SUM),
--   Subqueries, Conditional Aggregation, and Multi-Table Joins.
-- =============================================================================

USE ev_charging_analytics;

-- =============================================================================
-- SECTION A: DATABASE OVERVIEW & SCOPE
-- =============================================================================

-- Query 1: Total Stations, Connectors, and Average Power Rating by Station
-- Business Purpose: Confirms asset deployment scope across Chandigarh.
SELECT 
    s.station_id,
    s.station_name,
    s.area,
    s.station_type,
    s.total_connectors,
    COUNT(c.connector_id) AS verified_connectors,
    ROUND(AVG(c.rated_power_kw), 1) AS avg_connector_power_kw,
    ROUND(SUM(c.rated_power_kw), 1) AS total_grid_capacity_kw
FROM stations s
LEFT JOIN connectors c ON s.station_id = c.station_id
GROUP BY s.station_id, s.station_name, s.area, s.station_type, s.total_connectors
ORDER BY s.station_id;

-- Query 2: Total Sessions by Status and Energy Delivery Reconciliation
-- Business Purpose: Evaluates operational completion efficiency and failed volume.
SELECT 
    session_status,
    COUNT(*) AS total_sessions,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 2) AS session_share_pct,
    ROUND(SUM(energy_delivered_kwh), 2) AS total_energy_kwh,
    ROUND(AVG(energy_delivered_kwh), 2) AS avg_energy_kwh_per_session,
    ROUND(SUM(charging_revenue_inr), 2) AS total_revenue_inr
FROM charging_sessions
GROUP BY session_status
ORDER BY total_sessions DESC;

-- Query 3: Dataset Coverage and Monthly Session Trend with Running Cumulative Volume
-- Business Purpose: Validates chronological coverage and tracks user adoption pace.
WITH MonthlyStats AS (
    SELECT 
        DATE_FORMAT(session_start, '%Y-%m') AS session_month,
        COUNT(*) AS monthly_sessions,
        ROUND(SUM(energy_delivered_kwh), 2) AS monthly_energy_kwh,
        ROUND(SUM(charging_revenue_inr), 2) AS monthly_revenue_inr
    FROM charging_sessions
    GROUP BY DATE_FORMAT(session_start, '%Y-%m')
)
SELECT 
    session_month,
    monthly_sessions,
    monthly_energy_kwh,
    monthly_revenue_inr,
    SUM(monthly_sessions) OVER (ORDER BY session_month) AS cumulative_sessions,
    SUM(monthly_revenue_inr) OVER (ORDER BY session_month) AS cumulative_revenue_inr
FROM MonthlyStats
ORDER BY session_month;


-- =============================================================================
-- SECTION B: DEMAND ANALYTICS & TEMPORAL DYNAMICS
-- =============================================================================

-- Query 4: Hourly Charging Demand Profile & Commuter Peak Identification
-- Business Purpose: Uncovers diurnal traffic patterns to optimize dynamic pricing and grid draw.
SELECT 
    HOUR(session_start) AS hour_of_day,
    CASE 
        WHEN HOUR(session_start) BETWEEN 8 AND 11 THEN 'Morning Peak (08:00 - 11:00)'
        WHEN HOUR(session_start) BETWEEN 17 AND 21 THEN 'Evening Peak (17:00 - 21:00)'
        WHEN HOUR(session_start) BETWEEN 12 AND 16 THEN 'Midday Regular (12:00 - 16:00)'
        ELSE 'Off-Peak / Night (22:00 - 07:00)'
    END AS time_window,
    COUNT(*) AS total_sessions,
    ROUND(SUM(energy_delivered_kwh), 2) AS total_energy_kwh,
    ROUND(AVG(energy_delivered_kwh), 2) AS avg_energy_per_session_kwh,
    ROUND(SUM(charging_revenue_inr), 2) AS total_revenue_inr
FROM charging_sessions
GROUP BY HOUR(session_start), time_window
ORDER BY hour_of_day;

-- Query 5: Weekday versus Weekend Demand & Revenue Comparison
-- Business Purpose: Determines behavioral differences between corporate commuters and weekend retail shoppers.
SELECT 
    day_type,
    COUNT(*) AS total_sessions,
    ROUND(COUNT(*) / COUNT(DISTINCT DATE(session_start)), 1) AS avg_sessions_per_day,
    ROUND(SUM(energy_delivered_kwh), 2) AS total_energy_kwh,
    ROUND(AVG(energy_delivered_kwh), 2) AS avg_energy_per_session_kwh,
    ROUND(SUM(charging_revenue_inr), 2) AS total_revenue_inr,
    ROUND(AVG(charging_duration_minutes), 1) AS avg_duration_minutes
FROM charging_sessions
WHERE session_status = 'Completed'
GROUP BY day_type;

-- Query 6: Monthly Energy Consumption and Revenue Growth using LAG()
-- Business Purpose: Quantifies month-over-month (MoM) growth trajectory in power throughput.
WITH MonthlyAgg AS (
    SELECT 
        DATE_FORMAT(session_start, '%Y-%m') AS billing_month,
        ROUND(SUM(energy_delivered_kwh), 2) AS total_kwh,
        ROUND(SUM(charging_revenue_inr), 2) AS total_revenue
    FROM charging_sessions
    WHERE session_status = 'Completed'
    GROUP BY DATE_FORMAT(session_start, '%Y-%m')
)
SELECT 
    billing_month,
    total_kwh,
    ROUND(LAG(total_kwh, 1) OVER (ORDER BY billing_month), 2) AS prev_month_kwh,
    ROUND(((total_kwh - LAG(total_kwh, 1) OVER (ORDER BY billing_month)) / 
           LAG(total_kwh, 1) OVER (ORDER BY billing_month)) * 100, 2) AS kwh_growth_pct,
    total_revenue,
    ROUND(((total_revenue - LAG(total_revenue, 1) OVER (ORDER BY billing_month)) / 
           LAG(total_revenue, 1) OVER (ORDER BY billing_month)) * 100, 2) AS revenue_growth_pct
FROM MonthlyAgg
ORDER BY billing_month;

-- Query 7: Station-Level Demand Comparison & Energy Market Share
-- Business Purpose: Ranks stations by session volume and overall energy distribution share.
SELECT 
    s.station_id,
    s.station_name,
    s.area,
    COUNT(cs.session_id) AS total_sessions,
    ROUND(COUNT(cs.session_id) * 100.0 / (SELECT COUNT(*) FROM charging_sessions), 2) AS session_share_pct,
    ROUND(SUM(cs.energy_delivered_kwh), 2) AS total_energy_kwh,
    ROUND(SUM(cs.energy_delivered_kwh) * 100.0 / (SELECT SUM(energy_delivered_kwh) FROM charging_sessions), 2) AS energy_share_pct,
    DENSE_RANK() OVER (ORDER BY SUM(cs.energy_delivered_kwh) DESC) AS rank_by_energy
FROM stations s
JOIN charging_sessions cs ON s.station_id = cs.station_id
GROUP BY s.station_id, s.station_name, s.area
ORDER BY rank_by_energy;


-- =============================================================================
-- SECTION C: OPERATIONAL PERFORMANCE, RELIABILITY & UTILIZATION
-- =============================================================================

-- Query 8: Connector Utilization Analysis (Active Minutes vs Operating Capacity)
-- Business Purpose: Identifies individual connector utilization across the 182-day operating window.
WITH ConnectorActiveTime AS (
    SELECT 
        connector_id,
        station_id,
        SUM(charging_duration_minutes) AS total_charging_minutes,
        COUNT(session_id) AS session_count
    FROM charging_sessions
    WHERE session_status = 'Completed'
    GROUP BY connector_id, station_id
)
SELECT 
    c.connector_id,
    s.station_name,
    c.connector_type,
    c.rated_power_kw,
    COALESCE(cat.session_count, 0) AS completed_sessions,
    COALESCE(cat.total_charging_minutes, 0) AS active_charging_minutes,
    (s.operating_hours_per_day * 60 * 182) AS total_available_minutes,
    ROUND(COALESCE(cat.total_charging_minutes, 0) * 100.0 / (s.operating_hours_per_day * 60 * 182), 2) AS utilization_pct
FROM connectors c
JOIN stations s ON c.station_id = s.station_id
LEFT JOIN ConnectorActiveTime cat ON c.connector_id = cat.connector_id
ORDER BY utilization_pct DESC;

-- Query 9: Station Utilization Ranking (Aggregated Capacity vs Consumption)
-- Business Purpose: Ranks overall stations by network asset utilization efficiency.
SELECT 
    s.station_id,
    s.station_name,
    s.station_type,
    s.total_connectors,
    SUM(cs.charging_duration_minutes) AS station_active_minutes,
    (s.total_connectors * s.operating_hours_per_day * 60 * 182) AS station_available_minutes,
    ROUND(SUM(cs.charging_duration_minutes) * 100.0 / 
          (s.total_connectors * s.operating_hours_per_day * 60 * 182), 2) AS station_utilization_pct,
    DENSE_RANK() OVER (ORDER BY SUM(cs.charging_duration_minutes) * 100.0 / 
                       (s.total_connectors * s.operating_hours_per_day * 60 * 182) DESC) AS utilization_rank
FROM stations s
JOIN charging_sessions cs ON s.station_id = cs.station_id
WHERE cs.session_status = 'Completed'
GROUP BY s.station_id, s.station_name, s.station_type, s.total_connectors, s.operating_hours_per_day
ORDER BY utilization_rank;

-- Query 10: Average Charging and Idle Duration by Connector Type
-- Business Purpose: Uncovers parking dwell time / connector squatting across charger speeds.
SELECT 
    c.connector_type,
    ROUND(AVG(c.rated_power_kw), 1) AS avg_power_kw,
    COUNT(cs.session_id) AS completed_sessions,
    ROUND(AVG(cs.charging_duration_minutes), 1) AS avg_active_charging_minutes,
    ROUND(AVG(cs.idle_duration_minutes), 1) AS avg_idle_minutes,
    ROUND(AVG(cs.charging_duration_minutes + cs.idle_duration_minutes), 1) AS avg_total_plugged_minutes,
    ROUND(SUM(cs.idle_duration_minutes) * 100.0 / 
          SUM(cs.charging_duration_minutes + cs.idle_duration_minutes), 2) AS idle_time_ratio_pct
FROM connectors c
JOIN charging_sessions cs ON c.connector_id = cs.connector_id
WHERE cs.session_status = 'Completed'
GROUP BY c.connector_type
ORDER BY avg_power_kw DESC;

-- Query 11: Failed and Cancelled Session Rates by Station
-- Business Purpose: Detects unreliable locations requiring hardware audits or power stability checks.
SELECT 
    s.station_id,
    s.station_name,
    COUNT(cs.session_id) AS total_attempts,
    SUM(CASE WHEN cs.session_status = 'Completed' THEN 1 ELSE 0 END) AS completed_sessions,
    SUM(CASE WHEN cs.session_status = 'Failed' THEN 1 ELSE 0 END) AS failed_sessions,
    SUM(CASE WHEN cs.session_status = 'Cancelled' THEN 1 ELSE 0 END) AS cancelled_sessions,
    ROUND(SUM(CASE WHEN cs.session_status = 'Failed' THEN 1 ELSE 0 END) * 100.0 / COUNT(cs.session_id), 2) AS failure_rate_pct,
    ROUND(SUM(CASE WHEN cs.session_status = 'Completed' THEN 1 ELSE 0 END) * 100.0 / COUNT(cs.session_id), 2) AS success_rate_pct
FROM stations s
JOIN charging_sessions cs ON s.station_id = cs.station_id
GROUP BY s.station_id, s.station_name
ORDER BY failure_rate_pct DESC;

-- Query 12: Downtime Analysis by Station and Root Cause
-- Business Purpose: Analyzes outage duration and financial repair costs by failure reason.
SELECT 
    s.station_id,
    s.station_name,
    sd.downtime_reason,
    sd.maintenance_type,
    COUNT(sd.downtime_id) AS outage_events,
    SUM(sd.downtime_duration_minutes) AS total_downtime_minutes,
    ROUND(SUM(sd.downtime_duration_minutes) / 60.0, 1) AS total_downtime_hours,
    ROUND(SUM(sd.maintenance_cost_inr), 2) AS total_repair_cost_inr
FROM stations s
JOIN station_downtime sd ON s.station_id = sd.station_id
GROUP BY s.station_id, s.station_name, sd.downtime_reason, sd.maintenance_type
ORDER BY s.station_id, total_downtime_minutes DESC;

-- Query 13: Peak Hourly Charging Window per Station (Top Hour Identification via Window Functions)
-- Business Purpose: Finds the absolute busiest single hour for each station.
WITH StationHourlyDemand AS (
    SELECT 
        station_id,
        HOUR(session_start) AS hour_of_day,
        COUNT(*) AS sessions_in_hour,
        ROW_NUMBER() OVER (PARTITION BY station_id ORDER BY COUNT(*) DESC) AS rnk
    FROM charging_sessions
    GROUP BY station_id, HOUR(session_start)
)
SELECT 
    s.station_id,
    s.station_name,
    shd.hour_of_day AS peak_hour,
    CONCAT(LPAD(shd.hour_of_day, 2, '0'), ':00 - ', LPAD(shd.hour_of_day + 1, 2, '0'), ':00') AS peak_time_range,
    shd.sessions_in_hour AS peak_session_volume
FROM StationHourlyDemand shd
JOIN stations s ON shd.station_id = s.station_id
WHERE shd.rnk = 1
ORDER BY peak_session_volume DESC;

-- Query 14: Connector Type Performance, Throughput, and Gross Yield
-- Business Purpose: Evaluates capital asset ROI by hardware specification.
SELECT 
    c.connector_type,
    COUNT(DISTINCT c.connector_id) AS active_ports,
    COUNT(cs.session_id) AS completed_sessions,
    ROUND(SUM(cs.energy_delivered_kwh), 2) AS total_energy_kwh,
    ROUND(SUM(cs.charging_revenue_inr), 2) AS total_revenue_inr,
    ROUND(SUM(cs.charging_revenue_inr) / COUNT(DISTINCT c.connector_id), 2) AS revenue_per_port_inr,
    ROUND(SUM(cs.charging_revenue_inr) / NULLIF(SUM(cs.energy_delivered_kwh), 0), 2) AS realized_tariff_per_kwh
FROM connectors c
LEFT JOIN charging_sessions cs ON c.connector_id = cs.connector_id AND cs.session_status = 'Completed'
GROUP BY c.connector_type
ORDER BY total_revenue_inr DESC;


-- =============================================================================
-- SECTION D: FINANCIAL PERFORMANCE, PROFITABILITY & COST OPTIMIZATION
-- =============================================================================

-- Query 15: Charging Revenue, Volume, and Average Ticket Size by Station
-- Business Purpose: Benchmarks top-line cash generation across network nodes.
SELECT 
    s.station_id,
    s.station_name,
    s.area,
    COUNT(cs.session_id) AS total_completed_sessions,
    ROUND(SUM(cs.energy_delivered_kwh), 2) AS total_kwh_sold,
    ROUND(SUM(cs.charging_revenue_inr), 2) AS gross_charging_revenue_inr,
    ROUND(AVG(cs.charging_revenue_inr), 2) AS avg_revenue_per_session_inr,
    DENSE_RANK() OVER (ORDER BY SUM(cs.charging_revenue_inr) DESC) AS revenue_rank
FROM stations s
JOIN charging_sessions cs ON s.station_id = cs.station_id
WHERE cs.session_status = 'Completed'
GROUP BY s.station_id, s.station_name, s.area
ORDER BY revenue_rank;

-- Query 16: Electricity Procurement Cost Reconciliation by Station
-- Business Purpose: Validates variable COGS (electricity supply) and unit energy cost.
SELECT 
    s.station_id,
    s.station_name,
    ROUND(SUM(cs.energy_delivered_kwh), 2) AS total_energy_kwh,
    ROUND(SUM(cs.energy_delivered_kwh * cs.electricity_tariff_per_kwh_inr), 2) AS session_elec_cost_inr,
    ROUND(doc.total_daily_elec_cost_inr, 2) AS daily_table_elec_cost_inr,
    ROUND(ABS(SUM(cs.energy_delivered_kwh * cs.electricity_tariff_per_kwh_inr) - doc.total_daily_elec_cost_inr), 2) AS variance_inr
FROM stations s
JOIN charging_sessions cs ON s.station_id = cs.station_id
JOIN (
    SELECT station_id, SUM(electricity_cost_inr) AS total_daily_elec_cost_inr
    FROM daily_station_operating_costs
    GROUP BY station_id
) doc ON s.station_id = doc.station_id
GROUP BY s.station_id, s.station_name, doc.total_daily_elec_cost_inr
ORDER BY s.station_id;

-- Query 17: Gross Energy Contribution (Revenue minus Direct Electricity Cost)
-- Business Purpose: Calculates gross energy margin before station overheads.
SELECT 
    s.station_id,
    s.station_name,
    ROUND(SUM(cs.charging_revenue_inr), 2) AS revenue_inr,
    ROUND(SUM(cs.energy_delivered_kwh * cs.electricity_tariff_per_kwh_inr), 2) AS electricity_cogs_inr,
    ROUND(SUM(cs.charging_revenue_inr) - SUM(cs.energy_delivered_kwh * cs.electricity_tariff_per_kwh_inr), 2) AS gross_contribution_inr,
    ROUND(((SUM(cs.charging_revenue_inr) - SUM(cs.energy_delivered_kwh * cs.electricity_tariff_per_kwh_inr)) / 
           SUM(cs.charging_revenue_inr)) * 100, 2) AS gross_margin_pct
FROM stations s
JOIN charging_sessions cs ON s.station_id = cs.station_id
GROUP BY s.station_id, s.station_name
ORDER BY gross_contribution_inr DESC;

-- Query 18: Comprehensive Operating Profit after Fixed & Variable Expenses
-- Business Purpose: Computes bottom-line network profitability taking into account rent, staff, and upkeep.
WITH StationRevenues AS (
    SELECT 
        station_id,
        ROUND(SUM(charging_revenue_inr), 2) AS total_revenue
    FROM charging_sessions
    GROUP BY station_id
),
StationExpenses AS (
    SELECT 
        station_id,
        ROUND(SUM(electricity_cost_inr), 2) AS total_elec,
        ROUND(SUM(staff_cost_inr), 2) AS total_staff,
        ROUND(SUM(rent_cost_inr), 2) AS total_rent,
        ROUND(SUM(maintenance_cost_inr), 2) AS total_maint,
        ROUND(SUM(other_operating_cost_inr), 2) AS total_other,
        ROUND(SUM(electricity_cost_inr + staff_cost_inr + rent_cost_inr + maintenance_cost_inr + other_operating_cost_inr), 2) AS total_opex
    FROM daily_station_operating_costs
    GROUP BY station_id
)
SELECT 
    s.station_id,
    s.station_name,
    s.station_type,
    sr.total_revenue AS revenue_inr,
    se.total_elec AS electricity_cost_inr,
    se.total_staff AS staff_cost_inr,
    se.total_rent AS rent_cost_inr,
    se.total_maint AS maintenance_cost_inr,
    se.total_other AS other_expenses_inr,
    se.total_opex AS total_operating_costs_inr,
    ROUND(sr.total_revenue - se.total_opex, 2) AS operating_profit_inr,
    ROUND(((sr.total_revenue - se.total_opex) / sr.total_revenue) * 100, 2) AS operating_profit_margin_pct,
    DENSE_RANK() OVER (ORDER BY (sr.total_revenue - se.total_opex) DESC) AS profitability_rank
FROM stations s
JOIN StationRevenues sr ON s.station_id = sr.station_id
JOIN StationExpenses se ON s.station_id = se.station_id
ORDER BY profitability_rank;

-- Query 19: Monthly Financial Trajectory & Profit Trends
-- Business Purpose: Evaluates financial stability and operational leverage over time.
SELECT 
    DATE_FORMAT(c.operating_date, '%Y-%m') AS financial_month,
    ROUND(SUM(s_rev.month_revenue), 2) AS charging_revenue_inr,
    ROUND(SUM(c.electricity_cost_inr), 2) AS electricity_cost_inr,
    ROUND(SUM(c.staff_cost_inr + c.rent_cost_inr + c.maintenance_cost_inr + c.other_operating_cost_inr), 2) AS fixed_opex_inr,
    ROUND(SUM(c.electricity_cost_inr + c.staff_cost_inr + c.rent_cost_inr + c.maintenance_cost_inr + c.other_operating_cost_inr), 2) AS total_costs_inr,
    ROUND(SUM(s_rev.month_revenue) - 
          SUM(c.electricity_cost_inr + c.staff_cost_inr + c.rent_cost_inr + c.maintenance_cost_inr + c.other_operating_cost_inr), 2) AS operating_profit_inr
FROM daily_station_operating_costs c
JOIN (
    SELECT 
        station_id, 
        DATE(session_start) AS op_date, 
        SUM(charging_revenue_inr) AS month_revenue
    FROM charging_sessions
    GROUP BY station_id, DATE(session_start)
) s_rev ON c.station_id = s_rev.station_id AND c.operating_date = s_rev.op_date
GROUP BY DATE_FORMAT(c.operating_date, '%Y-%m')
ORDER BY financial_month;

-- Query 20: Cost-Versus-Utilization Optimization Matrix (High Cost vs Low Utilization Audit)
-- Business Purpose: Flags underperforming stations burdened with disproportionate overhead.
WITH StationMetrics AS (
    SELECT 
        s.station_id,
        s.station_name,
        s.area,
        s.station_type,
        ROUND(SUM(cs.charging_duration_minutes) * 100.0 / 
              (s.total_connectors * s.operating_hours_per_day * 60 * 182), 2) AS utilization_pct,
        ROUND(SUM(cs.charging_revenue_inr), 2) AS revenue_inr,
        doc.total_opex_inr,
        ROUND(SUM(cs.charging_revenue_inr) - doc.total_opex_inr, 2) AS operating_profit_inr
    FROM stations s
    JOIN charging_sessions cs ON s.station_id = cs.station_id AND cs.session_status = 'Completed'
    JOIN (
        SELECT station_id, SUM(electricity_cost_inr + staff_cost_inr + rent_cost_inr + maintenance_cost_inr + other_operating_cost_inr) AS total_opex_inr
        FROM daily_station_operating_costs
        GROUP BY station_id
    ) doc ON s.station_id = doc.station_id
    GROUP BY s.station_id, s.station_name, s.area, s.station_type, s.total_connectors, s.operating_hours_per_day, doc.total_opex_inr
)
SELECT 
    station_id,
    station_name,
    station_type,
    utilization_pct,
    total_opex_inr,
    revenue_inr,
    operating_profit_inr,
    CASE 
        WHEN utilization_pct < 12.0 AND operating_profit_inr < 0 THEN 'Critical: High Cost, Low Utilization (Loss-Making)'
        WHEN utilization_pct < 12.0 AND operating_profit_inr >= 0 THEN 'Moderate: Underutilized but Marginally Viable'
        WHEN utilization_pct >= 12.0 AND operating_profit_inr > 100000 THEN 'Star Performer: High Utilization & Profit'
        ELSE 'Balanced: Healthy Operational Profile'
    END AS strategic_quadrant
FROM StationMetrics
ORDER BY operating_profit_inr DESC;
