-- =============================================================================
-- EV Charging Station Analytics & Profitability Optimization
-- Script 02: Data Ingestion Script & Instructions
-- Target RDBMS: MySQL 8.0 Community Server
-- Author: Senior MySQL Database Engineer
-- Description:
--   Provides tested LOAD DATA LOCAL INFILE commands and step-by-step execution
--   instructions for ingesting all raw CSV datasets into MySQL.
-- =============================================================================

USE ev_charging_analytics;

-- =============================================================================
-- PREREQUISITES FOR LOCAL INFILE IN MYSQL 8.0:
-- By default, MySQL 8.0 disables local file loading for security.
-- To enable it in MySQL Command Line Client:
-- 1. Run in MySQL Server:
--    SET GLOBAL local_infile = 1;
-- 2. Launch your MySQL client with local infile enabled:
--    mysql --local-infile=1 -u root -p
-- =============================================================================

SET GLOBAL local_infile = 1;

-- -----------------------------------------------------------------------------
-- 1. INGEST STATIONS
-- -----------------------------------------------------------------------------
-- Adjust the file path to point to your local data/raw directory:
-- Example Windows path: 'C:/Users/ansht/Desktop/Sem 3/Bussiness Analytics/EV_Charging_Analytics/data/raw/stations.csv'
LOAD DATA LOCAL INFILE 'data/raw/stations.csv'
INTO TABLE stations
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES
(station_id, station_name, city, area, latitude, longitude, installation_date, 
 total_connectors, station_type, monthly_rent_inr, maintenance_cost_monthly_inr, operating_hours_per_day);

-- -----------------------------------------------------------------------------
-- 2. INGEST CONNECTORS
-- -----------------------------------------------------------------------------
LOAD DATA LOCAL INFILE 'data/raw/connectors.csv'
INTO TABLE connectors
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES
(connector_id, station_id, connector_type, rated_power_kw, installation_date, 
 connector_status, electricity_tariff_per_kwh_inr);

-- -----------------------------------------------------------------------------
-- 3. INGEST TARIFF HISTORY
-- -----------------------------------------------------------------------------
LOAD DATA LOCAL INFILE 'data/raw/tariff_history.csv'
INTO TABLE tariff_history
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES
(tariff_id, connector_id, @eff_from, @eff_to, electricity_tariff_per_kwh_inr, customer_price_per_kwh_inr)
SET 
  effective_from = STR_TO_DATE(@eff_from, '%Y-%m-%d %H:%i:%s'),
  effective_to = STR_TO_DATE(@eff_to, '%Y-%m-%d %H:%i:%s');

-- -----------------------------------------------------------------------------
-- 4. INGEST CHARGING SESSIONS
-- -----------------------------------------------------------------------------
LOAD DATA LOCAL INFILE 'data/raw/charging_sessions.csv'
INTO TABLE charging_sessions
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES
(session_id, connector_id, station_id, vehicle_id, @s_start, @s_end, 
 energy_delivered_kwh, charging_duration_minutes, idle_duration_minutes, 
 electricity_tariff_per_kwh_inr, charging_revenue_inr, 
 session_status, payment_status, day_type, weather_condition)
SET 
  session_start = STR_TO_DATE(@s_start, '%Y-%m-%d %H:%i:%s'),
  session_end = STR_TO_DATE(@s_end, '%Y-%m-%d %H:%i:%s');

-- -----------------------------------------------------------------------------
-- 5. INGEST STATION DOWNTIME
-- -----------------------------------------------------------------------------
LOAD DATA LOCAL INFILE 'data/raw/station_downtime.csv'
INTO TABLE station_downtime
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES
(downtime_id, connector_id, station_id, @dt_start, @dt_end, 
 downtime_duration_minutes, downtime_reason, maintenance_type, maintenance_cost_inr)
SET 
  downtime_start = STR_TO_DATE(@dt_start, '%Y-%m-%d %H:%i:%s'),
  downtime_end = STR_TO_DATE(@dt_end, '%Y-%m-%d %H:%i:%s');

-- -----------------------------------------------------------------------------
-- 6. INGEST DAILY STATION OPERATING COSTS
-- -----------------------------------------------------------------------------
LOAD DATA LOCAL INFILE 'data/raw/daily_station_operating_costs.csv'
INTO TABLE daily_station_operating_costs
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'
IGNORE 1 LINES
(record_id, station_id, operating_date, electricity_cost_inr, staff_cost_inr, 
 rent_cost_inr, maintenance_cost_inr, other_operating_cost_inr);

-- =============================================================================
-- VERIFY ROW COUNTS AFTER INGESTION
-- =============================================================================
SELECT 'stations' AS table_name, COUNT(*) AS row_count FROM stations
UNION ALL
SELECT 'connectors', COUNT(*) FROM connectors
UNION ALL
SELECT 'tariff_history', COUNT(*) FROM tariff_history
UNION ALL
SELECT 'charging_sessions', COUNT(*) FROM charging_sessions
UNION ALL
SELECT 'station_downtime', COUNT(*) FROM station_downtime
UNION ALL
SELECT 'daily_station_operating_costs', COUNT(*) FROM daily_station_operating_costs;
