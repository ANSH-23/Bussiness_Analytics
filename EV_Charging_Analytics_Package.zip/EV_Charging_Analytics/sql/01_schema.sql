-- =============================================================================
-- EV Charging Station Analytics & Profitability Optimization
-- Script 01: Relational Schema DDL
-- Target RDBMS: MySQL 8.0 Community Server (InnoDB Storage Engine)
-- Author: Senior MySQL Database Engineer
-- Description:
--   Creates the normalized database schema 'ev_charging_analytics' with strict
--   primary keys, foreign keys, CHECK constraints, UNIQUE constraints, and indexes.
-- =============================================================================

-- Step 1: Create Database
CREATE DATABASE IF NOT EXISTS ev_charging_analytics
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE ev_charging_analytics;

-- Step 2: Drop existing tables in reverse dependency order (safe for re-execution)
DROP TABLE IF EXISTS daily_station_operating_costs;
DROP TABLE IF EXISTS station_downtime;
DROP TABLE IF EXISTS charging_sessions;
DROP TABLE IF EXISTS tariff_history;
DROP TABLE IF EXISTS connectors;
DROP TABLE IF EXISTS stations;

-- =============================================================================
-- Table 1: stations
-- Master entity representing the 10 physical charging stations in Chandigarh.
-- =============================================================================
CREATE TABLE stations (
    station_id VARCHAR(10) NOT NULL,
    station_name VARCHAR(100) NOT NULL,
    city VARCHAR(50) NOT NULL DEFAULT 'Chandigarh',
    area VARCHAR(50) NOT NULL,
    latitude DECIMAL(9, 6) NOT NULL,
    longitude DECIMAL(9, 6) NOT NULL,
    installation_date DATE NOT NULL,
    total_connectors INT NOT NULL,
    station_type VARCHAR(50) NOT NULL,
    monthly_rent_inr DECIMAL(12, 2) NOT NULL,
    maintenance_cost_monthly_inr DECIMAL(12, 2) NOT NULL,
    operating_hours_per_day INT NOT NULL DEFAULT 24,

    CONSTRAINT pk_stations PRIMARY KEY (station_id),
    CONSTRAINT chk_total_connectors CHECK (total_connectors > 0),
    CONSTRAINT chk_operating_hours CHECK (operating_hours_per_day BETWEEN 1 AND 24),
    CONSTRAINT chk_station_rent CHECK (monthly_rent_inr >= 0),
    CONSTRAINT chk_station_maint CHECK (maintenance_cost_monthly_inr >= 0)
) ENGINE=InnoDB;

-- =============================================================================
-- Table 2: connectors
-- Connectors installed across stations (50 connectors total).
-- =============================================================================
CREATE TABLE connectors (
    connector_id VARCHAR(10) NOT NULL,
    station_id VARCHAR(10) NOT NULL,
    connector_type VARCHAR(30) NOT NULL,
    rated_power_kw DECIMAL(6, 2) NOT NULL,
    installation_date DATE NOT NULL,
    connector_status VARCHAR(20) NOT NULL DEFAULT 'Operational',
    electricity_tariff_per_kwh_inr DECIMAL(8, 2) NOT NULL,

    CONSTRAINT pk_connectors PRIMARY KEY (connector_id),
    CONSTRAINT fk_connectors_station FOREIGN KEY (station_id) 
        REFERENCES stations (station_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_rated_power CHECK (rated_power_kw > 0),
    CONSTRAINT chk_elec_tariff CHECK (electricity_tariff_per_kwh_inr > 0)
) ENGINE=InnoDB;

-- Index on station_id for fast join lookups
CREATE INDEX idx_connectors_station ON connectors (station_id);
CREATE INDEX idx_connectors_type ON connectors (connector_type);

-- =============================================================================
-- Table 3: tariff_history
-- Historical pricing and procurement tariffs by connector over time.
-- =============================================================================
CREATE TABLE tariff_history (
    tariff_id VARCHAR(15) NOT NULL,
    connector_id VARCHAR(10) NOT NULL,
    effective_from DATETIME NOT NULL,
    effective_to DATETIME NOT NULL,
    electricity_tariff_per_kwh_inr DECIMAL(8, 2) NOT NULL,
    customer_price_per_kwh_inr DECIMAL(8, 2) NOT NULL,

    CONSTRAINT pk_tariff_history PRIMARY KEY (tariff_id),
    CONSTRAINT fk_tariff_connector FOREIGN KEY (connector_id) 
        REFERENCES connectors (connector_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_tariff_dates CHECK (effective_to > effective_from),
    CONSTRAINT chk_cust_price CHECK (customer_price_per_kwh_inr >= electricity_tariff_per_kwh_inr)
) ENGINE=InnoDB;

CREATE INDEX idx_tariff_connector_dates ON tariff_history (connector_id, effective_from, effective_to);

-- =============================================================================
-- Table 4: charging_sessions
-- Individual charging sessions (>11,000 records).
-- =============================================================================
CREATE TABLE charging_sessions (
    session_id VARCHAR(20) NOT NULL,
    connector_id VARCHAR(10) NOT NULL,
    station_id VARCHAR(10) NOT NULL,
    vehicle_id VARCHAR(30) NOT NULL,
    session_start DATETIME NOT NULL,
    session_end DATETIME NOT NULL,
    energy_delivered_kwh DECIMAL(8, 2) NOT NULL DEFAULT 0.00,
    charging_duration_minutes INT NOT NULL DEFAULT 0,
    idle_duration_minutes INT NOT NULL DEFAULT 0,
    electricity_tariff_per_kwh_inr DECIMAL(8, 2) NOT NULL,
    charging_revenue_inr DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    customer_price_per_kwh_inr DECIMAL(8, 2) GENERATED ALWAYS AS (CASE WHEN energy_delivered_kwh > 0 THEN ROUND(charging_revenue_inr / energy_delivered_kwh, 2) ELSE 0.00 END) STORED,
    session_status VARCHAR(20) NOT NULL,
    payment_status VARCHAR(20) NOT NULL,
    day_type VARCHAR(15) NOT NULL,
    weather_condition VARCHAR(30) NOT NULL,

    CONSTRAINT pk_charging_sessions PRIMARY KEY (session_id),
    CONSTRAINT fk_sessions_connector FOREIGN KEY (connector_id) 
        REFERENCES connectors (connector_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_sessions_station FOREIGN KEY (station_id) 
        REFERENCES stations (station_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_session_times CHECK (session_end > session_start),
    CONSTRAINT chk_session_energy CHECK (energy_delivered_kwh >= 0),
    CONSTRAINT chk_charging_duration CHECK (charging_duration_minutes >= 0),
    CONSTRAINT chk_idle_duration CHECK (idle_duration_minutes >= 0),
    CONSTRAINT chk_session_revenue CHECK (charging_revenue_inr >= 0),
    CONSTRAINT chk_session_status CHECK (session_status IN ('Completed', 'Failed', 'Cancelled'))
) ENGINE=InnoDB;

-- Indexes for analytical query optimization
CREATE INDEX idx_sessions_station ON charging_sessions (station_id);
CREATE INDEX idx_sessions_connector ON charging_sessions (connector_id);
CREATE INDEX idx_sessions_start ON charging_sessions (session_start);
CREATE INDEX idx_sessions_status ON charging_sessions (session_status);
CREATE INDEX idx_sessions_st_date ON charging_sessions (station_id, session_start);

-- =============================================================================
-- Table 5: station_downtime
-- Connector-level outage and maintenance events.
-- =============================================================================
CREATE TABLE station_downtime (
    downtime_id VARCHAR(20) NOT NULL,
    connector_id VARCHAR(10) NOT NULL,
    station_id VARCHAR(10) NOT NULL,
    downtime_start DATETIME NOT NULL,
    downtime_end DATETIME NOT NULL,
    downtime_duration_minutes INT NOT NULL,
    downtime_reason VARCHAR(100) NOT NULL,
    maintenance_type VARCHAR(30) NOT NULL,
    maintenance_cost_inr DECIMAL(10, 2) NOT NULL DEFAULT 0.00,

    CONSTRAINT pk_station_downtime PRIMARY KEY (downtime_id),
    CONSTRAINT fk_downtime_connector FOREIGN KEY (connector_id) 
        REFERENCES connectors (connector_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_downtime_station FOREIGN KEY (station_id) 
        REFERENCES stations (station_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT chk_downtime_times CHECK (downtime_end > downtime_start),
    CONSTRAINT chk_downtime_duration CHECK (downtime_duration_minutes > 0),
    CONSTRAINT chk_downtime_cost CHECK (maintenance_cost_inr >= 0)
) ENGINE=InnoDB;

CREATE INDEX idx_downtime_connector ON station_downtime (connector_id);
CREATE INDEX idx_downtime_station ON station_downtime (station_id);
CREATE INDEX idx_downtime_start ON station_downtime (downtime_start);

-- =============================================================================
-- Table 6: daily_station_operating_costs
-- Daily operational expenses allocated per station (1,820 records).
-- =============================================================================
CREATE TABLE daily_station_operating_costs (
    record_id VARCHAR(20) NOT NULL,
    station_id VARCHAR(10) NOT NULL,
    operating_date DATE NOT NULL,
    electricity_cost_inr DECIMAL(10, 2) NOT NULL,
    staff_cost_inr DECIMAL(10, 2) NOT NULL,
    rent_cost_inr DECIMAL(10, 2) NOT NULL,
    maintenance_cost_inr DECIMAL(10, 2) NOT NULL,
    other_operating_cost_inr DECIMAL(10, 2) NOT NULL,

    CONSTRAINT pk_daily_costs PRIMARY KEY (record_id),
    CONSTRAINT fk_daily_costs_station FOREIGN KEY (station_id) 
        REFERENCES stations (station_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT uq_station_date UNIQUE (station_id, operating_date),
    CONSTRAINT chk_daily_elec CHECK (electricity_cost_inr >= 0),
    CONSTRAINT chk_daily_staff CHECK (staff_cost_inr >= 0),
    CONSTRAINT chk_daily_rent CHECK (rent_cost_inr >= 0),
    CONSTRAINT chk_daily_maint CHECK (maintenance_cost_inr >= 0),
    CONSTRAINT chk_daily_other CHECK (other_operating_cost_inr >= 0)
) ENGINE=InnoDB;

CREATE INDEX idx_daily_costs_date ON daily_station_operating_costs (operating_date);
CREATE INDEX idx_daily_costs_station_date ON daily_station_operating_costs (station_id, operating_date);
