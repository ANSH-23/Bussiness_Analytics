# EV Charging Station Analytics & Profitability Optimization
### Using Python, MySQL 8.0, Microsoft Excel, and Tableau

[![Python 3.13](https://img.shields.io/badge/Python-3.13.5-blue.svg)](https://www.python.org/)
[![MySQL 8.0](https://img.shields.io/badge/MySQL-8.0_Community-orange.svg)](https://www.mysql.com/)
[![Excel 2024](https://img.shields.io/badge/Microsoft_Excel-2024_LTSC-green.svg)](https://www.office.com/)
[![Tableau Ready](https://img.shields.io/badge/Tableau-Desktop_%26_Public-brightgreen.svg)](https://public.tableau.com/)
[![Tests Passing](https://img.shields.io/badge/Pytest-14_Passed_100%25-success.svg)](tests/)

---

## 1. Project Overview

This repository contains an end-to-end, production-ready Business Analytics & Data Engineering capstone project designed for Master of Computer Applications (MCA) academic submission, practical laboratory demonstrations, resume portfolio development, and viva voce examinations.

The system analyzes the operational performance, equipment reliability, energy throughput, and financial profitability of an Electric Vehicle (EV) public charging network operating across **10 charging stations and 50 charging ports in Chandigarh, India** over a six-month operating window (**April 01, 2026 to September 30, 2026 | 183 calendar days**).

### Core Business Questions Answered:
1. Which charging stations and connectors are underutilized?
2. During which hours and days is charging demand highest?
3. Which stations generate the most revenue and bottom-line operating profit?
4. How do electricity tariffs and variable utility costs impact station margins?
5. What revenue loss and energy wastage are associated with failed sessions?
6. How does equipment downtime impact network availability and revenue?
7. Which connector standards (CCS2, Type 2 AC, CHAdeMO) deliver the highest yield?
8. How do weekdays, weekends, location type, and weather affect charging demand?
9. Which stations have high facility rents but low utilization (loss-making nodes)?
10. What operational and pricing changes optimize network profitability?

---

## 2. Technology Stack & Prerequisites

- **Operating System:** Windows 10/11 (or macOS / Linux compatible)
- **Programming Language:** Python 3.13+ (Uses Standard Library, `pandas`, `openpyxl`, `python-docx`, `pytest`)
- **Relational Database:** MySQL 8.0 Community Server & MySQL Workbench
- **Spreadsheet Modeling:** Microsoft Excel 2019 / 2021 / 2024 / Office 365
- **Business Intelligence:** Tableau Desktop 2023.x/2024.x or Tableau Public (Free)
- **Database Driver:** MySQL Connector/ODBC 8.0 (Windows 64-bit)

---

## 3. Repository Directory Structure

```text
EV_Charging_Analytics/
│
├── README.md                              <- Master project manual and execution guide
├── requirements.txt                       <- Python dependencies
├── .gitignore                             <- Git exclusion rules
│
├── src/                                   <- Python data pipeline engines
│   ├── generate_dataset.py                <- Master synthetic generator (fixed seed 42)
│   ├── validate_dataset.py                <- 34-check automated data quality auditor
│   ├── calculate_kpis.py                  <- Multi-dimensional analytical aggregations
│   ├── export_tableau_data.py             <- Optimized relational Tableau CSV exports
│   └── build_excel_model.py               <- 7-sheet dynamic financial workbook builder
│
├── data/
│   ├── raw/                               <- Authoritative synthetic CSV datasets
│   │   ├── stations.csv                   <- 10 stations master catalog (ST01..ST10)
│   │   ├── connectors.csv                 <- 50 connectors master catalog (CN001..CN050)
│   │   ├── tariff_history.csv             <- 149 historical tariff records
│   │   ├── charging_sessions.csv          <- 23,325 charging session transaction logs
│   │   ├── station_downtime.csv           <- 571 equipment outage/maintenance logs
│   │   ├── daily_station_operating_costs.csv <- 1,830 daily operating expense records
│   │   └── station_daily_kpis.csv         <- 1,830 pre-aggregated daily KPI rows
│   ├── processed/                         <- Business aggregation summaries
│   │   ├── station_summary.csv            <- Master 10-station P&L scorecard
│   │   ├── monthly_financial_summary.csv  <- 6-month financial trajectory & MoM growth
│   │   ├── connector_performance.csv      <- 50-port throughput & failure rates
│   │   ├── hourly_demand_profile.csv      <- 24-hour diurnal commuter curve
│   │   └── weather_impact_summary.csv     <- Demand & error rates under rain/storms
│   └── tableau/                           <- Clean, normalized Tableau data extracts
│       ├── tableau_stations.csv
│       ├── tableau_connectors.csv
│       ├── tableau_charging_sessions.csv
│       ├── tableau_station_downtime.csv
│       ├── tableau_daily_station_operating_costs.csv
│       └── tableau_station_daily_kpis.csv
│
├── sql/                                   <- MySQL 8.0 production SQL scripts
│   ├── 01_schema.sql                      <- Database DDL with PK, FK, CHECK, and indexes
│   ├── 02_data_ingest.sql                 <- Fast LOAD DATA LOCAL INFILE import scripts
│   ├── 03_analytics_queries.sql           <- 20+ documented queries (CTEs, Window, LAG)
│   ├── 04_analytics_views.sql             <- 5 certified reporting views
│   └── 05_data_quality_checks.sql         <- Automated SQL assertion test suite
│
├── output/                                <- Final generated academic project artifacts
│   ├── EV_Charging_Analytics_Financial_Model.xlsx <- 7-sheet live Excel financial model
│   ├── EV_Charging_Analytics_Project_Report.docx  <- Full 27-chapter academic project report
│   ├── data_quality_report.txt            <- Audit log of 34 data validation checks
│   └── data_quality_summary.csv           <- Tabular pass/fail audit scorecard
│
├── tests/                                 <- Automated QA test suite
│   └── test_data_validation.py            <- 14 Pytest unit & reconciliation tests
│
├── docs/                                  <- Technical architecture & exam documentation
│   ├── PROJECT_ARCHITECTURE.md            <- Pipeline flowchart, ERD, and ODBC guide
│   ├── DATA_DICTIONARY.md                 <- Enterprise data catalog of all entities
│   ├── TABLEAU_IMPLEMENTATION_GUIDE.md    <- Step-by-step 4-dashboard build manual
│   └── VIVA_PREPARATION.md                <- 35 in-depth viva examination Q&As
│
└── screenshots/                           <- Visual wireframes and capture instructions
    └── README.md
```

---

## 4. Quick Start & Execution Guide

### Step 1: Clone Repository & Setup Virtual Environment
Open PowerShell in the project directory:
```powershell
cd "EV_Charging_Analytics"

# Create a virtual environment (optional but recommended)
python -m venv venv
venv\Scripts\activate

# Install required Python libraries
pip install -r requirements.txt
```

### Step 2: Regenerate Datasets & Run Automated Validation
```powershell
# 1. Generate all raw CSV datasets (deterministic seed 42)
python src/generate_dataset.py

# 2. Run the 34-check automated data quality auditor
python src/validate_dataset.py

# 3. Compute processed KPI summaries
python src/calculate_kpis.py

# 4. Export clean Tableau-ready extracts
python src/export_tableau_data.py

# 5. Build the executive 7-sheet Excel financial model
python src/build_excel_model.py
```

### Step 3: Run the Pytest Test Suite
```powershell
pytest tests/test_data_validation.py -v
```
*Expected Result:* `14 passed in ~0.56s` (100% pass rate).

---

## 5. MySQL Database Setup & Execution

### Method 1: Using MySQL Workbench (GUI)
1. Open **MySQL Workbench** and connect to your local MySQL 8.0 server.
2. Open and execute `sql/01_schema.sql` (Click the Lightning icon) to create database `ev_charging_analytics` and normalized tables.
3. Ingest the datasets:
   - Either run `sql/02_data_ingest.sql` in the MySQL command line with local infile enabled.
   - Or use MySQL Workbench's **Table Data Import Wizard** (Right-click table -> *Table Data Import Wizard* -> browse to `data/raw/<table_name>.csv`).
4. Execute `sql/03_analytics_queries.sql` to run the 20 analytical queries across overview, demand, operations, and financial performance.
5. Execute `sql/04_analytics_views.sql` to build the 5 certified reporting views.
6. Execute `sql/05_data_quality_checks.sql` to run all database assertion tests.

### Method 2: Using MySQL Command Line Client
```bash
mysql -u root -p --local-infile=1

# Inside MySQL prompt:
source sql/01_schema.sql;
source sql/02_data_ingest.sql;
source sql/03_analytics_queries.sql;
source sql/04_analytics_views.sql;
source sql/05_data_quality_checks.sql;
```

---

## 6. Microsoft Excel Financial Model

Open `output/EV_Charging_Analytics_Financial_Model.xlsx` in Microsoft Excel.

### Sheet Directory:
- **Sheet 1: Read Me:** Metadata, KPI mathematical formulas, and instructions.
- **Sheet 2: Session Data:** 1,500 transaction records with dynamic formulas for durations, revenues, and gross margins.
- **Sheet 3: Station Summary:** Complete 10-station P&L scorecard with full fixed and variable expense allocations.
- **Sheet 4: Monthly Analysis:** 6-month monthly financial trajectory with live Month-over-Month (`MoM%`) growth formulas.
- **Sheet 5: Connector Analysis:** Port-level throughput, uptime, and failure rates.
- **Sheet 6: Financial Dashboard:** Executive KPI callout cards and embedded native Bar and Line charts.
- **Sheet 7: What-If Analysis:** Interactive sensitivity analysis with yellow parameter input cells. Adjust customer tariffs or demand multipliers to see real-time updates to projected operating profit!

---

## 7. Tableau Dashboard Construction

Refer to `docs/TABLEAU_IMPLEMENTATION_GUIDE.md` for full step-by-step instructions.

### Dashboards Built:
1. **Dashboard 1: Executive Overview:** High-level KPIs, monthly trajectory, and station profitability rankings.
2. **Dashboard 2: Demand & Utilization:** 24-hour diurnal commuter curves, weekday vs. weekend splits, and connector port utilization.
3. **Dashboard 3: Downtime & Reliability:** Outage duration by root cause, maintenance repair costs, and port failure rates.
4. **Dashboard 4: Financial Performance:** Strategic Quadrant Matrix (Operating Profit vs. Active Utilization Rate) to identify Star Performers, Cash Cows, and Loss-Making stations.

---

## 8. Data Validation & Reconciliation Results

The system enforces strict mathematical and relational integrity verified by `src/validate_dataset.py`:
- **Primary & Foreign Key Integrity:** 0 duplicate keys, 0 orphan records across all 6 tables.
- **Schedule Collision Audit:** 0 overlapping sessions on any connector, 0 overlapping downtime events, 0 collisions between sessions and outages.
- **Financial Cross-Reconciliation:**
  - Session Electricity Costs: **₹ 3,364,115.95**
  - Daily Table Electricity Costs: **₹ 3,364,120.15**
  - Variance: **₹ 4.20** (pure rounding difference across 23,325 records and 1,830 daily aggregations).
- **Monthly Rent Allocation:** Allocated daily rent reconciles exactly to stated monthly rent for every calendar month (0 mismatches).
- **Port Utilization:** Strictly bounded between $0.00\%$ and $100.00\%$ (Average active utilization: **11.2%**).

---

## 9. Academic Deliverables & Report

The project includes a comprehensive, formal academic project report formatted in accordance with university MCA dissertation guidelines:
- **File Location:** `output/EV_Charging_Analytics_Project_Report.docx`
- **Contents:** 27 complete chapters covering abstract, literature review, functional requirements, database schema, data generation methodology, SQL implementation, Excel financial modeling, Tableau dashboard architecture, actual findings, business recommendations, limitations, future scope, and references.

---

## 10. Troubleshooting & Common Questions

1. **`LOAD DATA LOCAL INFILE` fails in MySQL:**
   - Run `SET GLOBAL local_infile = 1;` in MySQL.
   - Connect client with `mysql --local-infile=1 -u root -p`.
   - Ensure forward slashes (`/`) are used in Windows file paths.
2. **Formulas show `#NAME?` in non-English Excel:**
   - Formulas use standard English uppercase names (`SUM`, `IF`, `ROUND`, `AVERAGE`). Ensure Excel calculation options are set to *Automatic*.
3. **Tableau shows duplicated sums on join:**
   - Do not use physical joins. Use Tableau's logical **Relationships** on the data source canvas as detailed in `docs/TABLEAU_IMPLEMENTATION_GUIDE.md`.

---

## 11. Authors & Academic Disclaimer

- **Author:** MCA Candidate (Data Analytics & Business Intelligence)
- **Academic Mentor:** Senior Data Analytics Engineer & Curriculum Mentor
- **Disclaimer:** All data in this repository is synthetic and generated for educational and analytical benchmarking. No proprietary data belonging to any commercial charging point operator was used.
